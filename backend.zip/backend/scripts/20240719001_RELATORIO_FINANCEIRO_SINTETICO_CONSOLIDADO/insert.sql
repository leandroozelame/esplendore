INSERT INTO CIX.TB_PARAMETRO_CANAL
(SQ_PARAMETRO_CANAL, CD_SECAO, DS_PARAMETRO, DS_SECAO, NO_PARAMETRO, NR_CANAL, ST_ATIVO, ST_EDITAVEL, VL_PARAMETRO)
VALUES(707, 5, 'REL - Relatório Financeiro Sintético Consolidado', 'RELATÓRIOS', '10000000000018', 5, '1', '1', 'financeiro-sintetico-consolidado?dependencia={dependencia}&data={data}&canal={canal}');
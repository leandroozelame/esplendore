
CANAL 5 PERNA 0

UPDATE BLK2.PRC

SET PRCNOM='FLUXO_501000_0_5', PRCTIPFLX=0, PRCVER=10000, PRCDFN='<?xml version="1.0" encoding="UTF-8"?> 

		<definitions id="Definition" 

		targetNamespace="http://www.jboss.org/drools" 

		typeLanguage="http://www.java.com/javaTypes" 

		expressionLanguage="http://www.mvel.org/2.0" 

		xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" 

		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 

		xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" 

		xmlns:g="http://www.jboss.org/drools/flow/gpd" 

		xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 

		xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" 

		xmlns:di="http://www.omg.org/spec/DD/20100524/DI" 

		xmlns:tns="http://www.jboss.org/drools"> 

<process processType="Private" isExecutable="true" id="bpmn_501000_0_1_5" name="Solicitacao Titulos BRB" tns:packageName="defaultPackage" > 

<!-- nodes --> 

<startEvent id="_1" name="StartProcess" /> 

	<task id="_2" name="ValidaTransacaoCanalComponenteHandler" tns:taskName="ValidaTransacaoCanalComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_3" name="CalculaDataReferenciaComponenteHandler" tns:taskName="CalculaDataReferenciaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_4" name="ValidaCodigoSegurancaComponenteHandler" tns:taskName="ValidaCodigoSegurancaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_5" name="ValidaDataRealizacaoTransacaoComponenteHandler" tns:taskName="ValidaDataRealizacaoTransacaoComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_6" name="ValidaCodigoBarrasCobrancaComponenteHandler" tns:taskName="ValidaCodigoBarrasCobrancaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_7" name="ValidaTitulosProprioBancoNPCComponenteHandler" tns:taskName="ValidaTitulosProprioBancoNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_8" name="ValidaDataPagamentoTitulosNPCComponenteHandler" tns:taskName="ValidaDataPagamentoTitulosNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_9" name="ValidaTransacaoDuplicadaNPCComponenteHandler" tns:taskName="ValidaTransacaoDuplicadaNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
 
	<task id="_10" name="IncluiReciboComponenteHandler" tns:taskName="IncluiReciboComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_11" name="GeraAutenticacaoEletronicaComponenteHandler" tns:taskName="GeraAutenticacaoEletronicaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_12" name="GravaComprovanteComponenteHandler" tns:taskName="GravaComprovanteComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
 
<endEvent id="_13" name="End" >	<terminateEventDefinition/></endEvent> 

				    <!-- connections --> 

	<sequenceFlow id="_1-_2" sourceRef="_1" targetRef="_2" />

	<sequenceFlow id="_2-_3" sourceRef="_2" targetRef="_3" />

	<sequenceFlow id="_3-_4" sourceRef="_3" targetRef="_4" />

	<sequenceFlow id="_4-_5" sourceRef="_4" targetRef="_5" />

	<sequenceFlow id="_5-_6" sourceRef="_5" targetRef="_6" />

	<sequenceFlow id="_6-_7" sourceRef="_6" targetRef="_7" />

	<sequenceFlow id="_7-_8" sourceRef="_7" targetRef="_8" />

	<sequenceFlow id="_8-_9" sourceRef="_8" targetRef="_9" />

	<sequenceFlow id="_9-_10" sourceRef="_9" targetRef="_10" />

	<sequenceFlow id="_10-_11" sourceRef="_10" targetRef="_11" />

	<sequenceFlow id="_11-_12" sourceRef="_11" targetRef="_12" />

	<sequenceFlow id="_12-_13" sourceRef="_12" targetRef="_13" />

</process> 

</definitions>', PRCDATHOR=TIMESTAMP '2024-04-09 16:09:39.000000'

WHERE PRCID='501000_5_0_10000                    ';

CANAL 5 PERNA 1

UPDATE BLK2.PRC

SET PRCNOM='FLUXO_501000_1_5', PRCTIPFLX=1, PRCVER=10000, PRCDFN='<?xml version="1.0" encoding="UTF-8"?><definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" id="Definition" targetNamespace="http://www.jboss.org/drools" typeLanguage="http://www.java.com/javaTypes" expressionLanguage="http://www.mvel.org/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" xmlns:g="http://www.jboss.org/drools/flow/gpd" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:tns="http://www.jboss.org/drools">

  <process processType="Private" isExecutable="true" id="bpmn_501000_1_1_5" name="Confirmacaoo Titulos BRB" tns:packageName="defaultPackage">

    <!-- nodes -->

    <startEvent id="_1" name="StartProcess"/>

    <task id="_2" name="BaixaOperacionalNPCOutrosMeiosPgtoComponenteHandler" tns:taskName="BaixaOperacionalNPCOutrosMeiosPgtoComponenteHandler">

      <ioSpecification>

        <inputSet> 

			</inputSet>

        <outputSet> 

			</outputSet>

      </ioSpecification>

    </task>

    <task id="_3" name="ConfirmaTransacaoComprovanteComponenteHandler" tns:taskName="ConfirmaTransacaoComprovanteComponenteHandler">

      <ioSpecification>

        <inputSet> 

			</inputSet>

        <outputSet> 

			</outputSet>

      </ioSpecification>

    </task>

    <endEvent id="_4" name="End">

      <terminateEventDefinition/>

    </endEvent>

    <!-- connections -->

    <sequenceFlow id="_1-_2" sourceRef="_1" targetRef="_2"/>

    <sequenceFlow id="_2-_3" sourceRef="_2" targetRef="_3"/>

    <sequenceFlow id="_3-_4" sourceRef="_3" targetRef="_4"/>

  </process>

</definitions>', PRCDATHOR=TIMESTAMP '2024-04-09 16:09:39.000000'

WHERE PRCID='501000_5_1_10000                    ';

CANAL 9 PERNA 0

UPDATE BLK2.PRC

SET PRCNOM='FLUXO_501000_0_9', PRCTIPFLX=0, PRCVER=10000, PRCDFN='<?xml version="1.0" encoding="UTF-8"?> 

		<definitions id="Definition" 

		targetNamespace="http://www.jboss.org/drools" 

		typeLanguage="http://www.java.com/javaTypes" 

		expressionLanguage="http://www.mvel.org/2.0" 

		xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" 

		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 

		xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" 

		xmlns:g="http://www.jboss.org/drools/flow/gpd" 

		xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" 

		xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" 

		xmlns:di="http://www.omg.org/spec/DD/20100524/DI" 

		xmlns:tns="http://www.jboss.org/drools"> 

<process processType="Private" isExecutable="true" id="bpmn_501000_0_1_9" name="Solicitacao Titulos BRB" tns:packageName="defaultPackage" > 

<!-- nodes --> 

<startEvent id="_1" name="StartProcess" /> 

	<task id="_2" name="ValidaTransacaoCanalComponenteHandler" tns:taskName="ValidaTransacaoCanalComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_3" name="CalculaDataReferenciaComponenteHandler" tns:taskName="CalculaDataReferenciaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_4" name="ValidaCodigoSegurancaComponenteHandler" tns:taskName="ValidaCodigoSegurancaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_5" name="ValidaDataRealizacaoTransacaoComponenteHandler" tns:taskName="ValidaDataRealizacaoTransacaoComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_6" name="ValidaCodigoBarrasCobrancaComponenteHandler" tns:taskName="ValidaCodigoBarrasCobrancaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_7" name="ValidaTitulosProprioBancoNPCComponenteHandler" tns:taskName="ValidaTitulosProprioBancoNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_8" name="ValidaDataPagamentoTitulosNPCComponenteHandler" tns:taskName="ValidaDataPagamentoTitulosNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_9" name="ValidaTransacaoDuplicadaNPCComponenteHandler" tns:taskName="ValidaTransacaoDuplicadaNPCComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_10" name="IncluiReciboComponenteHandler" tns:taskName="IncluiReciboComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_11" name="GeraAutenticacaoEletronicaComponenteHandler" tns:taskName="GeraAutenticacaoEletronicaComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
	<task id="_12" name="GravaComprovanteComponenteHandler" tns:taskName="GravaComprovanteComponenteHandler" > 

		<ioSpecification> 

			<inputSet> 

			</inputSet> 

			<outputSet> 

			</outputSet> 

		</ioSpecification> 

	</task>
 
 
<endEvent id="_13" name="End" >	<terminateEventDefinition/></endEvent> 

				    <!-- connections --> 

	<sequenceFlow id="_1-_2" sourceRef="_1" targetRef="_2" />

	<sequenceFlow id="_2-_3" sourceRef="_2" targetRef="_3" />

	<sequenceFlow id="_3-_4" sourceRef="_3" targetRef="_4" />

	<sequenceFlow id="_4-_5" sourceRef="_4" targetRef="_5" />

	<sequenceFlow id="_5-_6" sourceRef="_5" targetRef="_6" />

	<sequenceFlow id="_6-_7" sourceRef="_6" targetRef="_7" />

	<sequenceFlow id="_7-_8" sourceRef="_7" targetRef="_8" />

	<sequenceFlow id="_8-_9" sourceRef="_8" targetRef="_9" />

	<sequenceFlow id="_9-_10" sourceRef="_9" targetRef="_10" />

	<sequenceFlow id="_10-_11" sourceRef="_10" targetRef="_11" />

	<sequenceFlow id="_11-_12" sourceRef="_11" targetRef="_12" />

	<sequenceFlow id="_12-_13" sourceRef="_12" targetRef="_13" />

</process> 

</definitions>', PRCDATHOR=TIMESTAMP '2024-04-09 16:09:39.000000'

WHERE PRCID='501000_9_0_10000                    ';

CANAL 9 PERNA 1

UPDATE BLK2.PRC

SET PRCNOM='FLUXO_501000_1_9', PRCTIPFLX=1, PRCVER=10000, PRCDFN='<?xml version="1.0" encoding="UTF-8"?><definitions xmlns="http://www.omg.org/spec/BPMN/20100524/MODEL" id="Definition" targetNamespace="http://www.jboss.org/drools" typeLanguage="http://www.java.com/javaTypes" expressionLanguage="http://www.mvel.org/2.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" xmlns:g="http://www.jboss.org/drools/flow/gpd" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:tns="http://www.jboss.org/drools">

  <process processType="Private" isExecutable="true" id="bpmn_501000_1_1_9" name="Confirmacao Titulos BRB" tns:packageName="defaultPackage">

    <!-- nodes -->

    <startEvent id="_1" name="StartProcess"/>

    <task id="_2" name="BaixaOperacionalNPCOutrosMeiosPgtoComponenteHandler" tns:taskName="BaixaOperacionalNPCOutrosMeiosPgtoComponenteHandler">

      <ioSpecification>

        <inputSet> 

			</inputSet>

        <outputSet> 

			</outputSet>

      </ioSpecification>

    </task>

    <task id="_3" name=" ConfirmaTransacaoComprovanteComponenteHandler" tns:taskName=" ConfirmaTransacaoComprovanteComponenteHandler">

      <ioSpecification>

        <inputSet> 

			</inputSet>

        <outputSet> 

			</outputSet>

      </ioSpecification>

    </task>

    <endEvent id="_4" name="End">

      <terminateEventDefinition/>

    </endEvent>

    <!-- connections -->

    <sequenceFlow id="_1-_2" sourceRef="_1" targetRef="_2"/>

    <sequenceFlow id="_2-_3" sourceRef="_2" targetRef="_3"/>

    <sequenceFlow id="_3-_4" sourceRef="_3" targetRef="_4"/>

  </process>

</definitions>', PRCDATHOR=TIMESTAMP '2024-04-09 16:09:39.000000'

WHERE PRCID='501000_9_1_10000                    ';
package br.com.brb.cix.domain.model.formapagamento;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FormaPagamentoRepository extends JpaRepository<FormaPagamento, Long> {
    
    FormaPagamento findByCodigo(Long codigo);
    
    List<FormaPagamento> findAllByOrderByCodigo();
    
    List<FormaPagamento> findByCodigoNotIn(List<Long> codigo);
}

package br.com.brb.cix.domain.model.interfaces;

/**
 *
 * @author NUCAN
 */
public interface ILogFinanceiroBanklink {
    public String montaLogParticao(Integer erro);
}

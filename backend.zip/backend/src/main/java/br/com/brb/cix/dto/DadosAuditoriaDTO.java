package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DadosAuditoriaDTO {
	private Object parametroEntrada;
	private Object parametroSaida;
	private BigDecimal valorTransacao;
	private Long numeroConta;
}
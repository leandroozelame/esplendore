package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.ws.consulta.dto.RespostaCodigosPagamentoGps;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class RespostaCodigosPagamentoGpsDTO {
    
   private List<RespostaCodigosPagamentoGps> consultaCodigosPagamentoGps;
   
   public RespostaCodigosPagamentoGpsDTO(){};
  
   
   
}

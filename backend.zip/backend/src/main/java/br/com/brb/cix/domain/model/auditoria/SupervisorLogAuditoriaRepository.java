package br.com.brb.cix.domain.model.auditoria;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SupervisorLogAuditoriaRepository extends JpaRepository<SupervisorLogAuditoria, Long> {
}
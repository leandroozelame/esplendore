package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoExtratoCDB implements EnumDominio {
    FUNDOS(9, "Fundos de investimento"), //
    OPERACOES_VENCIDAS(10, "Operações de CDB vencidas");

    private static final Map<Integer, EnumTipoExtratoCDB> MAP = new HashMap<>();

    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;

    static {
        for (EnumTipoExtratoCDB e : EnumTipoExtratoCDB.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoExtratoCDB get(int codTipoExtrato) {
        return MAP.get(codTipoExtrato);
    }

    @JsonCreator
    public static EnumTipoExtratoCDB criaEnum(int codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}
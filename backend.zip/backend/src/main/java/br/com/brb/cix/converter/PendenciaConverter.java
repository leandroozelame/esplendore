package br.com.brb.cix.converter;

import br.com.brb.cix.domain.model.pendencia.Pendencia;
import br.com.brb.cix.dto.PendenciaDTO;

public class PendenciaConverter {

    public static PendenciaDTO toPendenciaDTO(Pendencia pendencia) {
        PendenciaDTO pendenciaDTO = new PendenciaDTO();
        pendenciaDTO.setCodigo(pendencia.getCodigo());
        pendenciaDTO.setNsuCix(pendencia.getNsuCix());
        pendenciaDTO.setNsuBlk(pendencia.getNsuBlk());
        pendenciaDTO.setNsuCixEstornado(pendencia.getNsuCixEstornado());
        pendenciaDTO.setSituacao(pendencia.getSituacao());
        pendenciaDTO.setCodigoRegra(pendencia.getRegra().getCodigo());
        pendenciaDTO.setNomeRegra(pendencia.getRegra().getNome());
        pendenciaDTO.setNumeroRecibo(pendencia.getNumeroRecibo());
        pendenciaDTO.setDataCadastro(pendencia.getDataCadastro());
        pendenciaDTO.setDataAtualizacao(pendencia.getDataAtualizacao());
        pendenciaDTO.setValor(pendencia.getValor());
        pendenciaDTO.setDescricao(pendencia.getDescricao());
        pendenciaDTO.setContaOrigem(pendencia.getContaOrigem());
        pendenciaDTO.setContaDestino(pendencia.getContaDestino());
        pendenciaDTO.setTerminal(pendencia.getTerminal());
        pendenciaDTO.setMatricula(pendencia.getMatricula());
        pendenciaDTO.setMatriculaUltimoAutorizador(pendencia.getMatriculaUltimoAutorizador());
        pendenciaDTO.setUnidade(pendencia.getUnidade());
        pendenciaDTO.setDetalhamento(pendencia.getDetalhamento());
        pendenciaDTO.setMotivoRejeicao(pendencia.getMotivoRejeicao());

        // Verifica se nsuBlk, nsuCix e situacao são 0 e adiciona null
        if (pendenciaDTO.getNsuBlk() == 0) {
            pendenciaDTO.setNsuBlk(null);
        }
        if (pendenciaDTO.getNsuCix() == 0) {
            pendenciaDTO.setNsuCix(null);
        }
        if (pendenciaDTO.getSituacao()  == '0') {
            pendenciaDTO.setSituacao(null);
        }

        return pendenciaDTO;
    }
}
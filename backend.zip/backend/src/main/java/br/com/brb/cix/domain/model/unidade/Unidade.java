package br.com.brb.cix.domain.model.unidade;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.brb.cix.domain.model.grupocnp.BloqueioCorrespondente;
import br.com.brb.cix.config.jackson.CustomGrupoCNPSerializer;
import br.com.brb.cix.domain.model.grupocnp.GrupoCNP;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Table(name = "VW_UND")
@ToString
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "codigo")
public class Unidade  {
    private static final long serialVersionUID = -7884383952009631321L;

    @Id
    @Column(name = "UNDCOD")
    private Long codigo;

    @Column(name = "UNDDSC")
    private String descricao;

    @Column(name = "UNDCAT")
    private Integer categoria;

    @Column(name = "UNDTRA")
    private Integer transacionavel;
    
    @Column(name = "UNDTIP")
    private Integer tipo;
    
    @JsonSerialize(using=CustomGrupoCNPSerializer.class)
    @ManyToMany(mappedBy="listaCorrespondentes", cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    private List<GrupoCNP> listaGrupos;
    
    @OneToOne(mappedBy = "unidade")
    private BloqueioCorrespondente bloqueioCorrespondente;

    @ManyToOne
    @JoinColumn(name = "PTA_LIQUIDACAO")
    private Unidade ptaLiquidacao;
}

package br.com.brb.cix.dto;


import java.util.Date;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AtendimentoSaidaDTO extends AbstractDTO {
    private Long codigo; 
    private String nomeCliente;
    private String cpfCliente;
    private Long telefoneCliente;
    private Date dataInicio;
    private Date dataFim;
    
}
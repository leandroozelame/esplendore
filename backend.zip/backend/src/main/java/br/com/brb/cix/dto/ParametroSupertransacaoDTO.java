package br.com.brb.cix.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class ParametroSupertransacaoDTO {
	
	private Long id;
	private Integer modulo;
	private FormaPagamentoDTO formaPagamento;
	private Date dataCriacao;
	private Date dataAlteracao;
	private Boolean habilitado;
	private List<FuncionalidadeDTO> funcionalidades;
	
}

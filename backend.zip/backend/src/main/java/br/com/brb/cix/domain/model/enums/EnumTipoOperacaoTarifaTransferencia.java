package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author u653865
 *
 */
@Getter
@AllArgsConstructor
public enum EnumTipoOperacaoTarifaTransferencia implements EnumDominio {

    CONSULTA_TARIFA(1, "Consulta Tarifa"), 
    CONSULTA_PROTOCOLO(2, "Consulta Protocolo"), 
    RECEBIMENTO_TARIFA(3, "Recebimento Tarifa"),
    CONSULTA_TARIFA_A_SER_CANCELADA(4, "Consulta Tarifa a ser cancelada"), 
    CANCELA_PAGAMENTO_TARIFA(5, "Cancela Pagamento Tarifa");

    private Integer codigo;
    private String descricao;

    static List<EnumTipoOperacaoTarifaTransferencia> listaEnum = Arrays
            .asList(EnumTipoOperacaoTarifaTransferencia.values());
    private static final Map<Integer, EnumTipoOperacaoTarifaTransferencia> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

    /**
     * @param codigo
     * @return
     */
    @JsonCreator
    public static EnumTipoOperacaoTarifaTransferencia get(int codigo) {
        return MAP.get(codigo);
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

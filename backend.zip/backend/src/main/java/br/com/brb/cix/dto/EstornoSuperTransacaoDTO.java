package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class EstornoSuperTransacaoDTO {

    private Boolean isEstornavel;
    private Long numeroTransacao;
    private String nomeTransacao;
    private BigDecimal valorTransacao;
    private Long nsuTransacao;
}

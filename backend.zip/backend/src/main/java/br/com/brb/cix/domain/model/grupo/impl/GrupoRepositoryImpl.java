package br.com.brb.cix.domain.model.grupo.impl;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.Getter;

@Repository
public class GrupoRepositoryImpl {
    @Getter
    private final EntityManager entityManager;

    @Autowired
    public GrupoRepositoryImpl(EntityManager manager) {
        entityManager = manager;
    }
}
package br.com.brb.cix.domain.model.perfil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.domain.model.grupo.Grupo;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Table(name = "TB_PERFIL")
public class Perfil  {

    private static final long serialVersionUID = -7884383952009631336L;

    @Id
    @SequenceGenerator(name = "perfil_sequence", sequenceName = "SQ_PERFIL", allocationSize = 1)
    @GeneratedValue(generator = "perfil_sequence")
    @Column(name = "SQ_CODIGO", unique=true)
    private Long codigo;

    @Column(name = "NO_NOME")
    private String nome;

    @Column(name = "DS_DESCRICAO", nullable = true)
    private String descricao;

    @Column(name = "ST_ATIVO")
    private Character ativo;

    @Column(name = "NR_MATRICULA")
    private Integer matricula;

    @Column(name = "DT_CRIACAO")
    private Date dataCriacao;

    @Column(name = "DT_ALTERACAO", nullable = true)
    private Date dataAlteracao;

    @Column(name = "CD_MODULO")
    private Integer modulo;

    @JsonManagedReference
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "TB_PERFIL_GRUPO",
            joinColumns = @JoinColumn(name = "SQ_CODIGO", referencedColumnName = "SQ_CODIGO"),
            inverseJoinColumns = @JoinColumn(name = "CD_GRPCOD", referencedColumnName = "GRPCOD"))
    private List<Grupo> listaGrupos;

    @JsonManagedReference
    @ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "TB_PERFIL_FUNCIONALIDADE",
            joinColumns = @JoinColumn(name = "SQ_CODIGO", referencedColumnName = "SQ_CODIGO"),
            inverseJoinColumns = @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE"))
    private List<Funcionalidade> listaFuncionalidades;

    public Perfil() {
        super();
        dataCriacao = new Date();
        listaFuncionalidades = new ArrayList<>();
    }

    public Perfil(String nome, String descricao, Integer matricula, Integer modulo) {
        super();
        this.nome = nome;
        this.descricao = descricao;
        this.matricula = matricula;
        this.ativo = '1';
        this.modulo = modulo;
        dataCriacao = new Date();
    }

}

package br.com.brb.cix.domain.model.supertransacao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametroSupertransacaoRepository extends JpaRepository<ParametroSupertransacao, Long> {
	
	ParametroSupertransacao findByModuloAndFormaPagamentoCodigo(Integer modulo, Long codigoFormaPagamento);
	
	List<ParametroSupertransacao> findByModulo(Integer modulo);
	
	List<ParametroSupertransacao> findByModuloAndFuncionalidadesCodigoIn(Integer modulo, List<Long> funcionalidades);
	
	List<ParametroSupertransacao> findByModuloAndFormaPagamentoCodigoAndFuncionalidadesCodigoIn(Integer modulo, Long codigoFormaPagamento, List<Long> funcionalidades);

	List<ParametroSupertransacao> findByModuloAndHabilitado(Integer modulo, Boolean habilitado);
}

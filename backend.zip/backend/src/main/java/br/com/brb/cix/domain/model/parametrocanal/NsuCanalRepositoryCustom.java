package br.com.brb.cix.domain.model.parametrocanal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public class NsuCanalRepositoryCustom {
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public NsuCanalRepositoryCustom(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public Long proximoNSU() {
        return jdbcTemplate.queryForObject("SELECT CIX.SQ_NSU_CANAL.NEXTVAL FROM DUAL", Long.class);
    }

    public Long atualNSU() {
        return jdbcTemplate.queryForObject("SELECT CIX.SQ_NSU_CANAL.CURRVAL FROM DUAL", Long.class);
    }

}

package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RecebimentoArrecadacaoDTO extends ContaTipoDTO {
	
	private String codigoBarras;
	private Date dataVencimento;

	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Integer tipoCaptura;

	private String descricaoTipoCaptura;
	private String convenio;
	private BigDecimal valorTitulo;
	private BigDecimal valorMulta;
	private BigDecimal valorJuros;
	private BigDecimal valorOutrosAcrescimos;
	private BigDecimal valorDesconto;
	@LogValorTransacao
	private BigDecimal valorTotalCobranca;
	private String documentoIdentificacao;
	private Date dataEmissaoDocumento;
	private EnumFormaMovimentacao formaMovimentacao;
	private Long numeroFichaContabil;
	private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
	private Integer numeroCheque;
	private Long numeroContaCheque;
	private String cmc7;
	private String matriculaSupervisor;
	private Integer idAlvara;
	private BigDecimal valorAlvara;
	private String nomeBeneficiario;
	private Long cpfCnpj;
	private String tipoPessoa;
	private String nomeTribunal;
	private String cnpjTribunal;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Integer tpPessoaSigla;
}
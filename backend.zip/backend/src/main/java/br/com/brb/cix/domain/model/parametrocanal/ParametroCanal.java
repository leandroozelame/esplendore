package br.com.brb.cix.domain.model.parametrocanal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "TB_PARAMETRO_CANAL")
public class ParametroCanal  {
    private static final long serialVersionUID = -9183640981662144837L;

    @SequenceGenerator(name = "parametrocanal_sequence", sequenceName = "SQ_PARAMETRO_CANAL", allocationSize = 1)
    @GeneratedValue(generator = "parametrocanal_sequence")
    @Column(name = "SQ_PARAMETRO_CANAL", nullable = true)
    @Id
    @Getter
    @Setter
    private Long id;

    @Column(name = "CD_SECAO", nullable = true)
    @Getter
    @Setter
    private Integer codigoSecao;

    @Column(name = "DS_SECAO", nullable = true)
    @Getter
    @Setter
    private String secao;

    @Column(name = "NR_CANAL", nullable = true)
    @Getter
    @Setter
    private Integer numeroCanal;

    @Column(name = "NO_PARAMETRO", nullable = true)
    @Getter
    @Setter
    private String parametro;

    @Column(name = "VL_PARAMETRO", nullable = true)
    @Getter
    @Setter
    private String valorParametro;

    @Column(name = "DS_PARAMETRO", nullable = true)
    @Getter
    @Setter
    private String descricaoParametro;

    @Column(name = "ST_EDITAVEL", nullable = true)
    @Getter
    @Setter
    private Character editavel;

    @Column(name = "ST_ATIVO", nullable = true)
    @Getter
    @Setter
    private Character ativo;
}

package br.com.brb.cix.domain.model.capturadadosPLD;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.util.ConvertCharToBoolean;
import br.com.brb.cix.util.SimNaoConverter;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_CAPTURA_DADOS_PLD")
public class CapturaDadosPLD {

    private static final long serialVersionUID = 623334414738169809L;

    @Id
    @SequenceGenerator(name = "captura_dados_pld_sequence",  sequenceName = "SQ_CAPTURA_DADOS_PLD",  allocationSize = 1)
    @GeneratedValue(generator = "captura_dados_pld_sequence")
    @Column(name = "SQ_CAPTURA_DADOS_PLD")
    private Long  id;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_ESTRANGEIRO_RESPONSAVEL")
    private Boolean estrangeiroResponsavel;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_ESTRANGEIRO_PORTADOR")
    private Boolean estrangeiroPortador;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_ESTRANGEIRO_DEPOSITANTE")
    private Boolean estrangeiroDepositante;
    
    @Column(name = "DN_CPF_CNPJ_RESPONSAVEL")
    private String cpfCnpjResponsavel;
    
    @Column(name = "DN_CPF_CNPJ_PORTADOR")
    private String cpfCnpjPortador;
    
    @Column(name = "DN_CPF_CNPJ_DEPOSITANTE")
    private String cpfCnpjDepositante;
    
    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_PESSOA_RESPONSAVEL")
    private Boolean tipoPessoaResponsavel;
    
    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_PESSOA_DEPOSITANTE")
    private Boolean tipoPessoaDepositante;
    
    @Column(name = "NO_RESPONSAVEL")
    private String nomeResponsavel;
    
    @Column(name = "NO_PORTADOR")
    private String nomePortador;   
    
    @Column(name = "NO_DEPOSITANTE")
    private String nomeDepositante;
    
    @Column(name = "DN_DOC_VIAGEM_RESPONSAVEL")
    private String numeroDocViagemResponsavel;
    
    @Column(name = "DN_DOC_VIAGEM_PORTADOR")
    private String numeroDocViagemPortador;
    
    @Column(name = "DN_DOC_VIAGEM_DEPOSITANTE")
    private String numeroDocViagemDepositante;
    
    @Column(name = "NO_TIPO_DOC_RESPONSAVEL")
    private String tipoDocResponsavel;
    
    @Column(name = "NO_TIPO_DOC_PORTADOR")
    private String tipoDocPortador;
    
    @Column(name = "NO_TIPO_DOC_DEPOSITANTE")
    private String tipoDocDepositante;
    
    @Column(name = "NO_PAIS_ORIGEM_RESPONSAVEL")
    private String paisOrigemResponsavel;
    
    @Column(name = "NO_PAIS_ORIGEM_PORTADOR")
    private String paisOrigemPortador;
    
    @Column(name = "NO_PAIS_ORIGEM_DEPOSITANTE")
    private String paisOrigemDepositante;
    
    @Column(name = "NO_ORGANISMO_INTERNACIONAL_RES")
    private String organismoInternacionalResponsavel;
    
    @Column(name = "NO_ORGANISMO_INTERNACIONAL_POR")
    private String organismoInternacionalPortador;
    
    @Column(name = "NO_ORGANISMO_INTERNACIONAL_DEP")
    private String organismoInternacionalDepositante;
    
    @Column(name = "DN_REGISTRO_PJ_RESPONSAVEL")
    private String numeroRegistroPessoaJuridicaResponsavel;
    
    @Column(name = "DN_REGISTRO_PJ_DEPOSITANTE")
    private String numeroRegistroPessoaJuridicaDepositante;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_RECUSA_CLIENTE")
    private Boolean recusaCliente;
    
    @Column(name = "DS_ORIGEM_RECURSO")
    private String origemRecurso;
    
    @Column(name = "DS_FINALIDADE_SAQUE")
    private String finalidadeSaque;
    
    @Column(name = "NR_PROTOCOLO_FRM")
    private String numeroProtocoloFRM;
    
    @Column(name = "NR_NSU_TRANSACAO")
    private Long nsuTransacao;
}

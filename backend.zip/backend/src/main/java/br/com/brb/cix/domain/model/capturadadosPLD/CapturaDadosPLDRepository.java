package br.com.brb.cix.domain.model.capturadadosPLD;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CapturaDadosPLDRepository extends JpaRepository<CapturaDadosPLD, Long> {
    
    //List<CapturaDadosPLD> findByNsuTransacao(Long nsuAutorizacao);
    
    @Query(value = " SELECT cap.NR_NSU_TRANSACAO FROM {h-schema}TB_CAPTURA_DADOS_PLD cap "
            + "WHERE cap.NR_NSU_TRANSACAO = ?1", nativeQuery = true)
    List<Long> findByNsuTransacao(Long nsuAutorizacao);
    
}
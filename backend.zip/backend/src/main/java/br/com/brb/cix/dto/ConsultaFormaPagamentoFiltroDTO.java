package br.com.brb.cix.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultaFormaPagamentoFiltroDTO {
    @NotNull
    private Integer codigoModulo;
    private Integer codigoUnidade;
    private Long codigoTerminal;
    private Long codigoFuncionalidade;
    private Long codigoFormaPagamento;
}

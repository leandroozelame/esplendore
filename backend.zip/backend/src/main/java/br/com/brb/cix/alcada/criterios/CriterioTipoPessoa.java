package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoPessoa;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.enums.EnumPerfilConta;
import br.com.brb.cix.ws.consulta.dto.InformacaoConta;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CriterioTipoPessoa implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Tipo de Pessoa";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegraTipoPessoa.INDIFERENTE.equals(regra.getTipoPessoa());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        InformacaoConta informacaoConta = dadosTransacao.getInformacaoConta();

        if (informacaoConta == null) {
            log.debug("informacaoConta: {}", informacaoConta);
            return false;
        }

        EnumValorRegraTipoPessoa regraTipoPessoa = regra.getTipoPessoa();
        Integer tipoPessoa = informacaoConta.getTipoPessoa();
        Integer perfilConta = informacaoConta.getCodigoPerfilConta();
        log.debug("regraTipoPessoa: {}, tipoPessoa: {}, perfilConta: {}", regraTipoPessoa, tipoPessoa, perfilConta);

        if (perfilConta != null && perfilConta.equals(EnumPerfilConta.GOVERNO.getCodigo())) {// Força tipo pessoa Governo para perfil 9 (Governo)
            tipoPessoa = Integer.parseInt(EnumValorRegraTipoPessoa.GOVERNO.getCodigo().toString());
            log.debug("Alterando tipo de pessoa para {}", EnumValorRegraTipoPessoa.GOVERNO);
        }
        return regraTipoPessoa.getCodigo().equals(tipoPessoa.toString().charAt(0));
    }
}

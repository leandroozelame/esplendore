package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

@Getter
@Setter
public class FormaPagamentoViasReciboDTO {
    @NotNull
    private Long codigoFormaPagamento;
    private String nomeFormaPagamento;
    @NotNull
    private Integer numeroVias;
}

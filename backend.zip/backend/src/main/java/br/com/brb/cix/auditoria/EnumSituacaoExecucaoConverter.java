package br.com.brb.cix.auditoria;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumSituacaoExecucaoConverter implements AttributeConverter<EnumSituacaoExecucao, Character> {

    @Override
    public Character convertToDatabaseColumn(EnumSituacaoExecucao enumDominio) {
        return enumDominio != null ? enumDominio.getCodigo() : null;
    }

    @Override
    public EnumSituacaoExecucao convertToEntityAttribute(Character codigo) {
        for (EnumSituacaoExecucao enumDominio : EnumSituacaoExecucao.values()) {
            if (enumDominio.getCodigo().equals(codigo)) {
                return enumDominio;
            }
        }

        return null;
    }
}

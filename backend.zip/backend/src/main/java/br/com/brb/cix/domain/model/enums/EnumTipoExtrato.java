package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoExtrato implements EnumDominio{
    DIARIO(1, "Diário"), 
    MENSAL(2, "Mensal"), 
    POR_PERIODO(3, "Por período"), 
    MES_ATUAL(5, "Mês atual"), 
    MESES_ANTERIORES(6, "Meses anteriores"), 
    DIARIO_DETALHADO(8, "Diário detalhado"),
    MENSAL_DETALHADO(9, "Mensal detalhado"), 
    POR_PERIODO_DETALHADO(10, "Por período detalhado");
	
    private static final Map<Integer, EnumTipoExtrato> MAP = new HashMap<>();
    
    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;

    static {
        for (EnumTipoExtrato e : EnumTipoExtrato.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoExtrato get(int codTipoExtrato) {
        return MAP.get(codTipoExtrato);
    }
    
    @JsonCreator
    public static EnumTipoExtrato criaEnum(int codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
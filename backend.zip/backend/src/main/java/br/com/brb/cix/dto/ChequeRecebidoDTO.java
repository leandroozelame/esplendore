package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import lombok.*;

@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class ChequeRecebidoDTO {
    
    private Integer nrCheque;
    private Integer nrBanco;
    private Integer nrAgencia;
    private Integer nrCompensacao;
    private Long nrConta;
    private String cmc7;
    @LogValorTransacao
    private BigDecimal valorCheque;
    
    public ChequeRecebidoDTO(String codigoCmc7) {
        setCamposCmc7(codigoCmc7);
    }

	private void setCamposCmc7(String codigoCmc7) {
		this.nrCheque = Integer.parseInt(codigoCmc7.substring(11, 17));
        this.nrBanco = Integer.parseInt(codigoCmc7.substring(0, 3));
        this.nrAgencia = Integer.parseInt(codigoCmc7.substring(3, 7));
        this.nrCompensacao = Integer.parseInt(codigoCmc7.substring(8, 11));
        this.nrConta = Long.parseLong(codigoCmc7.substring(19, 29));
        this.cmc7 = codigoCmc7;
	}
    
    public ChequeRecebidoDTO(String codigoCmc7, BigDecimal valorCheque) {
    	setCamposCmc7(codigoCmc7);
        this.valorCheque = valorCheque;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.bobina;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.brb.cix.domain.model.terminal.Terminal;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@Entity
@Getter
@Setter
@Table(name = "TB_BOBINA")
public class Bobina {

    @SequenceGenerator(name = "bobina_sequence", sequenceName = "SQ_BOBINA", allocationSize = 1)
    @GeneratedValue(generator = "bobina_sequence")
    @Column(name = "SQ_BOBINA")
    @Id
    private Long codigo;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_ABERTURA_BOBINA")
    private Date dataAbertura;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_FECHAMENTO_BOBINA")
    private Date dataFechamento;

    @Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;

    @Column(name = "SQ_BOBINA_PAI")
    private Long bobinaPai;

    @ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;

    @Lob
    @Column(name = "TX_BOBINA")
    private String textoBobina;

    @Column(name = "DT_ATUALIZACAO")
    private Date dataAtualizacao;

    // FUNÇÕES BOBINA ===============================
    public static final String ABERTURA_CAIXA = "cabecalho-abertura-caixa";
    public static final String TROCA_OPERADOR = "cabecalho-troca-operador";
    public static final String RODAPE_BOBINA = "rodape-bobina";
    public static final String RESUMO_GAVETA = "resumo-gaveta";
    public static final String RESUMO_GAVETA_CONFERENCIA = "resumo-gaveta-conferencia";
    public static final String RESUMO_TROCA_NUMERARIO = "resumo-troca-numerario";
    public static final String COMPROVANTE_DOC_ASSINATURA = "comprovante-doc-assinatura";

}

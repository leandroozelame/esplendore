package br.com.brb.cix.domain.model.transacaoSupertransacao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SituacaoExecucaoTransacaoRepository extends JpaRepository<SituacaoExecucaoTransacao, Integer> {

}

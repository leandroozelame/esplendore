package br.com.brb.cix.domain.model.resumotransacao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import br.com.brb.cix.domain.model.terminal.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResumoTransacaoRepository extends JpaRepository<ResumoTransacao, Long> {
	List<ResumoTransacao> findByTerminalAndDataTransacaoBetweenOrderByDataTransacaoAscEventoAsc(Terminal terminal, Date dataInicial, Date dataFinal);

	@Query(nativeQuery = true, value = "SELECT * FROM {h-schema}TB_RESUMO_TRANSACAO  "
			+ "WHERE SQ_RESUMO_TRANSACAO IN (SELECT MAX(SQ_RESUMO_TRANSACAO) FROM {h-schema}TB_RESUMO_TRANSACAO WHERE CD_TRANSACAO = ?1 "
			+ "AND SQ_TERMINAL = ?2 "
			+ "AND TRUNC(DT_TRANSACAO) = TRUNC(SYSDATE)) ")
	ResumoTransacao buscarUltimoResumo(Long codigoTransacao, Long codigoTerminal);

	@Query(nativeQuery = true, value = "SELECT * FROM {h-schema}TB_RESUMO_TRANSACAO  "
			+ "WHERE DT_TRANSACAO IN (SELECT MAX(DT_TRANSACAO) FROM {h-schema}TB_RESUMO_TRANSACAO WHERE SQ_TERMINAL = ?1 "
			+ "AND DS_EVENTO LIKE '%Gaveta - %' AND TX_RESUMO IS NOT NULL AND CD_NSU_AUTORIZACAO < ?2) ")
	List<ResumoTransacao> buscarUltimoResumoPorData(Long codigoTerminal, Long nsu);
	
	List<ResumoTransacao> findByNsuAutorizacao(Long nsuAutorizacao);
}

package br.com.brb.cix.domain.model.resumotransacao;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import br.com.brb.cix.domain.model.terminal.Terminal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TB_RESUMO_TRANSACAO")
public class ResumoTransacao {
	
	@Id
	@SequenceGenerator(name = "resumo_transacao_sequence", sequenceName = "SQ_RESUMO_TRANSACAO", allocationSize = 1)
    @GeneratedValue(generator = "resumo_transacao_sequence")
    @Column(name = "SQ_RESUMO_TRANSACAO")
    private Long codigo;
	
	@ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;
	
	@Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;
	
	@Column(name = "CD_TRANSACAO")
    private Long codigoTransacao;
	
	@Column(name = "NO_TRANSACAO")
	private String nomeTransacao;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DT_TRANSACAO")
	private Date dataTransacao;
	
	@Column(name = "CD_NSU_AUTORIZACAO")
	private Long nsuAutorizacao;
	
	@Lob
    @Column(name = "TX_RESUMO")
    private String resumo;
	
	@Column(name = "DS_EVENTO")
	private String evento;
	
	@Column(name = "VL_TRANSACAO")
	private BigDecimal valorTransacao;
}
package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.security.Conta;
import br.com.brb.cix.security.OperadorLogado;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CriterioContaOperador implements CriterioAlcada {

    @Autowired
    private OperadorLogado operadorLogado;

    @Override
    public String getNomeCriterio() {
        return "Conta Operador";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegra.INDIFERENTE.equals(regra.getContaOperador());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        Long numeroConta = dadosTransacao.getConta();
        if (numeroConta == null) {
            log.debug("numeroConta: {}", numeroConta);
            return false;
        }

        EnumValorRegra regraContaOperador = regra.getContaOperador();
        List<Long> contasOperador = operadorLogado.getContas().stream()
                .map(Conta::getConta)
                .collect(Collectors.toList());
        Boolean contaNaLista = contasOperador.contains(numeroConta);

        log.debug("regraContaOperador: {}, numeroConta: {}, contasOperador: {}, contaNaLista: {}", regraContaOperador, numeroConta, contasOperador, contaNaLista);

        return     (regraContaOperador.equals(EnumValorRegra.NAO) && !contaNaLista)
                || (regraContaOperador.equals(EnumValorRegra.SIM) && contaNaLista);
    }
}

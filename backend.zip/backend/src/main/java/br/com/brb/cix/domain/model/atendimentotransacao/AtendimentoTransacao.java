/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.atendimentotransacao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.atendimento.Atendimento;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@Entity
@Getter
@Setter
@Table(name = "TB_ATENDIMENTO_TRANSACAO")
public class AtendimentoTransacao {

    @SequenceGenerator(name = "atendimentotransacao_sequence", sequenceName = "SQ_ATENDIMENTO_TRANSACAO",
            allocationSize = 1)
    @GeneratedValue(generator = "atendimentotransacao_sequence")
    @Column(name = "SQ_ATENDIMENTO_TRANSACAO")
    @Id
    private Long codigo;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_ATENDIMENTO", nullable = false)
    private Atendimento atendimento;

    @Column(name = "CD_NSU")
    private Long nsu;

}

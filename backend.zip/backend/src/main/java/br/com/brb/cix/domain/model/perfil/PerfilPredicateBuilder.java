package br.com.brb.cix.domain.model.perfil;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.OrderSpecifier;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public final class PerfilPredicateBuilder {

    public static BooleanBuilder numeroCanal(Integer numeroCanal) {
        return Objects.isNull(numeroCanal) ? new BooleanBuilder()
                : new BooleanBuilder(QPerfil.perfil.modulo.eq(numeroCanal));
    }

    public static BooleanBuilder nomePerfil(String nome) {
        return StringUtils.isEmpty(nome) ? new BooleanBuilder()
                : new BooleanBuilder(QPerfil.perfil.nome.containsIgnoreCase(nome));
    }
    
    public static BooleanBuilder nomePerfilExato(String nome){
        return StringUtils.isEmpty(nome) ? new BooleanBuilder()
                : new BooleanBuilder(QPerfil.perfil.nome.equalsIgnoreCase(nome));        
    }

    public static BooleanBuilder situacao(Character situacao) {
        return situacao == null ? new BooleanBuilder()
                : new BooleanBuilder(QPerfil.perfil.ativo.eq(situacao));
    }

    public static OrderSpecifier<Character> ordenaPorSituacao() {
        return QPerfil.perfil.ativo.desc();
    }

    public static OrderSpecifier<String> ordenaPorNome() {
        return QPerfil.perfil.nome.asc();
    }

}

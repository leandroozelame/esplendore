package br.com.brb.cix.auditoria.anotacao;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.PARAMETER)
@Retention(RetentionPolicy.RUNTIME)
public @interface Log {
	
	/**
	 * Nome do parametro que sera salvo na auditoria
	 * @return
	 */
	String value() default "";
	
	/**
	 * Ignora o parametro na auditoria
	 * @return
	 */
	boolean ignora() default false;
        
        /**
	 * Indica que o parâmetro também é o valor da Transação
	 * @return
	 */
        boolean ehValorTransacao() default false;
        

}

package br.com.brb.cix.domain.model.supertransacao;

import java.util.List;

import br.com.brb.cix.domain.model.terminal.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupertransacaoRepository extends JpaRepository<Supertransacao, Long> {

	Supertransacao findByTerminalAndSituacaoExecucaoCodigoIn(Terminal terminal, List<Integer> situacoes);
	
	Supertransacao findByNsuAndSituacaoExecucao(Long nsu, SituacaoSupertransacao situacao);
}

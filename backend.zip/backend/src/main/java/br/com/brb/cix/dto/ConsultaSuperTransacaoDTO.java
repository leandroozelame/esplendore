package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsultaSuperTransacaoDTO extends AbstractDTO {

    private Long codigoFuncionalidade;
    private String descricaoFuncionalidade;
    private Long codigoFormaPagamento;
    private String descricaoFormaPagamento;

}

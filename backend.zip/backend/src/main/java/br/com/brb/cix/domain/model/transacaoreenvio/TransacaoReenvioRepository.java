package br.com.brb.cix.domain.model.transacaoreenvio;


import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoReenvioRepository extends JpaRepository<TransacaoReenvio, Long> {

}

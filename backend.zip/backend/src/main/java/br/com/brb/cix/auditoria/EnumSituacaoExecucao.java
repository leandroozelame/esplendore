package br.com.brb.cix.auditoria;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumSituacaoExecucao implements EnumDominio{
	ERRO('0', "Falha"), 
	SUCESSO('1', "Sucesso"),
    REJEITADO('2', "Rejeitado"),
	TRNNRM('4', "Normal"),
	TRNCFN('5', "Confirmada"),
	TRNDSC('6', "Desconto"),
	TRNESR('7', "Estornada"),
	TRNREC('8', "Recuperada");

	@Getter
	private Character codigo;
	
	@Getter
	private String descricao;
	
	@Override
	public String toString() {
		return getDescricao();
	}
}

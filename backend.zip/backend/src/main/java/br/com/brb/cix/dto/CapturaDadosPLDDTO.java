package br.com.brb.cix.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Id;

import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CapturaDadosPLDDTO implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long id;

    private String numeroProtocoloFrm;

    // Responsável

    private Boolean estrangeiroResponsavel;

    private String cpfCnpjResponsavel;

    private String tipoPessoaResponsavel;

    private String nomeResponsavel;

    private String numeroDocViagemResponsavel;

    private String tipoDocResponsavel;

    private String paisOrigemResponsavel;

    private String organismoInternacionalResponsavel;

    private String numeroRegistroPessoaJuridicaResponsavel;

    // Depositante

    private Boolean estrangeiroDepositante;

    private String cpfCnpjDepositante;

    private String tipoPessoaDepositante;

    private String nomeDepositante;

    private String numeroDocViagemDepositante;

    private String tipoDocDepositante;

    private String paisOrigemDepositante;

    private String organismoInternacionalDepositante;

    private String numeroRegistroPessoaJuridicaDepositante;

    // Portador

    private Boolean estrangeiroPortador;

    private String cpfCnpjPortador;

    private String nomePortador;

    private String numeroDocViagemPortador;

    private String tipoDocPortador;

    private String paisOrigemPortador;

    private String organismoInternacionalPortador;

    // Dados da Transação

    private Boolean recusaCliente;

    private String origemRecurso;

    private String finalidadeSaque;

    private Long nsuTransacao;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<TransacaoDTO> transacoes = new ArrayList<TransacaoDTO>();

}

package br.com.brb.cix.domain.model.parametro;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametroRepository extends JpaRepository<Parametro, Long> {
	
	Parametro findByCodigo(Long codigo);
	
}

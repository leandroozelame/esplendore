package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.enums.EnumTipoBoleto;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TituloCobrancaDTO extends ContaTipoDTO{
    private EnumFormaMovimentacao formaMovimentacao;
    private Long codigoTransacao;
    private BigDecimal valorTotal;
    private BigDecimal valorDocumento;
    private BigDecimal valorDescontos;
    private BigDecimal valorMulta;
    private BigDecimal valorOutrosAcrescimos;
    private BigDecimal valorDeducoes;
    private BigDecimal valorJuros;
    private Date dataVencimento;
    private String nomeBeneficiario;
    private String cpfCnpjBeneficiario;
    private String nomePagador;
    private String cpfCnpjPagador;
    private String tpPessoaPagador;
    private String codigoBarras;
    private String linhaDigitavel;
    private Integer tipoCaptura;
    private String descricaoTipoCaptura;
    private Long fichaContabil; 
    private String  numeroDocumento;
    private Date dataExpedicao;
    private String telefone;
    private Integer numeroBanco;
    private String nomePortador;
    private String cpfPortador;
    private Integer ordemTitularConta;
	private Long numeroTransacao;
    
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Integer numeroCheque;
    private Long numeroContaCheque;
    private String cmc7;

    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long agencia;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Long conta;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private EnumTipoConta tipoConta;

    private String cpfCnpjTitularConta;
    private String tipoPessoaTitularConta;
    private EnumTipoBoleto tipoBoleto;

    private Integer idAlvara;
    private BigDecimal valorAlvara;
    private String nomeBeneficiarioAlvara;
    private Long cpfCnpj;
    private String tipoPessoa;
    private Integer tpPessoaSigla;
    private String nomeTribunal;
    private String cnpjTribunal;
    private String cpfCnpjPortadorPLD;
    private String nomePortadorPLD;
    private String tpPessoaPortadorPLD;

}


package br.com.brb.cix.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

public class ParametroCanalDTO implements Serializable {
    private static final long serialVersionUID = 1L;

    @Getter
    @Setter
    private Long id;

    @Getter
    @Setter
    private Integer numeroCanal;

    @Getter
    @Setter
    private Integer codigoSecao;

    @Getter
    @Setter
    private String secao;

    @Getter
    @Setter
    private String parametro;

    @Getter
    @Setter
    private String valorParametro;

    @Getter
    @Setter
    private String descricaoParametro;

    @Getter
    @Setter
    private Character editavel;

    public ParametroCanalDTO(Integer codigoSecao, String secao) {
        this.codigoSecao = codigoSecao;
        this.secao = secao;
    }

    public ParametroCanalDTO(String parametro, Integer numeroCanal) {
        this.numeroCanal = numeroCanal;
        this.parametro = parametro;
    }

    public ParametroCanalDTO() {
    }
}
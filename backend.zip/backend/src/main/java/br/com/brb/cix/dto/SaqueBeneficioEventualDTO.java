package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u654764
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaqueBeneficioEventualDTO extends AbstractDTO {
    private Long codigoTransacao;
    private EnumFormaMovimentacao formaMovimentacao;
    private String cpfBeneficiario;
    private String codigoDeSegurancaBeneficiario;
    private Integer nrProgramaSocial;
    private Integer tctCod;
    private boolean gaveta;
    @LogValorTransacao
    private BigDecimal valorTransacao = BigDecimal.ZERO;
    private PendenciaDTO pendencia;
}
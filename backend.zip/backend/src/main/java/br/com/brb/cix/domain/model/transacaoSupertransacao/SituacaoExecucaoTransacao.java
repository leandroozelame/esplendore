package br.com.brb.cix.domain.model.transacaoSupertransacao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_SITUACAO_TRANSACAO_EXECUCAO")
public class SituacaoExecucaoTransacao  {

	private static final long serialVersionUID = -8024172692058053387L;

	@Id
    @Column(name = "CD_SITUACAO_TRANSACAO_EXECUCAO")
    private Integer codigo;

    @Column(name = "NO_SITUACAO_TRANSACAO_EXECUCAO")
    private String descricao;
}

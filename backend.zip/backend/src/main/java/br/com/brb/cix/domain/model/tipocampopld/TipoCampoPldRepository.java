package br.com.brb.cix.domain.model.tipocampopld;


import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoCampoPldRepository extends JpaRepository<TipoCampoPld, Long> {
    
    boolean existsByCodigo(Long codigo);

    TipoCampoPld findByCodigo(Long codigo);

    TipoCampoPld findByCodigoAndNome(Long codigo, String nome);
    
}

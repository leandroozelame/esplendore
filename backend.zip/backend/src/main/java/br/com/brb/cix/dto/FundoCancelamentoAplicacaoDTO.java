package br.com.brb.cix.dto;

import br.com.brb.cix.ws.consulta.dto.FundoCancelamentoAplicacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FundoCancelamentoAplicacaoDTO extends FundoCancelamentoAplicacao {
    private String descricaoCanal;
}
package br.com.brb.cix.domain.model.parametropld;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.domain.model.tipocampopld.TipoCampoPld;
import br.com.brb.cix.util.SimNaoConverter;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TB_PARAMETRO_PLD")
public class ParametroPld  {
    private static final long serialVersionUID = 1L;
    @Id
    @SequenceGenerator(name = "parametro_pld_sequence", sequenceName = "SQ_PARAMETRO_PLD", allocationSize = 1)
    @GeneratedValue(generator = "parametro_pld_sequence")
    @Column(name = "SQ_PARAMETRO_PLD")
    private Long codigo;
    
    @Column(name = "CD_MODULO")
    private Integer modulo;
    
    @JsonBackReference(value = "funcionalidade")
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE", nullable = true)
    private Funcionalidade funcionalidade;
    
    @JsonBackReference(value = "formaPagamento")
    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO", referencedColumnName = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;
    
    @Column(name = "VL_PLD")
    private BigDecimal valor;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_HABILITADO")
    private Boolean habilitado;
    
    @JsonManagedReference
    @ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "TB_PARAMETRO_TIPO_CAMPO_PLD", 
        joinColumns = @JoinColumn(name = "SQ_PARAMETRO_PLD", referencedColumnName = "SQ_PARAMETRO_PLD"), 
        inverseJoinColumns = @JoinColumn(name = "SQ_TIPO_CAMPO_PLD", referencedColumnName = "SQ_TIPO_CAMPO_PLD"))
    private List<TipoCampoPld> camposPld;
}

package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author u654764
 *
 */
@AllArgsConstructor
@Getter
public enum EnumTipoDepositoConta implements EnumDominio {
    DEPOSITO_ENVELOPE(1017,"Envelope"),
    DEPOSITO_IDENTIFICADO(1016,"Identificado"), 
    DEPOSITO_CONTA_CORRENTE(1015,"Conta Corrente"), 
    DEPOSITO_POUPANCA_INTEGRADA(2015,"Poupança/Integrada"), 
    DEPOSITO_CHEQUE_LIBERADO(1025,"Cheque Liberado"), 
    DEPOSITO_CHEQUE_LIQUIDADO(1020,"Cheque Liquidado");
    
    
    private Integer codigo;
    private String descricao;

    static List<EnumTipoDepositoConta> listaEnum = Arrays.asList(EnumTipoDepositoConta.values());
    private static final Map<Integer, EnumTipoDepositoConta> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

    /**
     * @param codigo
     * @return
     */
    @JsonCreator
    public static EnumTipoDepositoConta get(int codigo) {
        return MAP.get(codigo);
    }

    /**
     * @return
     */
    public static List<Object> listarEnumTipoDeposito() {
        return listaEnum.stream().map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

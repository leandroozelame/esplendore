package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.List;

import br.com.brb.cix.ws.autorizacao.dto.ColetaDocumento;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ColetaDocumentoDTO {
	private List<ColetaDocumento> documentos;
	private BigDecimal valorTotal;
}
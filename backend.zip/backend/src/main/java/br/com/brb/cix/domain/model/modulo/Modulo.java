package br.com.brb.cix.domain.model.modulo;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Getter
@Setter
@Table(name = "TB_MODULO")
public class Modulo  {
	private static final long serialVersionUID = -2933794018592411809L;
	@Id
    @Column(name = "CD_MODULO")
    private Long codigo;
    @Column(name = "NO_MODULO")
    private String descricao;
    @Column(name = "ST_ATIVO")
    private boolean ativo;
}

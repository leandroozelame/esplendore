package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class InformacoesClienteContaDTO extends AbstractDTO {
    private Long codigoCliente;
    private Long cpfCnpj;
    private Date dataNascimento;
    private String nomeClienteEmpresa;
    private Integer ordemTitular;
}
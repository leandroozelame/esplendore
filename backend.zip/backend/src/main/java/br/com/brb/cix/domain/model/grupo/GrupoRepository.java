package br.com.brb.cix.domain.model.grupo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GrupoRepository extends JpaRepository<Grupo, Long> {

    static final String SQL_NATIVE_BUSCA_GRUPOS_DISSOCIADOS_PERFIL = "SELECT G.* FROM {h-schema}VW_GRUPO G "
            + "INNER JOIN {h-schema}TB_PERFIL_GRUPO PG ON PG.CD_GRPCOD = G.GRPCOD "
            + "INNER JOIN {h-schema}TB_PERFIL P ON P.SQ_CODIGO = PG.SQ_CODIGO "
            + "WHERE PG.SQ_CODIGO <> ?1 and P.CD_MODULO = ?2 ";

    @Query(nativeQuery = true, value = SQL_NATIVE_BUSCA_GRUPOS_DISSOCIADOS_PERFIL)
    List<Grupo> buscarGruposNaoAssociadosA(Long codigoPerfil, Integer codigoModulo);

    Grupo findByCodigo(Long codigo);
}

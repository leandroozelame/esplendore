package br.com.brb.cix.domain.model.limitesaldocaixa;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import br.com.brb.cix.dto.LimiteSaldoEmCaixaDTO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LimiteSaldoEmCaixaRepository extends JpaRepository<LimiteSaldoEmCaixa, Long> {
    List<LimiteSaldoEmCaixaDTO> findByCodigoModulo(Integer modulo);
    
    @Query("select l from LimiteSaldoEmCaixa l"
            + " where l.codigoModulo = :codigoModulo"
            + " and l.codigoUnidade = :codigoUnidade")
    List<LimiteSaldoEmCaixaDTO> localizarPorModuloUnidade(@Param("codigoModulo") Integer modulo, @Param("codigoUnidade") Long unidade);
    
    boolean existsByCodigoModuloAndCodigoUnidade(Integer modulo, Long unidade);
    
    @Query("select l from LimiteSaldoEmCaixa l"
            + " where l.codigoModulo = :codigoModulo"
            + " and (l.codigoUnidade = :codigoUnidade or l.codigoUnidade is :codigoUnidade)")
    LimiteSaldoEmCaixa getPorModuloUnidade(@Param("codigoModulo") Integer modulo, @Param("codigoUnidade") Long unidade);
    
    @Query("select l from LimiteSaldoEmCaixa l"
            + " where l.codigo = :codigo")
    LimiteSaldoEmCaixaDTO getPorModul(@Param("codigo") Long codigo);
    LimiteSaldoEmCaixa findByCodigoModuloAndCodigoUnidade(Integer codigoModulo, Long codigoUnidade);
   LimiteSaldoEmCaixa findByCodigo(Long codigo);
//    Long deleteByCodigo(Long codigo);
}

package br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm;


import java.sql.Clob;

import br.com.brb.cix.dto.AbstractDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsultaOnlineBobinaCaixaAdm extends AbstractDTO{
    
    
    //private Bobina bobina;
	private Long sqBobina;
	private Clob textoBobina;
	private Long matriculaOperador;
    private String nrTerminal; 
    private String oprNom;
    
	public ConsultaOnlineBobinaCaixaAdm(Long sqBobina) {
		super();
		this.sqBobina = sqBobina;
	}
    
}
package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.regra.Regra;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Slf4j
public class CriterioValorTransacao implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Valor da Transação";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return BigDecimal.ZERO.equals(regra.getValorTransacao()); // Para o valor da transação, ZERO é equivalente a INDIFERENTE
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        BigDecimal valorRegra = regra.getValorTransacao();
        BigDecimal valorTransacao = dadosTransacao.getValor();
        log.debug("valorRegra: {}, valorTransacao: {}", valorRegra, valorTransacao);

        return !valorRegra.equals(BigDecimal.ZERO) && valorTransacao != null && valorTransacao.compareTo(valorRegra) >= 0;
    }
}

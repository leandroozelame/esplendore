package br.com.brb.cix.domain.model.funcionalidadeformapagamento;

import br.com.brb.cix.dto.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * @author u653865
 *
 */
public interface FuncionalidadeFormaPagamentoRepositoryCustom {

    List<ConsultaFormaPagamentoDTO> listarParametroValorMaximo(BigDecimal valorPagamento, Integer codigoFuncionalidade, Integer codigoUnidade, Integer codigoTerminal);

    Boolean exigePld(Integer codigoFuncionalidade, Integer codigoFormaPagamento, BigDecimal valorPld);

    ConsultaSuperTransacaoDTO findByFuncionalidadeAndFormaPagamentoWithSuperTransacao(Integer codigoModulo, Integer codigoFuncionalidade, Integer codigoFormaPagamento);
    
    List<ConsultaFuncionalidadeFormaDTO> buscarParametros(ConsultaFormaPagamentoFiltroDTO consultaFormaPagamentoFiltroDTO);

    BigDecimal buscarLimitePorTransacaoFormaPagamento(Long codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento);

    BigDecimal buscarLimiteTransacaoPorTerminalUnidadeFuncionalidade(Integer codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento);

    List<FuncionalidadeFormaPagamentoDTO> buscarLimiteTransacaoPorFuncionalidade(Integer codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento);
}

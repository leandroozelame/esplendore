package br.com.brb.cix.domain.model.funcionalidadeformapagamento;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FuncionalidadeFormaPagamentoRepository extends JpaRepository<FuncionalidadeFormaPagamento, Long> {
    boolean existsByFuncionalidadeCodigoAndUnidadeAndTerminalCodigo(Long idFuncionalidade, Integer unidade, Long idTerminal);

    FuncionalidadeFormaPagamento findByFuncionalidadeCodigoAndUnidadeAndTerminalCodigoAndFormaPagamentoCodigo(Long codigoFuncionalidade, Integer codigoUnidade, Long codigoTerminal, Long codigoFormaPagamento);

    List<FuncionalidadeFormaPagamento> findByFuncionalidadeCodigoAndFormaPagamentoCodigo(Long codigoFuncionalidade, Long codigoFormaPagamento);

    List<FuncionalidadeFormaPagamento> findByFuncionalidadeCodigo(Long condigoFuncionalidade);

    FuncionalidadeFormaPagamento findByCodigo(Long codigo);

    List<FuncionalidadeFormaPagamento> findByFuncionalidadeNumeroTransacaoAndFuncionalidadeModuloAndAceitaFormaPagamentoAndUnidadeAndTerminalIpTerminal
    	(Integer numeroTransacao, Integer modulo, Boolean aceitaFormaPagamento, Integer codigoUnidade, String ipTerminal);

    @Query(value = " SELECT FF FROM FuncionalidadeFormaPagamento FF   where FF.modulo =:modulo")
    List<FuncionalidadeFormaPagamento> listaFuncionalidadefindByModulo(@Param("modulo") Integer modulo);

    @Query(value = " SELECT FF FROM  FuncionalidadeFormaPagamento FF where FF.formaPagamento.codigo = :cdFormaPagamento and FF.modulo= :modulo")
    List<FuncionalidadeFormaPagamento> listarFuncionalidadefindByModuloByFormaPagamento(@Param("cdFormaPagamento") Long cdFormaPagamento,@Param("modulo") Integer modulo);

    @Query(value = " SELECT FF FROM  FuncionalidadeFormaPagamento FF where  FF.modulo= :modulo and FF.funcionalidade.codigo= :cdFuncionalidade")
    List<FuncionalidadeFormaPagamento> listarFuncionalidadefindByFuncionalidade(@Param("modulo") Integer modulo,@Param("cdFuncionalidade") Long cdFuncionalidade);

    @Query(value = " SELECT FF FROM FuncionalidadeFormaPagamento FF   where FF.funcionalidade.codigo =:cdFuncionalidade and FF.formaPagamento.codigo =:cdFormaPagaento")
    List<FuncionalidadeFormaPagamento> listarFormaPagamentoByFuncionalidadeFormaPagamento(@Param("cdFuncionalidade") Long cdFuncionalidade , @Param("cdFormaPagaento") Long cdFormaPagaento);
}

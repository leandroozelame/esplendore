package br.com.brb.cix.domain.model.grupocnp;

import br.com.brb.cix.domain.model.unidade.Unidade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BloqueioCorrespondenteRepository extends JpaRepository<BloqueioCorrespondente, Long>{

    BloqueioCorrespondente findByUnidade(Unidade unidade);
    
}

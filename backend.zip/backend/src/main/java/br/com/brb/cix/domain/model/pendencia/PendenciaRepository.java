package br.com.brb.cix.domain.model.pendencia;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface PendenciaRepository extends JpaRepository<Pendencia, Long> {
    List<Pendencia> findByMatriculaAndSituacaoInOrderByDataCadastroDesc(String matricula, Collection<Character> situacoes);

    @Query(value = "SELECT UNIQUE p.* FROM {h-schema}TB_PENDENCIA_AUTORIZACAO p, {h-schema}TB_REGRA r, {h-schema}TB_FUNCIONALIDADE f "
            + "WHERE (p.SQ_REGRA = r.SQ_REGRA AND r.SQ_FUNCIONALIDADE = f.SQ_FUNCIONALIDADE AND f.CD_MODULO = ?1) "
            + "OR p.SQ_REGRA IS NULL "
            + "ORDER BY p.DT_CADASTRO_PENDENCIA DESC", nativeQuery = true)
    List<Pendencia> findByCanal(Integer canal);
    
    @Query(value = "SELECT UNIQUE PENDENCIA.*"
            + "  FROM {h-schema}TB_PENDENCIA_AUTORIZACAO PENDENCIA"
            + "  JOIN {h-schema}TB_REGRA REGRA"
            + "    ON PENDENCIA.SQ_REGRA = REGRA.SQ_REGRA"
            + "  JOIN {h-schema}TB_FUNCIONALIDADE FUNCIONALIDADE"
            + "    ON REGRA.SQ_FUNCIONALIDADE = FUNCIONALIDADE.SQ_FUNCIONALIDADE"
            + " WHERE FUNCIONALIDADE.CD_MODULO = ?1"
            + "   AND TRUNC(PENDENCIA.DT_CADASTRO_PENDENCIA) = TRUNC(SYSDATE)"
            + " ORDER BY PENDENCIA.DT_CADASTRO_PENDENCIA DESC", nativeQuery = true)
    List<Pendencia> findByCanalAndDataCadastroCorrente(Integer canal);

    @Query(value = "SELECT UNIQUE p.* " +
                "FROM {h-schema}TB_PENDENCIA_AUTORIZACAO p " +
                "LEFT JOIN {h-schema}TB_REGRA r ON p.SQ_REGRA = r.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_PRI pri ON r.SQ_REGRA = pri.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_SEC sec ON r.SQ_REGRA = sec.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_ALT aut ON r.SQ_REGRA = aut.SQ_REGRA " +
                "WHERE p.OPRMAT <> ?1 AND (p.NR_MATRICULA_ULT_AUTORIZADOR <> ?1 OR p.NR_MATRICULA_ULT_AUTORIZADOR is null) " +
                "AND (pri.GRPCOD = ?2 or sec.GRPCOD = ?2 or aut.GRPCOD = ?2 ) " +
                "AND p.ST_PENDENCIA_AUTORIZACAO in ('1', '2') " +
                "ORDER BY p.DT_CADASTRO_PENDENCIA DESC ", nativeQuery = true)
    List<Pendencia> findAutorizacaoByMatriculaAndGrupo(String matricula, Long grupo);

    @Query(value = "SELECT UNIQUE p.* " +
                "FROM {h-schema}TB_PENDENCIA_AUTORIZACAO p " +
                "LEFT JOIN {h-schema}TB_REGRA r ON p.SQ_REGRA = r.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_PRI pri ON r.SQ_REGRA = pri.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_SEC sec ON r.SQ_REGRA = sec.SQ_REGRA " +
                "LEFT JOIN {h-schema}TB_REGRA_GRUPO_AUT_ALT aut ON r.SQ_REGRA = aut.SQ_REGRA " +
                "WHERE p.OPRMAT <> ?1 AND (p.NR_MATRICULA_ULT_AUTORIZADOR <> ?1 OR p.NR_MATRICULA_ULT_AUTORIZADOR is null) " +
                "AND (pri.GRPCOD = ?2 or sec.GRPCOD = ?2 or aut.GRPCOD = ?2 ) " +
                "AND p.ST_PENDENCIA_AUTORIZACAO in ('1', '2') " +
                "AND p.UNDCOD = ?3 " +
    		"ORDER BY p.DT_CADASTRO_PENDENCIA DESC", nativeQuery = true)
    List<Pendencia> findAutorizacaoByMatriculaAndGrupoAndUnidade(String matricula, Long grupo, Long codigoUnidade);

    List<Pendencia> findByUnidadeOrderByDataCadastroDesc(Integer unidade);
    
    @Query(value="SELECT UNIQUE PENDENCIA.*"
            + "  FROM {h-schema}TB_PENDENCIA_AUTORIZACAO PENDENCIA"
            + "  JOIN {h-schema}TB_REGRA REGRA"
            + "    ON PENDENCIA.SQ_REGRA = REGRA.SQ_REGRA"
            + "  JOIN {h-schema}TB_FUNCIONALIDADE FUNCIONALIDADE"
            + "    ON REGRA.SQ_FUNCIONALIDADE = FUNCIONALIDADE.SQ_FUNCIONALIDADE"
            + " WHERE PENDENCIA.UNDCOD = ?1"
            + "   AND TRUNC(PENDENCIA.DT_CADASTRO_PENDENCIA) = TRUNC(SYSDATE)"
            + " ORDER BY PENDENCIA.DT_CADASTRO_PENDENCIA DESC", nativeQuery = true)
    List<Pendencia> findByUnidadeAndDataCadastroCorrente(Integer unidade);

    List<Pendencia> findByRegra_Codigo(Long codigoRegra);

    Pendencia findByCodigo(Long codigo);

    @SuppressWarnings("unchecked")
    Pendencia save(Pendencia pendencia);

    @Transactional
    List<Pendencia> deleteByCodigo(Long codigo);
}

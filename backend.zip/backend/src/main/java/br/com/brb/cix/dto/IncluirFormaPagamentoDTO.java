package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
public class IncluirFormaPagamentoDTO {
    @NotNull
    private Boolean atualizaParametrosExistentes;
    @NotNull
    private Integer codigoModulo;
    @NotNull
    private Long codigoFuncionalidade;
    private Integer codigoUnidade;
    private Long codigoTerminal;
    private List<ItemFormaPagamentoDTO> formasPagamento;
}
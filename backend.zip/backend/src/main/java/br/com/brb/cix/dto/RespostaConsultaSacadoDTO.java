package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.domain.model.enums.EnumSituacaoSacadoBrbGTE;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.ws.consulta.dto.TitularPessoa;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaConsultaSacadoDTO extends AbstractDTO {
    private List<AgregadoDTO> agregados;
    private Long cpfCnpj;
    private String nome;
    private EnumSituacaoSacadoBrbGTE situacao;
    private String termo;
    private EnumTipoPessoa tipoPessoa;
    private List<TitularPessoa> titulares;
}
package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
public class PendenciaLogDTO {
    private Long codigo;
    private String situacao;
    private Long codigoRegra;
    private Date dataCadastro;
    private Date dataAtualizacao;
    private BigDecimal valor;
    private String descricao;

    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private Long contaOrigem;

    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private Long contaDestino;

    private Integer terminal;
    private String matricula;
    private Integer unidade;
    private String motivoRejeicao;

    public PendenciaLogDTO() {
        super();
    }
}
package br.com.brb.cix.domain.model.enviocreditomalote;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvioCreditoMaloteEmpresarialRepository extends JpaRepository<EnvioCreditoMaloteEmpresarial, Long> {
    
    @Query(nativeQuery = true, value = "SELECT cm.* " 
        + "FROM {h-schema}TB_ENVIO_CREDITO_MALOTE cm " 
        + "INNER JOIN {h-schema}TB_MALOTE_EMPRESARIAL me ON cm.SQ_ENVIO_CREDITO_MALOTE = me.SQ_ENVIO_CREDITO_MALOTE " 
        + "INNER JOIN {h-schema}TB_TRANSACAO_MALOTE tm ON me.SQ_MALOTE_EMPRESARIAL = tm.SQ_MALOTE_EMPRESARIAL " 
        + "WHERE tm.NR_NSU = :nsuTransacao " ) 
    EnvioCreditoMaloteEmpresarial buscarCreditoPorNsuTransacao(@Param("nsuTransacao") Long nrNsuTransacaoMalote);

}
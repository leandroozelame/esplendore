package br.com.brb.cix.domain.model.terminal.excessao;

public class TerminalNaoEncontradoException extends Exception {

    private static final long serialVersionUID = 1L;

    public TerminalNaoEncontradoException() {
    }

    public TerminalNaoEncontradoException(String message) {
        super(message);
    }

}

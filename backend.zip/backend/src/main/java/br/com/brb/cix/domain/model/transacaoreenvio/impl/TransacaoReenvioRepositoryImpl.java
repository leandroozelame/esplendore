/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.transacaoreenvio.impl;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.Getter;

/**
 *
 * @author u842773
 */
@Repository
public class TransacaoReenvioRepositoryImpl {
    
    @Getter
    private final EntityManager entityManager;

    @Autowired
    public TransacaoReenvioRepositoryImpl(EntityManager manager) {
        entityManager = manager;
    }
}

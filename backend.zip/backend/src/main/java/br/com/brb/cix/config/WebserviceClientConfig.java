package br.com.brb.cix.config;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.reflections.Reflections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.saaj.SaajSoapMessageFactory;

import com.sun.xml.messaging.saaj.soap.ver1_1.SOAPMessageFactory1_1Impl;

import br.com.brb.cix.domain.model.parametrocanal.ParametroCanalRepository;
import br.com.brb.cix.ws.CixWebServiceClientInterceptor;
import br.com.brb.cix.ws.CixWebServiceClientInterceptor.EnumTipoWebservice;
import br.com.brb.cix.ws.log.EstLogBase;
import la.foton.infra.util.TextLayout;

@Configuration
public class WebserviceClientConfig {

    @Value("${cix.mock.banklink:#{null}}")
    private String MOCK_HOST_BANKLINK;
    private static final String PARAMETRO_HOST_BANKLINK = "HOST_BANKLINK";
    private static final String AUTORIZACAO_WSDL = "/AutorizadorFacadeBean/AutorizadorFacadeBean?WSDL";
    private static final String CONSULTA_WSDL = "/ConsultaFacadeBean/ConsultaFacadeBean?WSDL";
    private static final String LOG_WSDL = "/EnviaLogsFacadeBean/EnviaLogsFacadeBeanService?WSDL";

    @Autowired
    private ParametroCanalRepository parametroRepository;

    @Bean
    public Jaxb2Marshaller jaxb2MarshallerConsulta() {
        Jaxb2Marshaller jaxbMarshaller = new Jaxb2Marshaller();
        Map<String, Object> map = new HashMap<String, Object>();

        jaxbMarshaller.setContextPath("br.com.brb.cix.ws.consulta.dto");
        map.put("jaxb.formatted.output", true);
        jaxbMarshaller.setMarshallerProperties(map);
        return jaxbMarshaller;
    }

    @Bean
    public WebServiceTemplate consultaCliente() {
        String urlBanklink = getUrlBanklink();

        WebServiceTemplate webServiceTemplate = new WebServiceTemplate(new SaajSoapMessageFactory(new SOAPMessageFactory1_1Impl()));
        webServiceTemplate.setMarshaller(jaxb2MarshallerConsulta());
        webServiceTemplate.setUnmarshaller(jaxb2MarshallerConsulta());
        webServiceTemplate.setDefaultUri(urlBanklink + CONSULTA_WSDL);
        webServiceTemplate.setInterceptors(new ClientInterceptor[]{new CixWebServiceClientInterceptor(EnumTipoWebservice.CONSULTA)});
        return webServiceTemplate;
    }

    @Bean
    public Jaxb2Marshaller jaxb2MarshallerAutorizacao() {
        Jaxb2Marshaller jaxbMarshaller = new Jaxb2Marshaller();
        Map<String, Object> map = new HashMap<String, Object>();

        jaxbMarshaller.setContextPath("br.com.brb.cix.ws.autorizacao.dto");
        map.put("jaxb.formatted.output", true);
        jaxbMarshaller.setMarshallerProperties(map);
        return jaxbMarshaller;
    }

    @Bean
    public WebServiceTemplate autorizacaoCliente() {
        String urlBanklink = getUrlBanklink();

        WebServiceTemplate webServiceTemplate = new WebServiceTemplate(new SaajSoapMessageFactory(new SOAPMessageFactory1_1Impl()));
        webServiceTemplate.setMarshaller(jaxb2MarshallerAutorizacao());
        webServiceTemplate.setUnmarshaller(jaxb2MarshallerAutorizacao());
        webServiceTemplate.setDefaultUri(urlBanklink + AUTORIZACAO_WSDL);
        webServiceTemplate.setInterceptors(new ClientInterceptor[]{new CixWebServiceClientInterceptor(EnumTipoWebservice.AUTORIZACAO)});
        return webServiceTemplate;
    }

    @Bean
    public Jaxb2Marshaller jaxb2MarshallerLog() {
        Jaxb2Marshaller jaxbMarshaller = new Jaxb2Marshaller();
        Map<String, Object> map = new HashMap<String, Object>();

        jaxbMarshaller.setContextPaths("br.com.brb.cix.ws.log.dto");
        map.put("jaxb.formatted.output", true);
        jaxbMarshaller.setMarshallerProperties(map);
        return jaxbMarshaller;
    }

    @Bean
    public WebServiceTemplate logCliente() {
        String urlBanklink = getUrlBanklink();
        WebServiceTemplate webServiceTemplate = new WebServiceTemplate(new SaajSoapMessageFactory(new SOAPMessageFactory1_1Impl()));

        webServiceTemplate.setMarshaller(jaxb2MarshallerLog());
        webServiceTemplate.setUnmarshaller(jaxb2MarshallerLog());
        webServiceTemplate.setDefaultUri(urlBanklink + LOG_WSDL);
        webServiceTemplate.setInterceptors(new ClientInterceptor[]{new CixWebServiceClientInterceptor(EnumTipoWebservice.LOG)});
        return webServiceTemplate;
    }

    @Bean
    public XStreamMarshaller xStreamMarshaller() {
        XStreamMarshaller xstreamMarshaller = new XStreamMarshaller();
        Reflections reflections = new Reflections("la.foton.brb.banklink.libfdk");
        Map<String, Class<?>> aliasesByType = new HashMap<>();

        reflections.getSubTypesOf(la.foton.componente.common.Log.class).stream().forEach(clazz -> {
            aliasesByType.put(clazz.getSimpleName(), clazz);
        });

        Map<Class<?>, String> omittedFields = new HashMap<>();
        StringBuilder camposOmitidosEstLogBase = new StringBuilder();

        for (Field att : EstLogBase.class.getDeclaredFields()) {
            camposOmitidosEstLogBase.append(att.getName()).append(",");
        }
        omittedFields.put(EstLogBase.class, camposOmitidosEstLogBase.deleteCharAt(camposOmitidosEstLogBase.length() - 1).toString());

        StringBuilder camposOmitidosTextLayout = new StringBuilder();

        for (Field att : TextLayout.class.getDeclaredFields()) {
            camposOmitidosTextLayout.append(att.getName()).append(",");
        }
        omittedFields.put(TextLayout.class, camposOmitidosTextLayout.deleteCharAt(camposOmitidosTextLayout.length() - 1).toString());
        xstreamMarshaller.setAliases(aliasesByType);
        xstreamMarshaller.setAliasesByType(aliasesByType);
        xstreamMarshaller.setOmittedFields(omittedFields);
        return xstreamMarshaller;
    }

    private String getUrlBanklink() {

        if (MOCK_HOST_BANKLINK != null) {
            return MOCK_HOST_BANKLINK;
        } else {
            return parametroRepository.findByParametro(PARAMETRO_HOST_BANKLINK).getValorParametro();
        }
    }
}
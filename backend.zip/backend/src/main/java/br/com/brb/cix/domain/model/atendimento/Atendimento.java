/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.atendimento;

import br.com.brb.cix.domain.model.atendimentotransacao.AtendimentoTransacao;
import br.com.brb.cix.domain.model.informacaocaixa.*;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@Entity
@Getter
@Setter
@Table(name = "TB_ATENDIMENTO")
public class Atendimento {
   
    @SequenceGenerator(name = "atendimento_sequence", sequenceName = "SQ_ATENDIMENTO", allocationSize = 1)
    @GeneratedValue(generator = "atendimento_sequence")
    @Column(name = "SQ_ATENDIMENTO")
    @Id
    private Long codigo;
    
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_INFO_CAIXA", nullable = false)
    private InformacaoCaixa informacaoCaixa;
    
    @Column(name = "NO_CLIENTE")
    private String nomeCliente;
    
    @Column(name = "DS_CPF")
    private String cpfCliente;
    
    @Column(name = "NR_TELEFONE")
    private Long telefoneCliente;
    
    @Column(name = "DT_INICIO_ATENDIMENTO")
    private Date dataInicio;    

    @Column(name = "DT_FIM_ATENDIMENTO")
    private Date dataFim;        
    
    @OneToMany(mappedBy = "atendimento")
    private List<AtendimentoTransacao> atendimentos;
}

package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumValorRegraTipoPessoa implements EnumDominio {
    PESSOA_FISICA('0', "Pessoa Física"),
    PESSOA_JURIDICA('1', "Pessoa Jurídica"),
    GOVERNO('2', "Governo"),
    INDIFERENTE('9', "Indiferente");

    private static final Map<Character, EnumValorRegraTipoPessoa> MAP = new HashMap<>();

    @Getter
    private Character codigo;
    @Getter
    private String descricao;

    static {
        for (EnumValorRegraTipoPessoa e : EnumValorRegraTipoPessoa.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumValorRegraTipoPessoa get(Character codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumValorRegraTipoPessoa criaEnum(Object tipo) {
        EnumValorRegraTipoPessoa retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumValorRegraTipoPessoa criaEnumString(String descricao) {
        EnumValorRegraTipoPessoa retorno = null;
        Iterator<Map.Entry<Character, EnumValorRegraTipoPessoa>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Character, EnumValorRegraTipoPessoa> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao) || par.getKey().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

package br.com.brb.cix.enums;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumAutorizavel implements EnumDominio {
    NAO_AUTORIZAVEL('0'),
    AUTORIZAVEL('1');

    @Getter
    private final Character codigo;
}

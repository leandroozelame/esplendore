package br.com.brb.cix.domain.model.informacaocaixa;

import br.com.brb.cix.domain.model.terminal.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InformacaoCaixaRepository extends JpaRepository<InformacaoCaixa, Long> {
    InformacaoCaixa findByCodigo(Long codigo);
    
    InformacaoCaixa findByMatriculaOperador(Long matriculaOperador);
    
    InformacaoCaixa findByMatriculaOperadorAndTerminal(Long matriculaOperador, Terminal terminal);
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoMovimentacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.enums.EnumTipoTransacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaqueDTO extends AbstractDTO {

    private Long agencia;
    private Long conta;
    private EnumTipoConta tipoConta;
    private String nomeTitular;
    private Long cpfCnpjTitular;
    private Integer ordemTitularConta;
    private EnumTipoMovimentacao tipoMovimentacao;
    private BigDecimal saldoDisponivel;
    private EnumTipoTransacao tipoTransacao;
    private Long codigoTransacao;
    private EnumFormaMovimentacao formaMovimentacao;
    private Integer ptaOrigemConta;
    @LogValorTransacao
    private BigDecimal valorTransacao;
    private boolean gaveta;
    private PendenciaDTO pendencia;
}

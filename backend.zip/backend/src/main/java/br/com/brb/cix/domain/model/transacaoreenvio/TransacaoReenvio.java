package br.com.brb.cix.domain.model.transacaoreenvio;

import br.com.brb.cix.auditoria.EnumCanalConverter;
import br.com.brb.cix.enums.EnumCanal;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import javax.persistence.Convert;
import javax.persistence.FetchType;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

/*
Tabela que abrigará registro de transações para repescagem, caso houver algum problema com o autorizador/banklink

TB_TRANSACAO_REENVIO

Situação da transação: 
0 - Criado / 
1 - Enviado Autorização/ 
2 - Autorizado pelo BLK/ 
3 - Enviado Confirmação
4 - Confirmada pelo Canal/ 
5 - Log Financeiro Enviado / 
6 - Log Confirmado pelo BLK / 
7 - Gaveta Alterada/ 
8 - Bobina Alterada / 
91 - Em Reenvio Autorização/ 
93 - Em Reenvio Confirmação/ 
95 - Em Reenvio Log Financeiro/ 
99 - Com Erro
*/

@Entity
@Getter
@Setter
@Table(name = "TB_TRANSACAO_REENVIO")
@IdClass(TransacaoReenvioId.class)
public class TransacaoReenvio  {

    private static final long serialVersionUID = -3407562098053150245L;

    @Id
    @Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;

    @Id
    @Column(name = "NR_NSU_CANAL")
    private Long nsuCanal;
    
    @Column(name = "SQ_TERMINAL")
    private Long terminal;
    
    @Column(name = "CD_MODULO", nullable = true)
    @Convert(converter = EnumCanalConverter.class)
    private EnumCanal nrCanal;
    
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "CD_SITUACAO_TRANSACAO", nullable = false)
    private TransacaoStatus transacaoStatus;
    
    @Column(name = "CD_TRANSACAO")
    private Long codigoTransacao;    
    
    @Column(name = "TX_SOAP_AUTORIZACAO" ,columnDefinition = "clob")
    private String soapAutorizacao;
    
    @Column(name = "TX_SOAP_LOG", columnDefinition = "clob")
    private String soapLog;
    
    @Column(name = "DS_ERRO")
    private String descricaoErro;

}


package br.com.brb.cix.auditoria;

import br.com.brb.cix.auditoria.anotacao.Log;
import br.com.brb.cix.auditoria.anotacao.LogAuditoria;
import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumDominio;
import br.com.brb.cix.enums.EnumFuncionalidade;
import br.com.brb.cix.util.CixUtil;
import br.com.brb.cix.ws.util.ReflectionUtil;
import lombok.extern.slf4j.Slf4j;
import net.vidageek.mirror.dsl.Mirror;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Aspect
@Order(1)
@Component
public class LogAuditoriaAspect {
    @Autowired
    private LogAuditoriaBuilder logAuditoriaBuilder;

    @Pointcut("@annotation(br.com.brb.cix.auditoria.anotacao.LogAuditoria)")
    public void pointcutEntradaAuditoria() {}

    @Pointcut("@annotation(br.com.brb.cix.auditoria.anotacao.LogSaidaAuditoria)")
    public void pointcutSaidaAuditoria() {}

    @Around(value = "pointcutEntradaAuditoria()")
    public Object registraEntradaAuditoria(ProceedingJoinPoint pjp) throws Throwable {
        preencheEntradaAuditoria(pjp);
        return pjp.proceed();
    }

    @AfterThrowing(value = "pointcutEntradaAuditoria()", throwing = "exception")
    public void registraExcecaoEntrada(Exception exception) {
        logAuditoriaBuilder.comExcecao(exception);
    }

    @AfterReturning(value = "pointcutSaidaAuditoria()", returning = "resultado")
    public void registraSaidaAuditoria(JoinPoint joinPoint, Object resultado) throws IOException {
        if (logAuditoriaBuilder.getEnumFuncionalidade() != null) {

            if (!logAuditoriaBuilder.isIgnoraSaida()) {
                logAuditoriaBuilder.adicionaSaida(criaMapaParametrosSaida(resultado));
            }
            logAuditoriaBuilder.cria().executa();
        }
    }

    private void preencheEntradaAuditoria(ProceedingJoinPoint pjp) {
        try {
            LogAuditoria logAuditoria = AnnotationUtils.getAnnotation(((MethodSignature) pjp.getSignature()).getMethod(), LogAuditoria.class);
            EnumFuncionalidade enumFuncionalidade = logAuditoria.value();
            Map<String, Object> mapaParametrosEntrada = null;
            BigDecimal valorTransacao = null;

            if (!logAuditoria.ignoraEntrada()) {
                mapaParametrosEntrada = criaMapaParametrosEntrada(pjp);
                valorTransacao = recuperarValorTransacao(pjp);
            }
            logAuditoriaBuilder.comEnumCanal(logAuditoria.canal()).comEnumFuncionalidade(enumFuncionalidade)
                    .comValorTransacao(valorTransacao).adicionaEntrada(mapaParametrosEntrada)
                    .ignoraEntrada(logAuditoria.ignoraEntrada()).ignoraSaida(logAuditoria.ignoraSaida());
        } catch (Exception e) {
            log.error("preencheEntradaAuditoria()", e);
        }
    }

    /**
     * Cria mapa de parametros a partir do joinpoint utilizando a anotação @Log. Caso argumento do metodo nao contenha a
     * anotacao, sera utilizado como defaul o nome da variavel. Para ignorar um parametro na auditoria, utilizar
     * o @Log(ignora = true)
     */
    private Map<String, Object> criaMapaParametrosEntrada(JoinPoint jp) {
        MethodSignature assinaturaMetodo = (MethodSignature) jp.getSignature();
        Object[] argumentosMetodo = jp.getArgs();
        String[] nomeParametrosMetodo = assinaturaMetodo.getParameterNames();
        List<Log> anotacoesLog = ReflectionUtil.getParameterAnnotations(assinaturaMetodo.getMethod(), Log.class);
        Map<String, Object> mapaEntradaAuditoria = new LinkedHashMap<>();
        
        if (nomeParametrosMetodo != null) {
	        for (int i = 0; i < nomeParametrosMetodo.length; i++) {
	            Object argumento = argumentosMetodo[i];
	            String nomeParametroMetodo = nomeParametrosMetodo[i];
	            Log log = anotacoesLog.get(i);
	
	            if (argumento == null || (log != null && log.ignora())) continue;
	
	            String nomeParametroAuditoria = (log == null) || StringUtils.isEmpty(log.value()) ? nomeParametroMetodo : log.value();
	
	            if (argumento instanceof EnumDominio) {
	                EnumDominio enumDominio = (EnumDominio) argumento;
	                mapaEntradaAuditoria.put(nomeParametroAuditoria, enumDominio.toString());
	                continue;
	            }
	            if (BeanUtils.isSimpleValueType(argumento.getClass())) {
	                mapaEntradaAuditoria.put(nomeParametroAuditoria, argumento);
	                continue;
	            }
	            mapaEntradaAuditoria.put(nomeParametroAuditoria, argumento);
	        }
        }
        return mapaEntradaAuditoria;
    }
    
    /**
     * Cria mapa de parametros de saida a partir do joinpoint. Será aplicado uma formatação
     * genérica aos nomes dos atributos de retorno
     */
    private Map<String, Object> criaMapaParametrosSaida(Object resultado) throws IOException {
        return CixUtil.parseObjetoParaMap(resultado);
    }

    /**
     * Encontra primera ocorrencia da anotacao @LogValor e recupera o valor da transacao
     */
    private BigDecimal recuperarValorTransacao(JoinPoint jp) {
        MethodSignature assinaturaMetodo = (MethodSignature) jp.getSignature();
        Object[] argumentosMetodo = jp.getArgs();
        BigDecimal valorTransacao = null;
        List<LogValorTransacao> anotacoesLogValor = ReflectionUtil.getParameterAnnotations(assinaturaMetodo.getMethod(),LogValorTransacao.class);
        List<Log> anotacoesLog = ReflectionUtil.getParameterAnnotations(assinaturaMetodo.getMethod(), Log.class);
        
        if (anotacoesLogValor != null && !anotacoesLogValor.isEmpty()) {
            for (int i = 0; i < argumentosMetodo.length; i++) {
                Object argumento = argumentosMetodo[i];
                Log log = anotacoesLog.get(i);
                
                if (argumento != null && argumento.getClass().isPrimitive() && anotacoesLogValor.get(i) != null) {
                    valorTransacao = criaBigDecimal(valorTransacao, argumento);
                    break;
                } else if (argumento != null && !argumento.getClass().isPrimitive()) {
                    Field[] annotatedDeclaredFields = ReflectionUtil.getAnnotatedDeclaredFields(argumento.getClass(), LogValorTransacao.class, true);
                    if (annotatedDeclaredFields != null && annotatedDeclaredFields.length > 0) {
                        valorTransacao = criaBigDecimal(valorTransacao, new Mirror().on(argumento).get().field(annotatedDeclaredFields[0]));
                    } else if (log != null && log.ehValorTransacao() && valorTransacao == null){
                        valorTransacao = criaBigDecimal(valorTransacao, argumento);
                    }
                } 
            }
        }
        return valorTransacao;
    }

    private BigDecimal criaBigDecimal(BigDecimal valorTransacao, Object argumento) {
        if (argumento instanceof BigDecimal) {
            valorTransacao = (BigDecimal) argumento;
        } else if (argumento instanceof Double) {
            valorTransacao = BigDecimal.valueOf((Double) argumento);
        }
        return valorTransacao;
    }
}
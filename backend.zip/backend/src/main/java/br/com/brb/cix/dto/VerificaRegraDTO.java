package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class VerificaRegraDTO extends AbstractDTO{
    private Integer codigoMenuFuncionalidade; 
    private BigDecimal valor;
    private EnumFormaMovimentacao formaMovimentacao;
    private EnumTipoPessoa tipoPessoa;
}
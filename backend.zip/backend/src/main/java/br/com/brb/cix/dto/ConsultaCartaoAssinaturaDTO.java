package br.com.brb.cix.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoImagem;
import br.com.brb.cix.domain.model.enums.EnumTipoMovimentacao;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultaCartaoAssinaturaDTO {
	private Long conta;
	private Long agencia;
	private EnumTipoConta tipoConta;
	private EnumTipoMovimentacao tipoMovimentacao;
	private String nomeTitular;
    private Integer ordemConta;
    private EnumTipoImagem tipoImagem;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Boolean isAtalho;
}
package br.com.brb.cix.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CampoDTO {
	private String campo;
	private String conteudo;
}
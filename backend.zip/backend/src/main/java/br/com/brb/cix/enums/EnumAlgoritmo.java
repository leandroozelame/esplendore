package br.com.brb.cix.enums;

/**
 *
 * Enum onde ficam as informações dos possíveis algoritmos de criptografia a serem utilizados
 * 
 * @author u653949
 *  
 */
public enum EnumAlgoritmo
{
   AES("AES/CTR/NoPadding", "AES", true, 16, "140b41b22a29beb4061bda66b6747e14", "1234567890123456");

   private String identificacao;
   private String algoritmo;
   private boolean hasPadding;
   private Integer multiplo;
   private String chave;
   private String parametros;

   /**
    * 
   * Cria uma nova instância do tipo Algoritmo.<P>
   * @param identificacao
   * @param algoritmo
   * @param hasPadding
   * @param multiplo
    */
   private EnumAlgoritmo(String identificacao, String algoritmo, boolean hasPadding, Integer multiplo, String chave, String parametros)
   {
      this.identificacao = identificacao;
      this.algoritmo = algoritmo;
      this.hasPadding = hasPadding;
      this.multiplo = multiplo;
      this.chave = chave;
      this.parametros = parametros;
   }

   /**
    * 
   * Retorna a Identificação do algoritmo
   * @return
    */
   public String getIdentificacao()
   {
      return identificacao;
   }

   /**
    * 
   * Retorna se o algoritmo precisa de padding
   * @return
    */
   public boolean hasPadding()
   {
      return hasPadding;
   }

   /**
    * 
   * Caso o algoritmo exija que o texto/chaves sejam múltiplos de um determinado número
   * @return
    */
   public Integer getMultiplo()
   {
      return multiplo;
   }
   
   /**
    * 
   * Retorna a identificação simples do algoritmo
   * @return
    */
   public String getAlgoritmo()
   {
      return algoritmo;
   }
   
   /**
    * 
   * Retorna a chave do algoritmo
   * @return
    */
   public String getChave()
   {
      return chave;
   }
   
   /**
    * 
   * Retorna a chave do algoritmo
   * @return
    */
   public String getParametros()
   {
      return parametros;
   }
}

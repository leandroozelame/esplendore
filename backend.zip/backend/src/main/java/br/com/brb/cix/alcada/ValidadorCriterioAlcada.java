package br.com.brb.cix.alcada;

import br.com.brb.cix.alcada.criterios.*;
import br.com.brb.cix.domain.model.regra.Regra;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Service;
import org.springframework.web.context.WebApplicationContext;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ValidadorCriterioAlcada {

    @Autowired
    private CriterioContaOperador criterioContaOperador;
    @Autowired
    private CriterioContaOutroPA criterioContaOutroPA;
    @Autowired
    private CriterioFormaPagamento criterioFormaPagamento;
    @Autowired
    private CriterioGrupoOperador criterioGrupoOperador;
    @Autowired
    private CriterioSemSaldo criterioSemSaldo;
    @Autowired
    private CriterioSemSenha criterioSemSenha;
    @Autowired
    private CriterioTipoConta criterioTipoConta;
    @Autowired
    private CriterioTipoPessoa criterioTipoPessoa;
    @Autowired
    private CriterioValorTransacao criterioValorTransacao;

    private List<CriterioAlcada> criterios;

    @PostConstruct
    private void inicializarOrdemDeCriterios() {
        // A ordem dos critérios impacta a performance da alçada
        // Os critérios mais simples devem ser avaliados primeiro
        criterios = Arrays.asList(
                criterioValorTransacao,
                criterioFormaPagamento,
                criterioSemSenha,
                criterioContaOutroPA,
                criterioGrupoOperador,
                criterioContaOperador,
                criterioTipoPessoa,
                criterioTipoConta,
                criterioSemSaldo
        );
    }

    public boolean isCriteriosAtingidos(Regra regra, DadosTransacao dadosTransacao) {
        log.info("Regra: {}, Prioridade: {}", regra.getNome(), regra.getPrioridade());
        for (CriterioAlcada criterioAlcada: criterios) {
            log.info("Verificando critério '{}'", criterioAlcada.getNomeCriterio());
            if (criterioAlcada.isCriterioDesabilitado(regra)){
                log.info("Critério '{}' desabilitado", criterioAlcada.getNomeCriterio());
            } else if (criterioAlcada.isCriterioAtingido(regra, dadosTransacao)){
                log.info("Critério '{}' atingido", criterioAlcada.getNomeCriterio());
            } else {
                log.info("Critério '{}' não atingido", criterioAlcada.getNomeCriterio());
                return false;
            }
        }
        log.info("Todos os critérios da alçada foram atingidos");
        return true;
    }
}

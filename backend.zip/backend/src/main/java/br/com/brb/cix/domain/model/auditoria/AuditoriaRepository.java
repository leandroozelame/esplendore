package br.com.brb.cix.domain.model.auditoria;

import br.com.brb.cix.domain.model.parametrotransacaoestorno.ParametroTransacaoEstorno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.query.Param;

import java.util.Date;
import java.util.List;

public interface AuditoriaRepository extends JpaRepository<Auditoria, Long>, JpaSpecificationExecutor<Auditoria>, QueryDslPredicateExecutor<Auditoria>{
    
    Auditoria findByCdNsuAutorizacao(Long cdNsuAutorizacao);


    @Query(value = "SELECT * FROM (SELECT * FROM {h-schema}TB_LOG_AUDITORIA tla  WHERE tla.CD_CODIGO_TRANSACAO = 140 AND tla.DT_OPERACAO >= :dataOperacao " +
            "AND tla.CD_NSU_AUTORIZACAO > :nsu AND tla.DS_MATRICULA_OPERADOR = :matriculaOperador ORDER BY tla.DT_OPERACAO ASC) WHERE ROWNUM = 1", nativeQuery = true)
    Auditoria findNextPLD(@Param("nsu") Long nsu, @Param("dataOperacao") Date dataOperacao, @Param("matriculaOperador") String matriculaOperador);
    
}
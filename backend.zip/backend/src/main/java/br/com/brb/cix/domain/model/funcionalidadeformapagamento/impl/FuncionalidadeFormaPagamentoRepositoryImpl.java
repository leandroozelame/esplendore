package br.com.brb.cix.domain.model.funcionalidadeformapagamento.impl;

import br.com.brb.cix.domain.model.funcionalidadeformapagamento.FuncionalidadeFormaPagamentoRepositoryCustom;
import br.com.brb.cix.dto.*;
import br.com.brb.cix.infraestrutura.CixException;
import br.com.brb.cix.util.ObjectUtil;
import br.com.brb.cix.util.SqlUtil;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author u653865
 *
 */
@Repository
public class FuncionalidadeFormaPagamentoRepositoryImpl implements FuncionalidadeFormaPagamentoRepositoryCustom {

    @Getter
    private final EntityManager em;

    @Autowired
    public FuncionalidadeFormaPagamentoRepositoryImpl(EntityManager em) {
        this.em = em;
    }

    
    /*
     * (non-Javadoc)
     * 
     * @see br.com.brb.cix.domain.model.funcionalidadeformapagamento.
     * FuncionalidadeFormaPagamentoRepositoryCustom#listarParametroValorMaximo(
     * java.math.BigDecimal, java.lang.Integer, java.lang.Integer,
     * java.lang.Integer)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<ConsultaFormaPagamentoDTO> listarParametroValorMaximo(BigDecimal valorPagamento,
            Integer codigoFuncionalidade, Integer codigoUnidade, Integer codigoTerminal) {

        int tentativa = 1;
        List<Object[]> x = null;

        while (tentativa < 4 && !existeValorParametro(x)) {
            Query q = em.createNativeQuery(retornarSQLvalorMaximo(tentativa));
            q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
            q.setParameter("valorPagamento", valorPagamento);
            if (tentativa <= 2) {
                q.setParameter("codigoUnidade", codigoUnidade);
            }
            if (tentativa == 1) {
                q.setParameter("codigoTerminal", codigoTerminal);
            }
            x = q.getResultList();
            tentativa++;
        }
        return ObjectUtil.isNull(x) ? null
                : x.stream().map(i -> new ConsultaFormaPagamentoDTO(SqlUtil.toLong(i[0]), SqlUtil.toString(i[1]),
                        SqlUtil.toBoolean(i[2]))).collect(Collectors.toList());
    }

    /**
     * @param list
     * @return
     */
    private Boolean existeValorParametro(List<Object[]> list) {
        return ObjectUtil.isNull(list) ? Boolean.FALSE
                : list.stream().filter(i -> SqlUtil.toBoolean(i[2])).count() > 0L;
    }

    /**
     * @param opcao
     * @return
     */
    private String retornarSQLvalorMaximo(Integer opcao) {

        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT                                                         ");
        sql.append("       FP.CD_FORMA_PAGAMENTO,                                   ");
        sql.append("       FP.DS_FORMA_PAGAMENTO,                                   ");
        sql.append("       1                                                        ");
        sql.append(" FROM CIX.TB_FORMA_PAGAMENTO FP                                 ");
        sql.append(" JOIN CIX.TB_FUNCIONALIDADE_FORMA_PAGTO FFP                     ");
        sql.append("      ON FFP.CD_FORMA_PAGAMENTO = FP.CD_FORMA_PAGAMENTO         ");
        sql.append(" JOIN CIX.TB_FUNCIONALIDADE  F                                  ");
        sql.append("      ON F.SQ_FUNCIONALIDADE    = FFP.SQ_FUNCIONALIDADE         ");
        sql.append(" WHERE 1=1                                                      ");
        sql.append(" AND FFP.ST_ACEITA_FORMA_PAGAMENTO = 1                          ");
        sql.append(" AND (                                                          ");
        sql.append("      FFP.VL_MAXIMO_PAGAMENTO >= :valorPagamento                ");
        sql.append("      OR FFP.VL_MAXIMO_PAGAMENTO IS NULL                        ");
        sql.append("      )                                                         ");
        sql.append(" AND FFP.SQ_FUNCIONALIDADE    = :codigoFuncionalidade           ");
        sql.append(" AND FFP.CD_UNIDADE  ").append(opcao <= 2 ? " = :codigoUnidade  " : " IS NULL ");
        sql.append(" AND FFP.SQ_TERMINAL ").append(opcao == 1 ? " = :codigoTerminal " : " IS NULL ");
        sql.append("                                                                ");
        sql.append(" UNION ALL                                                      ");
        sql.append("                                                                ");
        sql.append(" SELECT                                                         ");
        sql.append("       FP.CD_FORMA_PAGAMENTO,                                   ");
        sql.append("       FP.DS_FORMA_PAGAMENTO,                                   ");
        sql.append("       0                                                        ");
        sql.append(" FROM CIX.TB_FORMA_PAGAMENTO FP                                 ");
        sql.append(" WHERE 1=1                                                      ");
        sql.append(" AND FP.CD_FORMA_PAGAMENTO                                      ");
        sql.append(" NOT IN (                                                       ");
        sql.append("          SELECT                                                ");
        sql.append("             FFP.CD_FORMA_PAGAMENTO                             ");
        sql.append("          FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO FFP            ");
        sql.append("          WHERE 1=1                                             ");
        sql.append("          AND FFP.ST_ACEITA_FORMA_PAGAMENTO = 1                 ");
        sql.append("          AND (                                                 ");
        sql.append("               FFP.VL_MAXIMO_PAGAMENTO >= :valorPagamento       ");
        sql.append("               OR FFP.VL_MAXIMO_PAGAMENTO IS NULL               ");
        sql.append("              )                                                 ");
        sql.append("          AND FFP.SQ_FUNCIONALIDADE    = :codigoFuncionalidade  ");
        sql.append("          AND FFP.CD_UNIDADE  ").append(opcao <= 2 ? " = :codigoUnidade  " : " IS NULL ");
        sql.append("          AND FFP.SQ_TERMINAL ").append(opcao == 1 ? " = :codigoTerminal " : " IS NULL ");
        sql.append("         )                                                      ");
        sql.append(" ORDER BY CD_FORMA_PAGAMENTO                                    ");

        return sql.toString();
    }

    /**
     * @param codigoFuncionalidade
     * @param codigoFormaPagamento
     * @param valorPld
     * @return
     */
    @Override
    public Boolean exigePld(Integer codigoFuncionalidade, Integer codigoFormaPagamento, BigDecimal valorPld) {
        Query q = em.createNativeQuery(retornarSQLExigePLD(codigoFormaPagamento));
        q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
        q.setParameter("valorPld", valorPld);
        if (!ObjectUtil.isNull(codigoFormaPagamento)) {
            q.setParameter("codigoFormaPagamento", codigoFormaPagamento);
        }

        try {
            return SqlUtil.toInteger(q.getSingleResult()) > 0;
        } catch (NoResultException e) {
            return Boolean.FALSE;
        }
    }

    /**
     * @param codigoFormaPagamento
     * @return
     */
    private String retornarSQLExigePLD(Integer codigoFormaPagamento) {
        StringBuffer sql = new StringBuffer();

        sql.append(" SELECT                                                              ");
        sql.append("    COUNT(*)                                                         ");
        sql.append(" FROM (                                                              ");
        sql.append("    SELECT                                                           ");
        sql.append("    1                                                                ");
        sql.append("    FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO FP                        ");
        sql.append("    WHERE 1=1                                                        ");
        sql.append("    AND NOT EXISTS (                                                 ");
        sql.append("                    SELECT                                           ");
        sql.append("                    1                                                ");
        sql.append("                    FROM CIX.TB_FUNCIONALIDADE F                     ");
        sql.append("                    WHERE F.SQ_FUNCIONALIDADE = FP.SQ_FUNCIONALIDADE ");
        sql.append("                    AND F.ST_FORMA_PAGAMENTO  = 0                    ");
        sql.append("                    )                                                ");
        sql.append("    AND FP.SQ_FUNCIONALIDADE  = :codigoFuncionalidade                ");
        if (!ObjectUtil.isNull(codigoFormaPagamento)) {
            sql.append("    AND FP.CD_FORMA_PAGAMENTO = :codigoFormaPagamento            ");
        }
        sql.append("    AND (FP.VL_PLD           >= :valorPld                            ");
        sql.append("        OR FP.VL_PLD IS NULL                                         ");
        sql.append("        )                                                            ");
        sql.append("                                                                     ");
        sql.append("    UNION ALL                                                        ");
        sql.append("                                                                     ");
        sql.append("    SELECT                                                           ");
        sql.append("    1                                                                ");
        sql.append("    FROM CIX.TB_FUNCIONALIDADE F                                     ");
        sql.append("    WHERE 1=1                                                        ");
        sql.append("    AND F.ST_FORMA_PAGAMENTO = 0                                     ");
        sql.append("    AND F.SQ_FUNCIONALIDADE  = :codigoFuncionalidade                 ");
        sql.append("    AND (F.VL_PLD           >= :valorPld                             ");
        sql.append("        OR F.VL_PLD IS NULL                                          ");
        sql.append("        )                                                            ");
        sql.append(" ) XXX                                                               ");

        return sql.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see br.com.brb.cix.domain.model.funcionalidadeformapagamento.
     * FuncionalidadeFormaPagamentoRepositoryCustom#
     * findByFuncionalidadeAndFormaPagamentoWithSuperTransacao(java.lang.
     * Integer, java.lang.Integer, java.lang.Integer)
     */
    @Override
    public ConsultaSuperTransacaoDTO findByFuncionalidadeAndFormaPagamentoWithSuperTransacao(Integer codigoModulo,
            Integer codigoFuncionalidade, Integer codigoFormaPagamento) {

        Object[] x = null;

        Query q = em.createNativeQuery(retornarQueryByFuncionalidadeAndFormaPagamentoSuperTransacao());
        q.setParameter("codigoModulo", codigoModulo);
        q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
        q.setParameter("codigoFormaPagamento", codigoFormaPagamento);
        try {
            x = (Object[]) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
        return ObjectUtil.isNull(x) ? null
                : new ConsultaSuperTransacaoDTO(SqlUtil.toLong(x[0]), SqlUtil.toString(x[1]), SqlUtil.toLong(x[2]),
                        SqlUtil.toString(x[3]));
    }
    
    /**
     * @return
     */
    private String retornarQueryByFuncionalidadeAndFormaPagamentoSuperTransacao() {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT                                               ");
        sql.append("        FUN.SQ_FUNCIONALIDADE,                        ");
        sql.append("        FUN.NO_FUNCIONALIDADE,                        ");
        sql.append("        FP.CD_FORMA_PAGAMENTO,                        ");
        sql.append("        FP.DS_FORMA_PAGAMENTO                         ");
        sql.append(" FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO F             ");
        sql.append(" JOIN CIX.TB_FUNCIONALIDADE FUN                       ");
        sql.append("      ON FUN.SQ_FUNCIONALIDADE = F.SQ_FUNCIONALIDADE  ");
        sql.append(" JOIN CIX.TB_FORMA_PAGAMENTO FP                       ");
        sql.append("      ON FP.CD_FORMA_PAGAMENTO = F.CD_FORMA_PAGAMENTO ");
        sql.append(" WHERE F.ST_SUPERTRANSACAO = 1                        ");
        sql.append(" AND FUN.CD_MODULO         = :codigoModulo            ");
        sql.append(" AND F.SQ_FUNCIONALIDADE   = :codigoFuncionalidade    ");
        sql.append(" AND F.CD_FORMA_PAGAMENTO  = :codigoFormaPagamento    ");
        sql.append(" AND ROWNUM = 1                                       ");

        return sql.toString();
    }
    
    @SuppressWarnings("unchecked")
    public List<ConsultaFuncionalidadeFormaDTO> buscarParametros(ConsultaFormaPagamentoFiltroDTO filtro) {
        StringBuilder sql = new StringBuilder("SELECT p.sq_funcionalidade_forma_pagto, m.cd_modulo, m.no_modulo,") //0,1,2
                .append(" p.cd_unidade, u.unddsc,") //3,4
                .append(" t.sq_terminal, t.ds_ip_terminal, t.nr_terminal,") //5,6,7
                .append(" f.sq_funcionalidade, f.no_funcionalidade,") //8,9
                .append(" fp.cd_forma_pagamento, fp.ds_forma_pagamento,") //10,11
                .append(" p.vl_maximo_pagamento, p.st_aceita_forma_pagamento") //12,13
                .append(" FROM {h-schema}TB_FUNCIONALIDADE_FORMA_PAGTO p")                
                .append(" LEFT JOIN {h-schema}TB_FUNCIONALIDADE f ON p.SQ_FUNCIONALIDADE = f.SQ_FUNCIONALIDADE")
                .append(" LEFT JOIN {h-schema}TB_MODULO m ON f.CD_MODULO = m.CD_MODULO")
                .append(" LEFT JOIN {h-schema}VW_UND u ON p.CD_UNIDADE = u.UNDCOD")
                .append(" LEFT JOIN {h-schema}TB_TERMINAL t ON p.SQ_TERMINAL = t.SQ_TERMINAL")
                .append(" LEFT JOIN {h-schema}TB_FORMA_PAGAMENTO fp ON p.CD_FORMA_PAGAMENTO = fp.CD_FORMA_PAGAMENTO");       
        
        montarClausulaWhere(filtro, sql);
        sql.append(" ORDER BY u.unddsc, t.nr_terminal, f.no_funcionalidade, fp.ds_forma_pagamento");
        
        Query query = em.createNativeQuery(sql.toString());
        
        setarParametros(filtro, query);
        
        List<Object[]> resultado = query.getResultList();
        List<ConsultaFuncionalidadeFormaDTO> parametros = null;
        
        if (resultado != null && !resultado.isEmpty()) {           
            parametros = new ArrayList<>();
            for (Object[] dado : resultado) {
                ConsultaFuncionalidadeFormaDTO parametro = new ConsultaFuncionalidadeFormaDTO();

                parametro.setIdFuncionalidadeFormaPagamento(Objects.isNull(dado[0]) ? null : Long.valueOf(dado[0].toString()));
                parametro.setCodigoModulo(Objects.isNull(dado[1]) ? null : Integer.valueOf(dado[1].toString()));
                parametro.setNomeModulo(Objects.isNull(dado[2]) ? null : dado[2].toString());
                parametro.setCodigoUnidade(Objects.isNull(dado[3]) ? null : Integer.valueOf(dado[3].toString()));
                parametro.setNomeUnidade(Objects.isNull(dado[4]) ? null : dado[4].toString());
                parametro.setCodigoTerminal(Objects.isNull(dado[5]) ? null : Long.valueOf(dado[5].toString()));
                parametro.setDescricaoTerminal(Objects.isNull(dado[5]) ? null : montarDescricaoTerminal(dado));
                parametro.setCodigoFuncionalidade(Objects.isNull(dado[8]) ? null : Long.valueOf(dado[8].toString()));
                parametro.setNomeFuncionalidade(Objects.isNull(dado[9]) ? null : dado[9].toString());
                parametro.setCodigoFormaPagamento(Objects.isNull(dado[10]) ? null : Long.valueOf(dado[10].toString()));
                parametro.setNomeFormaPagamento(Objects.isNull(dado[11]) ? null : dado[11].toString());
                parametro.setValorMaximoPagamento(Objects.isNull(dado[12]) ? null : new BigDecimal(dado[12].toString()));
                parametro.setAceitaFormaPagamento(Objects.isNull(dado[13]) ? null : (char) dado[13] == '1');
                parametros.add(parametro);
            }            
        }
        return parametros;
    }

    private String montarDescricaoTerminal(Object... dado) {
        return dado[6].toString() + " - " + dado[7].toString();
    }

    private void setarParametros(ConsultaFormaPagamentoFiltroDTO filtro, Query query) {
        query.setParameter("modulo", filtro.getCodigoModulo());
        
        if (!Objects.isNull(filtro.getCodigoUnidade())) {
            query.setParameter("unidade", filtro.getCodigoUnidade());
        }
        if (!Objects.isNull(filtro.getCodigoTerminal())) {
            query.setParameter("terminal", filtro.getCodigoTerminal());
        }
        if (!Objects.isNull(filtro.getCodigoFuncionalidade())) {
            query.setParameter("funcionalidade", filtro.getCodigoFuncionalidade());
        }
        if (!Objects.isNull(filtro.getCodigoFormaPagamento())) {
            query.setParameter("formaPagamento", filtro.getCodigoFormaPagamento());
        }
    }

    private void montarClausulaWhere(ConsultaFormaPagamentoFiltroDTO filtro, StringBuilder sql) {
        sql.append(" WHERE f.CD_MODULO = :modulo");
        if (!Objects.isNull(filtro.getCodigoUnidade())) {
            sql.append(" AND p.CD_UNIDADE = :unidade");
        }
        if (!Objects.isNull(filtro.getCodigoTerminal())) {
            sql.append(" AND p.SQ_TERMINAL = :terminal");
        }
        if (!Objects.isNull(filtro.getCodigoFuncionalidade())) {
            sql.append(" AND p.SQ_FUNCIONALIDADE = :funcionalidade");
        }
        if (!Objects.isNull(filtro.getCodigoFormaPagamento())) {
            sql.append(" AND p.CD_FORMA_PAGAMENTO = :formaPagamento");
        }
    }

    @Override
    public BigDecimal buscarLimitePorTransacaoFormaPagamento(Long codigoUnidade, Long codigoTerminal,
                                                             Long codigoFuncionalidade, Long codigoFormaPagamento) {
        BigDecimal valor = null;

        String sqlString = montarSQLValorMaximoTransacao(codigoUnidade);
        Query q = em.createNativeQuery(sqlString);
        q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
        q.setParameter("codigoFormaPagamento", codigoFormaPagamento);
        if (codigoUnidade != null) q.setParameter("codigoUnidade", codigoUnidade);
        q.setParameter("codigoTerminal", codigoTerminal);
        
        try {
            valor = (BigDecimal) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
        return ObjectUtil.isNull(valor) ? null : valor;
    }

    @Override
    public BigDecimal buscarLimiteTransacaoPorTerminalUnidadeFuncionalidade(Integer codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento) {

        validarEntrada(codigoUnidade, codigoTerminal, codigoFuncionalidade, codigoFormaPagamento);

        BigDecimal valor = null;

        String sqlConsultaValorMaximo = montarSQLConsultaValorMaximo();
        Query q = em.createNativeQuery(sqlConsultaValorMaximo);
        q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
        q.setParameter("codigoFormaPagamento", codigoFormaPagamento);
        q.setParameter("codigoUnidade", codigoUnidade);
        q.setParameter("codigoTerminal", codigoTerminal);

        try {
            valor = (BigDecimal) q.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
        return ObjectUtil.isNull(valor) ? null : valor;
    }

    @Override
    public List<FuncionalidadeFormaPagamentoDTO> buscarLimiteTransacaoPorFuncionalidade(Integer codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento) {

        validarEntrada(codigoUnidade, codigoTerminal, codigoFuncionalidade, codigoFormaPagamento);

        Boolean comUnidade = Boolean.FALSE.equals( codigoUnidade.equals(0) );
        String sqlConsultaValorMaximo = montarSQLConsultaValoresMaximoDaFuncionalidade(comUnidade);
        Query q = em.createNativeQuery(sqlConsultaValorMaximo);
        q.setParameter("codigoFuncionalidade", codigoFuncionalidade);
        q.setParameter("codigoFormaPagamento", codigoFormaPagamento);
        q.setParameter("codigoTerminal", codigoTerminal);

        if(comUnidade){
            q.setParameter("codigoUnidade", codigoUnidade);
        }

        List<Object[]> lista = q.getResultList();

        return ObjectUtil.isNull(lista) ? new ArrayList<>() : lista.stream().map(i -> {
            FuncionalidadeFormaPagamentoDTO item = new FuncionalidadeFormaPagamentoDTO();

            item.setCodigo(SqlUtil.toLong(i[0]));
            item.setUnidade(SqlUtil.toInteger(i[1]));

            TerminalDTO terminal = new TerminalDTO();
            terminal.setCodigo(SqlUtil.toLong(i[2]));
            item.setTerminal(terminal);

            item.setValorMaximoPagamento(SqlUtil.toBigDecimail(i[6]));

            return item;
        }).collect(Collectors.toList());
    }

    private static void validarEntrada(Integer codigoUnidade, Long codigoTerminal, Long codigoFuncionalidade, Long codigoFormaPagamento) {
        if (codigoFuncionalidade == null) {
            throw new CixException("Código funcionalidade não pode ser nulo");
        }

        if (codigoFormaPagamento == null) {
            throw new CixException("Código Forma de Pagamento não pode ser nulo");
        }

        if (codigoUnidade == null) {
            throw new CixException("Código unidade não pode ser nulo");
        }

        if (codigoTerminal == null) {
            throw new CixException("Código do terminal não pode ser nulo");
        }
    }

    private static String montarSQLConsultaValorMaximo() {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT *  ");
        sb.append("  FROM ( ");
        sb.append("	SELECT p.VL_MAXIMO_PAGAMENTO ");
        sb.append("	  FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p  ");
        sb.append("	 WHERE p.ST_ACEITA_FORMA_PAGAMENTO = 1 ");
        sb.append("	   AND p.SQ_FUNCIONALIDADE = :codigoFuncionalidade ");
        sb.append("	   AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento ");
        sb.append("	   AND p.CD_UNIDADE = :codigoUnidade ");
        sb.append("	   AND p.SQ_TERMINAL = :codigoTerminal ");
        sb.append("	UNION ");
        sb.append("	SELECT p.VL_MAXIMO_PAGAMENTO  ");
        sb.append("	  FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p  ");
        sb.append("	 WHERE p.ST_ACEITA_FORMA_PAGAMENTO = 1 ");
        sb.append("	   AND p.SQ_FUNCIONALIDADE = :codigoFuncionalidade  ");
        sb.append("	   AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento ");
        sb.append("	   AND p.CD_UNIDADE = :codigoUnidade ");
        sb.append("	   AND p.SQ_TERMINAL IS NULL ");
        sb.append("	UNION ");
        sb.append("	SELECT p.VL_MAXIMO_PAGAMENTO ");
        sb.append("	  FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p  ");
        sb.append("	 WHERE p.ST_ACEITA_FORMA_PAGAMENTO = 1 ");
        sb.append("	   AND p.SQ_FUNCIONALIDADE = :codigoFuncionalidade  ");
        sb.append("	   AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento ");
        sb.append("	   AND p.CD_UNIDADE IS NULL  ");
        sb.append("	   AND p.SQ_TERMINAL IS NULL ");
        sb.append("  ) VALOR_TRANSACAO ");
        sb.append(" WHERE ROWNUM = 1 ");
        return sb.toString();
    }

    private static String montarSQLConsultaValoresMaximoDaFuncionalidade(Boolean comUnidade) {
        StringBuilder sb = new StringBuilder();
        sb.append("SELECT * FROM (                              			");
        sb.append("    SELECT *			 			");
        sb.append("    FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p 			");
        sb.append("	   WHERE p.ST_ACEITA_FORMA_PAGAMENTO = 1                ");
        sb.append("	   AND p.SQ_FUNCIONALIDADE = :codigoFuncionalidade      ");
        sb.append("	   AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento     ");
        sb.append("	   AND (p.SQ_TERMINAL = :codigoTerminal OR p.SQ_TERMINAL IS NULL)    ");

        if(comUnidade){
            sb.append("	   AND (p.CD_UNIDADE = :codigoUnidade OR p.CD_UNIDADE IS NULL ) ");
        }else{
            sb.append("	   AND p.CD_UNIDADE IS NULL ");
        }

        sb.append("  ) ");
        return sb.toString();
    }

    private String montarSQLValorMaximoTransacao(Long codigoUnidade) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT * FROM (                              			");
        sql.append("    SELECT p.VL_MAXIMO_PAGAMENTO			 			");        
        sql.append("    FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p 			");
        sql.append("    WHERE p.SQ_FUNCIONALIDADE = :codigoFuncionalidade 	");
        sql.append(" 	AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento	");
        sql.append("    AND p.SQ_TERMINAL = :codigoTerminal					");
        sql.append("								                        ");
        sql.append("    UNION ALL								            ");
        sql.append("            											");
        sql.append("    SELECT p.VL_MAXIMO_PAGAMENTO			 			");        
        sql.append("    FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p 			");
        sql.append("    WHERE p.SQ_FUNCIONALIDADE = :codigoFuncionalidade 	");
        sql.append(" 	AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento	");
        sql.append("    AND p.CD_UNIDADE ").append(codigoUnidade != null ? " = :codigoUnidade  " : " IS NULL ");
        sql.append("    AND p.SQ_TERMINAL IS NULL                           ");
        sql.append("								                        ");
        sql.append("    UNION ALL								            ");
        sql.append("            											");
        sql.append("    SELECT p.VL_MAXIMO_PAGAMENTO			 			");        
        sql.append("    FROM CIX.TB_FUNCIONALIDADE_FORMA_PAGTO p 			");
        sql.append("    WHERE p.SQ_FUNCIONALIDADE = :codigoFuncionalidade 	");
        sql.append(" 	AND P.CD_FORMA_PAGAMENTO = :codigoFormaPagamento	");
        sql.append("    AND p.CD_UNIDADE ").append(codigoUnidade != null ? " = :codigoUnidade  " : " IS NULL ");
        sql.append("    AND p.SQ_TERMINAL IS NULL                           ");
        sql.append("            											");
        sql.append(") VALOR_TRANSACAO            							");
        sql.append("WHERE ROWNUM = 1            							");
        
        return sql.toString();
    }
}

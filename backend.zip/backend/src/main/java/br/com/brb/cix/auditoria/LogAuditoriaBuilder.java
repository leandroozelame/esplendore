package br.com.brb.cix.auditoria;

import br.com.brb.cix.context.CixHeader;
import br.com.brb.cix.domain.model.auditoria.Auditoria;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.dto.RetornoDTO;
import br.com.brb.cix.dto.comum.RetornoSucessoDTO;
import br.com.brb.cix.enums.EnumCanal;
import br.com.brb.cix.enums.EnumFuncionalidade;
import br.com.brb.cix.enums.EnumTipoEventoAuditoria;
import br.com.brb.cix.infraestrutura.CixException;
import br.com.brb.cix.security.OperadorLogado;
import br.com.brb.cix.service.ConsultaInformacoesContaService;
import br.com.brb.cix.service.TerminalComponent;
import br.com.brb.cix.util.CixUtil;
import br.com.brb.cix.ws.autorizacao.ExecutorTransacaoDTO;
import br.com.brb.cix.ws.autorizacao.dto.TransacaoBpm;
import br.com.brb.cix.ws.consulta.dto.InformacaoConta;
import br.com.brb.cix.ws.log.ExecutorLogDTO;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@SuppressWarnings("deprecation")
@Slf4j
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class LogAuditoriaBuilder {
    @Autowired
    private OperadorLogado operadorLogado;
    @Autowired
    private CixHeader cixHeader;
    @Autowired(required = false)
    private HttpServletRequest httpReq;
    @Autowired(required = false)
    private HttpServletResponse httpRes;
    @Autowired
    private ExecutorTransacaoDTO executorTransacaoDTO;
    @Autowired
    private ExecutorLogDTO executorLogDTO;
    @Autowired
    private ExecutorLogAuditoria executorLogAuditoria;
    @Autowired
    private ConsultaInformacoesContaService consultaInformacoesContaService;
    @Autowired
    private TerminalComponent terminalComponent;
    @Getter
    private EnumCanal enumCanal;
    @Getter
    private EnumFuncionalidade enumFuncionalidade;
    @Getter
    private Exception excecao;
    @Getter
    private LinkedHashMap<String, Object> mapaParametroEntrada = new LinkedHashMap<>();
    @Getter
    private LinkedHashMap<String, Object> mapaParametrosSaida = new LinkedHashMap<>();
    @Getter
    private BigDecimal valorTransacao;
    @Getter
    private String conta;
    @Getter
    private EnumTipoConta tipoConta;
    @Getter
    private String cpfCliente;
    @Getter
    private String nomeCliente;
    @Getter
    private boolean ignoraEntrada;
    @Getter
    private boolean ignoraPendencia;
    @Getter
    private boolean ignoraSaida;
    @Getter
    private EnumSituacaoExecucao enumSituacaoExecucao;
    @Getter
    @Setter
    private List<String> supervisores = new ArrayList<>();
    @Getter
    private EnumTipoEventoAuditoria tipoEventoAuditoria;
    @Getter
    private Long codigoTransacao;
    
    private List<EnumFuncionalidade> listaFuncionalidadesSemConta = Arrays.asList(EnumFuncionalidade.ABERTURA_CAIXA, 
        EnumFuncionalidade.AUTORIZA_PENDENCIA,EnumFuncionalidade.CANCELA_PENDENCIA, EnumFuncionalidade.HORARIO_CANAL_CONSULTA_MODULO,
        EnumFuncionalidade.CONSULTA_REGRA_CODIGO, EnumFuncionalidade.EXECUTAR_GAVETA, EnumFuncionalidade.FECHAMENTO_CAIXA, 
        EnumFuncionalidade.LOGIN_SISTEMA, EnumFuncionalidade.RECOLHIMENTO_NUMERARIO, EnumFuncionalidade.REJEITA_PENDENCIA,
        EnumFuncionalidade.SALDO_CAIXA, EnumFuncionalidade.SAQUE_BENEFICIO_EVENTUAL, EnumFuncionalidade.SUPRIMENTO_NUMERARIO);

    public LogAuditoriaBuilder ignoraEntrada(Boolean ignoraEntrada) {
        this.ignoraEntrada = ignoraEntrada;
        return this;
    }

    public LogAuditoriaBuilder ignoraPendencia(Boolean ignoraPendencia) {
        this.ignoraPendencia = ignoraPendencia;
        return this;
    }

    public LogAuditoriaBuilder ignoraSaida(Boolean ignoraSaida) {
        this.ignoraSaida = ignoraSaida;
        return this;
    }

    public LogAuditoriaBuilder comValorTransacao(BigDecimal valorTransacao) {
        this.valorTransacao = valorTransacao;
        return this;
    }

    public LogAuditoriaBuilder comConta(String conta) {
        this.conta = conta;
        return this;
    }

    public LogAuditoriaBuilder comTipoConta(EnumTipoConta tipoConta) {
        this.tipoConta = tipoConta;
        return this;
    }

    public LogAuditoriaBuilder comCpf(String cpf) {
        this.cpfCliente = cpf;
        return this;
    }

    public LogAuditoriaBuilder comNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
        return this;
    }

    public LogAuditoriaBuilder comExcecao(Exception excecao) {
        this.excecao = excecao;
        return this;
    }

    public LogAuditoriaBuilder comEnumFuncionalidade(EnumFuncionalidade enumFuncionalidade) {
        this.enumFuncionalidade = enumFuncionalidade;
        return this;
    }

    public LogAuditoriaBuilder comEnumCanal(EnumCanal enumCanal) {
        this.enumCanal = enumCanal;
        return this;
    }

    public LogAuditoriaBuilder comEnumSituacaoExecucao(EnumSituacaoExecucao enumSituacaoExecucao) {
        this.enumSituacaoExecucao = enumSituacaoExecucao;
        return this;
    }
    
    public LogAuditoriaBuilder comEnumTipoEventoAuditoria(EnumTipoEventoAuditoria tipoEventoAuditoria) {
        this.tipoEventoAuditoria = tipoEventoAuditoria;
        return this;
    }
    
    public LogAuditoriaBuilder comCodigoTransacao(Long codigoTransacao) {
        this.codigoTransacao = codigoTransacao;
        return this;
    }

    public LogAuditoriaBuilder adicionaEntrada(String chave, Object valor) {
        if (chave != null && valor != null) {
            this.mapaParametroEntrada.put(chave, valor);
        }
        return this;
    }

    public LogAuditoriaBuilder adicionaEntrada(Map<String, Object> mapaParametroEntrada) {
        if (mapaParametroEntrada != null && !mapaParametroEntrada.isEmpty()) {
            this.mapaParametroEntrada.putAll(mapaParametroEntrada);
        }
        return this;
    }

    public LogAuditoriaBuilder adicionaSaida(String chave, Object valor) {
        if (chave != null && valor != null) {
            if (valor instanceof RetornoSucessoDTO) {
                valor = ((RetornoSucessoDTO) valor).getResultado();
            }
            if (valor instanceof RetornoDTO) {
                valor = ((RetornoDTO) valor).getResultado();
            }
            this.mapaParametrosSaida.put(chave, valor);
        }
        return this;
    }

    public LogAuditoriaBuilder adicionaSaida(Map<String, Object> mapaParametroSaida) {
        if (mapaParametroSaida != null && !mapaParametroSaida.isEmpty()) {
            this.mapaParametrosSaida.putAll(mapaParametroSaida);
        }
        return this;
    }

    public void throwCixException(String mensagem) throws CixException {
    	CixException cixException = new CixException(mensagem);
    	
    	comExcecao(cixException);
    	throw cixException;
    }
    
    public ExecutorLogAuditoria cria() {
        try {
            // Dados Comum
            Auditoria auditoria = this.fabricaAuditoria();

            // Excecao
            if (excecao != null) {
                preencheDadosDaExcecao(auditoria);
            }
            // Transacao BPM
            if (executorTransacaoDTO.getTransacaoBpm() != null) {
                preencheDadosDaTransacaoBpm(auditoria);
            }
            // Autorizacao BPM
            if (executorTransacaoDTO.getAutorizacaoBpm() != null) {
                preencheDadosDaAutorizacaoBpm(auditoria);
            }
            // Log Financeiro
            if (executorLogDTO.getNsu() != null) {
                auditoria.setCdNsuLog(executorLogDTO.getNsuAsInteger());
            }
            
            // Busca informações da conta no BLK caso ja tenha uma conta informada
            preencheDadosDoCliente(auditoria);
            
            // Entrada
            auditoria.getMapaParametroEntrada().putAll(mapaParametroEntrada);
            // Saida
            auditoria.setMapaParametrosSaida(mapaParametrosSaida);
            executorLogAuditoria.setAuditoria(auditoria);
            executorLogAuditoria.setSupervisores(supervisores);
        } catch (Exception e) {
            log.error("Erro na criacao do Log de Auditoria", e);
            throw new ExecutorAuditoriaException(e);
        }
        return executorLogAuditoria;
    }

    private void preencheDadosDoCliente(Auditoria auditoria) {
        if (auditoria.getConta() != null && isCampoContaNaAuditoria() && (auditoria.getCpfCliente() == null || auditoria.getNomeCliente() == null)) {
            Integer agencia = CixUtil.recuperaAgenciaDaConta(CixUtil.getContaSemMascara(auditoria.getConta())).intValue();
            if(agencia > 0) {
                try {
                    List<InformacaoConta> informacaoConta = consultaInformacoesContaService.consulta(agencia, CixUtil.getContaSemMascara(auditoria.getConta())).getInformacoesConta();
                    if (informacaoConta != null) {
                        auditoria.setNomeCliente(informacaoConta.get(0).getNomeTitular1());
                        if(informacaoConta.get(0).getTipoPessoa().equals(EnumTipoPessoa.PESSOA_FISICA.getCodigo())){
                            auditoria.setCpfCliente(CixUtil.formataCpfCnpjSemPontuacao(informacaoConta.get(0).getCpfCnpjTitular1(), Boolean.TRUE));
                        }
                    }
                } catch (Exception e) {
                    log.error("Erro ao consultar informações de conta no BLK para auditoria: " + e.getMessage());
                }
            }
        }
    }

    private void preencheDadosDaAutorizacaoBpm(Auditoria auditoria) {
        auditoria.setCdNsuAutorizacao(executorTransacaoDTO.getAutorizacaoBpm().getNsuBlk());
        auditoria.setNomeTransacao(WordUtils.capitalizeFully(executorTransacaoDTO.getFromValores("FTN_DescricaoTransacao")));
        if(auditoria.getNomeCliente() == null)
            auditoria.setNomeCliente(WordUtils.capitalizeFully(executorTransacaoDTO.getFromValores("FTN_NomeTitularDebito1")));
        if(auditoria.getCpfCliente() == null)
            auditoria.setCpfCliente(executorTransacaoDTO.contemChave("FTN_CpfCnpjConta")
                    ? ((Long) executorTransacaoDTO.getFromValores("FTN_CpfCnpjConta")).toString() : null);
    }

    private void preencheDadosDaTransacaoBpm(Auditoria auditoria) {
        TransacaoBpm transacaoBpm = executorTransacaoDTO.getTransacaoBpm();

        auditoria.setCdTransacao(Integer.parseInt(Long.toString(transacaoBpm.getCodigoTransacao())));
        if (conta == null) { 
            String contaDaTransacao = String.valueOf(transacaoBpm.getDadosProcesso().getConta());
            Integer tipoContaDaTransacao = transacaoBpm.getDadosProcesso().getTipoConta();
            
            if (!contaDaTransacao.equals("0")) {
                auditoria.setConta(contaDaTransacao);
            }
            if (tipoContaDaTransacao != null && !EnumTipoConta.VAZIO.getCodigo().equals(tipoContaDaTransacao)) {
                auditoria.setTpConta(EnumTipoConta.get(tipoContaDaTransacao));
            }
        } else {
            auditoria.setConta(conta);                	
        }
        auditoria.setCdNsuCanal(Integer.parseInt(Long.toString(transacaoBpm.getNsuOrigem())));
    }

    private void preencheDadosDaExcecao(Auditoria auditoria) {
        if (enumSituacaoExecucao == null) {
            auditoria.setSituacaoExecucao(EnumSituacaoExecucao.ERRO);
        }
        auditoria.setMensagem(StringUtils.abbreviate(excecao.getMessage(), 300));
    }

    /**
     * Metodo para verificar se funcionalidade o campo conta e realmente uma conta.
     * Em algumas funcionalidades(ex: saque beneficio eventual) o cpf e gravado neste campo.
     * @param funcionalidade funcionalidade
     * @return Boolean
     */
    private Boolean isCampoContaNaAuditoria() {
    	Boolean retorno = Boolean.TRUE;
    	if(enumFuncionalidade != null) {
    		return !listaFuncionalidadesSemConta.contains(enumFuncionalidade);
    	}
    	return retorno;
    }
    
    public Auditoria fabricaAuditoria(){
        // Dados Comum
        Auditoria auditoriaInicial = new Auditoria();

        auditoriaInicial.setDataOperacao(LocalDateTime.now());
        auditoriaInicial.setNrTerminal(terminalComponent.getNumeroTerminalInteger());
        auditoriaInicial.setIp(CixUtil.getClientIp(httpReq));
        auditoriaInicial.setOperador(operadorLogado.getMatriculaCompleta());
        auditoriaInicial.setNomeOperador(operadorLogado.getNome());
        auditoriaInicial.setAgenciaOperador(operadorLogado.getCodigoUnidade().toString());
        auditoriaInicial.setCodigoUnidadeOperador(operadorLogado.getCodigoUnidade());
        auditoriaInicial.setDescricaoUnidadeOperador(operadorLogado.getDescricaoUnidade());
        auditoriaInicial.setServidor(httpReq.getServerName());
        auditoriaInicial.setVlOperacao(valorTransacao);
        auditoriaInicial.setConta(conta);
        auditoriaInicial.setTpConta(tipoConta);
        auditoriaInicial.setCpfCliente(cpfCliente);
        auditoriaInicial.setNomeCliente(nomeCliente);
        // Canal
        auditoriaInicial.setNrCanal((EnumCanal.NENHUM.equals(enumCanal) || enumCanal == null) ? cixHeader.getEnumCanal() : enumCanal);
        // Funcionalidade
        if (enumFuncionalidade != null) {
            auditoriaInicial.setFuncionalidade(enumFuncionalidade.getDescricao());
        }
        // Situação Execução
        HttpStatus httpStatus = HttpStatus.valueOf(httpRes.getStatus());
        
        if (enumSituacaoExecucao != null) {
            auditoriaInicial.setSituacaoExecucao(enumSituacaoExecucao);
        } else if (httpStatus.equals(HttpStatus.CREATED)) {
            auditoriaInicial.setSituacaoExecucao(EnumSituacaoExecucao.REJEITADO);
        } else if (httpStatus.is4xxClientError() || httpStatus.is5xxServerError()) {
            auditoriaInicial.setSituacaoExecucao(EnumSituacaoExecucao.ERRO);
        } else {
            auditoriaInicial.setSituacaoExecucao(EnumSituacaoExecucao.SUCESSO);
        }       
        if (tipoEventoAuditoria != null) {
            auditoriaInicial.setEvento(tipoEventoAuditoria.getDescricao());
        }
        if (codigoTransacao != null) {
            auditoriaInicial.setCdTransacao(codigoTransacao.intValue());
        }
        auditoriaInicial.setMapaParametroEntrada(new LinkedHashMap<>());
        auditoriaInicial.getMapaParametroEntrada().put("URL da Requisição", httpReq.getRequestURL().toString());
        return auditoriaInicial;
    }
}
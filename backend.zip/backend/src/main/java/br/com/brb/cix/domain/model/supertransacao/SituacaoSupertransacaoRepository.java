package br.com.brb.cix.domain.model.supertransacao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SituacaoSupertransacaoRepository extends JpaRepository<SituacaoSupertransacao, Integer> {

}

package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsultaFormaPagamentoDTO extends AbstractDTO {
    
    private Long codigo;
    private String descricao;
    private Boolean temFormaPagamento;
    

}

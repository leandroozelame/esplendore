package br.com.brb.cix.domain.model.supertransacao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_SITUACAO_SUPERTRANSACAO")
public class SituacaoSupertransacao  {
	
	private static final long serialVersionUID = 2312691307533131376L;

	@Id
    @Column(name = "CD_SITUACAO_SUPERTRANSACAO")
    private Integer codigo;

    @Column(name = "NO_SITUACAO_SUPERTRANSACAO")
    private String descricao;
}

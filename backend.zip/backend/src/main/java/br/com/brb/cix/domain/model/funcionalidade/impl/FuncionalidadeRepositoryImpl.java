package br.com.brb.cix.domain.model.funcionalidade.impl;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.domain.model.funcionalidade.FuncionalidadeRepositoryCustom;
import br.com.brb.cix.dto.FuncionalidadeDTO;
import br.com.brb.cix.util.SqlUtil;
import lombok.Getter;

/**
 * @author u653865
 *
 */
/**
 * @author u653865
 *
 */
@Repository
public class FuncionalidadeRepositoryImpl implements FuncionalidadeRepositoryCustom {

    @Getter
    private final EntityManager entityManager;

    /**
     * @param manager
     */
    @Autowired
    public FuncionalidadeRepositoryImpl(EntityManager manager) {
        this.entityManager = manager;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * br.com.brb.cix.domain.model.funcionalidade.FuncionalidadeRepositoryCustom
     * #listarComboFuncionalidades(java.lang.Boolean)
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<FuncionalidadeDTO> listarComboFuncionalidadesNrTransacao(List<Integer> numerosTransacao, Integer modulo) {

        Query q = entityManager.createNativeQuery(getSqlComboFuncionalidades());
        q.setParameter("numerosTransacao", numerosTransacao);
        q.setParameter("modulo", modulo);
        
        List<Object[]> x = q.getResultList();

        return x.stream().map(r -> new FuncionalidadeDTO(SqlUtil.toString(r[0]), SqlUtil.toInteger(r[1])))
                .collect(Collectors.toList());
    }

    /**
     * @param numeroTransacao
     * @return
     */
    @Override
    public String getStateFuncionalidadeByNrTransacao(Integer numeroTransacao) {
        Query q = entityManager.createNativeQuery(getSqlStateByNrTransacao());
        q.setParameter("numeroTransacao", numeroTransacao);
        try {
            return SqlUtil.toString(q.getSingleResult());
        } catch (NoResultException e) {
            return null;
        }
    }

    /**
     * @return
     */
    private String getSqlComboFuncionalidades() {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT                       ");
        sql.append("    F.no_funcionalidade,      ");
        sql.append("    F.nr_transacao            ");
        sql.append(" FROM CIX.tb_funcionalidade F ");
        sql.append(" WHERE F.nr_transacao IN (    ");
        /*
         * if (isDoc) { sql.append("    1540,                     ");
         * sql.append("    2520,                     "); sql.append(
         * "    1590,                     "); sql.append(
         * "    2530,                     "); sql.append(
         * "    3190                      ");
         * 
         * } else { sql.append("    154,                     "); sql.append(
         * "    160,                     "); sql.append(
         * "    151,                     "); sql.append(
         * "    155,                     "); sql.append(
         * "    153,                     "); sql.append(
         * "    152,                     "); sql.append(
         * "    156                      ");
         * 
         * }
         */
        sql.append(" :numerosTransacao            ");
        sql.append(" ) AND F.cd_modulo = :modulo  ");
        sql.append(" ORDER BY F.no_funcionalidade ");

        return sql.toString();
    }

    /**
     * @return
     */
    private String getSqlStateByNrTransacao() {
        StringBuffer sql = new StringBuffer();
        sql.append(" SELECT                                  ");
        sql.append(" F.ds_state                              ");
        sql.append(" FROM CIX.tb_funcionalidade F            ");
        sql.append(" WHERE F.nr_transacao = :numeroTransacao ");
        sql.append(" AND F.DS_STATE IS NOT NULL              ");

        return sql.toString();
    }

    @Override
    public Funcionalidade getSqlStateByCodMenu(Long codMenu) {
        // TODO Auto-generated method stub
        return null;
    }
    
    public FuncionalidadeDTO getByGrupoModuloFuncionalidade(Long codigoGrupo, Integer codigoModulo, Long codigoMenu) {
    	FuncionalidadeDTO funcionalidadeDTO;
    	StringBuilder sql = new StringBuilder();
    	sql.append("SELECT ");
    	sql.append("TB_FUNCIONALIDADE.NO_FUNCIONALIDADE     ,"); 
    	sql.append("TB_FUNCIONALIDADE.NR_TRANSACAO           ");
    	sql.append("FROM {h-schema}TB_PERFIL_GRUPO ");
    	sql.append("JOIN {h-schema}TB_PERFIL ON TB_PERFIL.SQ_CODIGO = TB_PERFIL_GRUPO.SQ_CODIGO ");
    	sql.append("JOIN {h-schema}TB_PERFIL_FUNCIONALIDADE ON TB_PERFIL.SQ_CODIGO = TB_PERFIL_FUNCIONALIDADE.SQ_CODIGO ");
    	sql.append("JOIN {h-schema}TB_FUNCIONALIDADE ON TB_PERFIL_FUNCIONALIDADE.SQ_FUNCIONALIDADE = TB_FUNCIONALIDADE.SQ_FUNCIONALIDADE ");
    	sql.append("WHERE ");
    	sql.append("TB_PERFIL_GRUPO.CD_GRPCOD = :codigoGrupo AND ");
    	sql.append("TB_PERFIL.CD_MODULO = :codigoModulo AND ");
    	sql.append("TB_FUNCIONALIDADE.CD_MENU = :codigoMenu");
   	
    	Query q = entityManager.createNativeQuery(sql.toString());
        q.setParameter("codigoGrupo", codigoGrupo);
        q.setParameter("codigoModulo", codigoModulo);
        q.setParameter("codigoMenu", codigoMenu);
        try {
        	Object[] result = (Object[]) q.getSingleResult();
        	funcionalidadeDTO = new FuncionalidadeDTO(SqlUtil.toString(result[0]), SqlUtil.toInteger(result[1]));
        } catch (NoResultException e) {
            return null;
        }
    	return funcionalidadeDTO;
    }

}

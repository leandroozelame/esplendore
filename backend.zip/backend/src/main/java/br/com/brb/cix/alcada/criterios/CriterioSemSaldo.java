package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.ws.consulta.dto.InformacaoConta;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
@Slf4j
public class CriterioSemSaldo implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Sem Saldo";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegra.INDIFERENTE.equals(regra.getSemSaldo());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        Boolean isContaDebito = dadosTransacao.getContaDebito();
        InformacaoConta informacaoConta = dadosTransacao.getInformacaoConta();

        // Regra "Sem saldo" deve ser aplicada apenas na conta a ser debitada
        if (!isContaDebito || informacaoConta == null) {
            log.debug("isContaDebito: {}, informacaoConta: {}", isContaDebito, informacaoConta);
            return false;
        }

        EnumValorRegra regraSemSaldo = regra.getSemSaldo();
        BigDecimal valorTransacao = dadosTransacao.getValor();
        BigDecimal saldoResgateAutomatico = informacaoConta.getSaldoResgateAutomatico();
        BigDecimal saldoDisponivel = informacaoConta.getSaldoDisponivel();
        BigDecimal saldo = saldoDisponivel.add(saldoResgateAutomatico);
        log.debug("regraSemSaldo: {}, isContaDebito: {}, valorTransacao: {}, saldo: {}, saldoResgateAutomatico: {}, saldoDisponivel: {}", regraSemSaldo, isContaDebito, valorTransacao, saldo, saldoResgateAutomatico, saldoDisponivel);

        return     (regraSemSaldo.equals(EnumValorRegra.NAO) && (saldo.compareTo(valorTransacao) >= 0))
                || (regraSemSaldo.equals(EnumValorRegra.SIM) && (saldo.compareTo(valorTransacao) <  0));
    }
}

package br.com.brb.cix.enums;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumAtivo implements EnumDominio {
    INATIVO('0'),
    ATIVO('1');

    @Getter
    private final Character codigo;
}



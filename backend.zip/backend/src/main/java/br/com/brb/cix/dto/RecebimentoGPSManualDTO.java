package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RecebimentoGPSManualDTO extends ContaTipoDTO {

    private EnumFormaMovimentacao formaMovimentacao;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Long numeroFichaContabil;
    private Long codigoTransacao;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private String numeroDocumento;
    private Integer codigoPagamento;
    private String competencia;
    private Date dataDocumento;
    private String matriculaSupervisor;
    private String identificadorContribuinte;
    private BigDecimal valorInss;
    private BigDecimal valorOutrasEntidades;
    private BigDecimal valorJuros;
    @LogValorTransacao
    private BigDecimal valorTotal;
    private String nomePagador;
    private String descricaoPagamento;
    private String numeroCheque;
    private Long numeroContaCheque;
    private String telefone;

    private Long idAlvara;
    private BigDecimal valorAlvara;
    private String nomeBeneficiario;
    private Long cpfCnpj;
    private String tipoPessoa;
    private String nomeTribunal;
    private String cnpjTribunal;
    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private Integer tpPessoaSigla;

    // cheque
    private String cmc7;
    private Integer formaMovimentacaoFinanceira;
}

package br.com.brb.cix.domain.model.parametropld;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametroPldRepository extends JpaRepository<ParametroPld, Long> {
    
    ParametroPld findByCodigo(Long codigo);
    
    List<ParametroPld> findByModulo(Integer modulo);
    
    List<ParametroPld> findByModuloAndFuncionalidadeCodigoAndFuncionalidadeAtivo(Integer modulo, Long funcionalidade, Character habilitado);
    
    List<ParametroPld> findByModuloAndFormaPagamentoCodigo(Integer modulo, Long formaPagamento);
    
    List<ParametroPld> findByModuloAndFuncionalidadeCodigoAndFormaPagamentoCodigo(Integer modulo, Long funcionalidade, Long formaPagamento);
    
    List<ParametroPld> findByModuloAndFuncionalidadeCodigoAndFormaPagamentoCodigoAndValor(Integer modulo, Long funcionalidade, Long formaPagamento, BigDecimal valor);
    
    List<ParametroPld> findByFuncionalidadeNumeroTransacaoAndModuloAndFormaPagamentoCodigoAndValorLessThanEqualAndHabilitadoTrueOrderByValorDesc(Integer nrTransacao, Integer modulo, Long formaPagamento, BigDecimal valor);
    
    boolean existsByModuloAndFuncionalidadeCodigoAndFormaPagamentoCodigoAndValor(Integer modulo, Long funcionalidade, Long formaPagamento, BigDecimal valor);

    List<ParametroPld> findByModuloAndFuncionalidadeNumeroTransacaoAndHabilitado(Integer modulo, Integer funcionalidade, Boolean habilitado);


}

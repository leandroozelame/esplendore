package br.com.brb.cix.config.security;

import br.com.brb.cix.security.CixUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CixUserDetailsService {

    public CixUser criaCixUser(String matriculaOperador) throws UsernameNotFoundException {
        return new CixUser(matriculaOperador);
    }
}
package br.com.brb.cix.domain.model.grupocnp;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.config.jackson.CustomUnidadeSerializer;
import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.brb.cix.domain.model.unidade.Unidade;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TB_GRUPO")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "codigo")
public class GrupoCNP  {

    private static final long serialVersionUID = 3033886786743759646L;
    
    @Id
    @SequenceGenerator(name = "grupocnp_sequence", sequenceName = "SQ_GRUPO", allocationSize = 1)
    @GeneratedValue(generator = "grupocnp_sequence")
    @Column(name = "SQ_GRUPO", unique=true)
    private Long codigo;
    
    @Column(name = "NO_GRUPO")
    private String nome;
    
    @Column(name = "TP_GRUPO")
    private Character tipo;
    
    @Column(name = "VL_LIMITE")
    private BigDecimal limite;
    
    @JsonSerialize(using= CustomUnidadeSerializer.class)
    @ManyToMany
    @JoinTable(name = "TB_GRUPO_CORRESPONDENTE",
    joinColumns = @JoinColumn(name = "SQ_GRUPO", referencedColumnName = "SQ_GRUPO"),
    inverseJoinColumns = @JoinColumn(name = "CD_UNIDADE", referencedColumnName = "UNDCOD"))
    private List<Unidade> listaCorrespondentes;
    
    public void addUnidade(Unidade unidade) {
        this.listaCorrespondentes.add(unidade);
        unidade.getListaGrupos().add(this);
    }
  
    public void removeUnidade(Unidade unidade) {
        this.listaCorrespondentes.remove(unidade);
        unidade.getListaGrupos().remove(this);
    }

}

package br.com.brb.cix.domain.model.formaautenticacao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FormaAutenticacaoRepository extends JpaRepository<FormaAutenticacao, Long> {
    
    List<FormaAutenticacao> findAllByOrderByCodigo();

}

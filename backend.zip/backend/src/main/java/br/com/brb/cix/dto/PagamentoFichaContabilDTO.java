package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class PagamentoFichaContabilDTO extends AbstractDTO {
    private EnumFormaMovimentacao formaMovimentacao;
    private Long numeroFichaContabil;
    @LogValorTransacao
    private BigDecimal valorTransacao;
    private String saidaRecurso;
    private Integer codigoSaidaRecurso;
    private String descricaoSaidaRecurso;
    private PendenciaDTO pendencia;
    private String linha;

    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private String cmc7;
    private Integer nrAgencia;
    private Long nrContaCredito;
    private String numeroCheque;
    private Long numeroContaCheque;

    private EnumTipoConta tipoConta;
    private EnumTipoModalidade tipoModalidade;

    @JsonInclude(JsonInclude.Include.NON_DEFAULT)
    private Long conta;
    private String numeroDocumento;
    private Integer ordemTitular;
}
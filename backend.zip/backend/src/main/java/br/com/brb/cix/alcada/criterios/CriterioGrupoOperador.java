package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.grupo.Grupo;
import br.com.brb.cix.domain.model.grupo.GrupoRepository;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.security.OperadorLogado;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
public class CriterioGrupoOperador implements CriterioAlcada {

    @Autowired
    private OperadorLogado operadorLogado;
    @Autowired
    private GrupoRepository grupoRepository;

    @Override
    public String getNomeCriterio() {
        return "Grupo do Operador";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return false; // Não é possível desabilitar o critério "Grupo do Operador"
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        Set<Long> gruposOperador = regra.getGruposOperador().stream()
                .map(Grupo::getCodigo)
                .collect(Collectors.toSet());

        // O não preenchimento dos grupos de operador equivale a todos os grupos
        if (gruposOperador.isEmpty()) {
            log.debug("gruposOperador: {}", gruposOperador);
            return true;
        }

        Long grupoOperador = grupoRepository.findByCodigo(operadorLogado.getCodigoGrupo()).getCodigo();
        log.debug("gruposOperador: {}, grupoOperador: {}", gruposOperador, grupoOperador);

        return gruposOperador.contains(grupoOperador);
    }
}

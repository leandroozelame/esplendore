package br.com.brb.cix.dto;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class SuprirNumerarioRegraDTO {
    private BigDecimal valorSuprido;
    private BigDecimal valorOriginalRetido;
    private String tipoSuprimento;
}
package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoExtratoDepositoIdentificado implements EnumDominio{
    MENSAL(1, "Mensal"), 
    POR_PERIODO(2, "Por período");
	
    private static final Map<Integer, EnumTipoExtratoDepositoIdentificado> MAP = new HashMap<>();
    
    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;

    static {
        for (EnumTipoExtratoDepositoIdentificado e : EnumTipoExtratoDepositoIdentificado.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoExtratoDepositoIdentificado get(int codTipoExtrato) {
        return MAP.get(codTipoExtrato);
    }
    
    @JsonCreator
    public static EnumTipoExtratoDepositoIdentificado criaEnum(int codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
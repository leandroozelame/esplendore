package br.com.brb.cix.domain.model.chequerecebido;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.terminal.Terminal;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "TB_CHEQUE_RECEBIDO")
public class ChequeRecebido {

    private static final long serialVersionUID = 8285009590510519138L;

    @EmbeddedId
    private ChequeRecebidoId id;
    
    @Column(name = "CD_CMC7", nullable = false)
    private String cmc7;
    
    @Column(name = "VL_CHEQUE", nullable = false)
    private BigDecimal valorCheque;
    
    @Column(name = "CD_UNIDADE", nullable = false)
    private Long cdUnidade;
    
    @Column(name = "CD_MODULO", nullable = false)
    private Integer cdModulo;
    
    @ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;
    
    @Column(name = "NR_TRANSACAO")
    private Long nrTransacao;
    
    @Column(name = "NR_NSU")
    private Long nsu;
    
    @Column(name = "DT_RECEBIMENTO")
    private Date dtRecebimento;
}

package br.com.brb.cix.dto;

public class ConsultaCodigoPagamentoGpsDTO {

      private Integer codigo;
      
      public ConsultaCodigoPagamentoGpsDTO(){};
      
      public Integer getCodigo(){
          return this.codigo;
      }
      
      public void setCodigo(Integer codigo){
          this.codigo = codigo;
      }
}
package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SupertransacaoDTO extends ContaTipoDTO {

	private Long id;
	private FormaPagamentoDTO formaMovimentacao;
	private String cabecalhoFormaMovimentacao;
	private List<Integer> funcionalidades;
	private Integer status;
	private List<TransacaoDTO> transacoes;
	@LogValorTransacao
	private BigDecimal subtotal;
	private BigDecimal valorTarifasDinheiro;
	private PendenciaDTO pendencia;
	private Long nsu;
	private Date dataInicioExecucao;
	
	private Long numeroFichaContabil;
	private BigDecimal valorFichaContabil;
	private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
	private Integer numeroCheque;
	private BigDecimal valorCheque;
	private Long numeroContaCheque;
	private String cmc7;
	private String matriculaSupervisor;
	private String numeroDocumento;
	private Date dataDocumento;
	
	public SupertransacaoDTO() {
		this.transacoes = new ArrayList<>();
		this.subtotal = new BigDecimal(0);
	}
}

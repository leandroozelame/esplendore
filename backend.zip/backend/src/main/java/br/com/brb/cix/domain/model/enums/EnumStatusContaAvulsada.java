package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumStatusContaAvulsada implements EnumDominio {
	AVULSADA_NORMAL(0, "Não"),
	AVULSADA_AGENCIA(1, "Conta Avulsada Agência"),
	AVULSADA_CCF(2, "Conta Avulsada CCF");

    private static final Map<Integer, EnumStatusContaAvulsada> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumStatusContaAvulsada e : EnumStatusContaAvulsada.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumStatusContaAvulsada get(int codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumStatusContaAvulsada criaEnum(Object tipo) {
        EnumStatusContaAvulsada retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumStatusContaAvulsada criaEnumString(String descricao) {
        EnumStatusContaAvulsada retorno = null;
        Iterator<Map.Entry<Integer, EnumStatusContaAvulsada>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumStatusContaAvulsada> par = it.next();
            if (par.getValue().name().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            } else if (par.getValue().getDescricao().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

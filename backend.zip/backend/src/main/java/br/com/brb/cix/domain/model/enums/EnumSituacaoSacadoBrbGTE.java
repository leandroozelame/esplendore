package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

/*
    Informações replicadas do Sistema GTE - TB_SITUACAO_SACADO_BRB
 */
@AllArgsConstructor
public enum EnumSituacaoSacadoBrbGTE implements EnumDominio {
    AGUARDANDO_FORMALIZACAO(0, "Aguardando Formalização"),

    INCLUSAO_SOLICITADA(1, "Inclusão Solicitada"),

    INCLUSAO_COM_ERRO_NA_CIP(2, "Inclusão com erro na CIP"),

    ATIVO(3, "Ativo"),

    EXCLUSAO_SOLICITADA(4, "Exclusão Solicitada"),

    EXCLUSAO_COM_ERRO_NA_CIP(5, "Exclusão com erro na CIP"),

    EXCLUIDO(6, "Excluído"),

    ALTERACAO_COM_ERRO_NA_CIP(7, "Alteração com erro na CIP");

    private static final Map<Integer, EnumSituacaoSacadoBrbGTE> MAP = new HashMap<>();

    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;

    static {
        for (EnumSituacaoSacadoBrbGTE e : EnumSituacaoSacadoBrbGTE.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumSituacaoSacadoBrbGTE get(int codigo) {
        return MAP.get(codigo);
    }

    public static EnumSituacaoSacadoBrbGTE criaEnum(String descricao) {
        EnumSituacaoSacadoBrbGTE retorno = null;
        Iterator<Map.Entry<Integer, EnumSituacaoSacadoBrbGTE>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumSituacaoSacadoBrbGTE> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @JsonCreator
    public static EnumSituacaoSacadoBrbGTE criaEnum(int codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

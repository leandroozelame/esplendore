package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LancamentoEstornavelDTO {
    private Long tctCod;
    private String tctDescricao;
    private Long tctEstorno;
    private Long nsu;
    private String matriculaOperador;
    @LogValorTransacao
    private BigDecimal valor;
    private Date dataHora;
}
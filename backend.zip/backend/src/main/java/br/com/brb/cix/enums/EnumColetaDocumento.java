package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumColetaDocumento implements EnumDominio{
	CHEQUE_BRB(1, "Cheque BRB"),
	CHEQUE_OUTROS_BANCOS(2, "Cheque Externo"), 
    CHEQUE_LIQUIDADO(3, "Cheque Pago/Liquidado"),
    TITULOS_OUTROS_BANCOS(4, "Títulos Outros Bancos");

	@Getter
	private final Integer codigo;
	@Getter
	private final String descricao;
	private static final Map<Integer, EnumColetaDocumento> MAP_ENUMCOLETA = new ConcurrentHashMap<>();

	static {
		for (EnumColetaDocumento e : EnumColetaDocumento.values()) {
			MAP_ENUMCOLETA.put(e.getCodigo(), e);
		}
	}

	@JsonCreator	
	public static EnumColetaDocumento get(int codigo) {
		return MAP_ENUMCOLETA.get(codigo);
	}
	
	@Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }	
}
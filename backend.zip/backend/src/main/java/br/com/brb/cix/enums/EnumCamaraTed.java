package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Enum camara ted.
 * 
 * @author rafael.nunes - 11/05/2022 - Implementacao.
 */
@AllArgsConstructor
public enum EnumCamaraTed implements EnumDominio {
	
	STR(1, "STR"),
	CIP(2, "CIP");
	
    @Getter
    private final Integer codigo;

    @Getter
    private final String descricao;
    
    private static final Map<Integer, EnumCamaraTed> MAP_CAMARA_TED = new ConcurrentHashMap<>();

    static {
        for (EnumCamaraTed e : EnumCamaraTed.values()) {
            MAP_CAMARA_TED.put(e.getCodigo(), e);
        }
    }

    @JsonCreator    
    public static EnumCamaraTed get(int codigo) {
        return MAP_CAMARA_TED.get(codigo);
    }
    
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

package br.com.brb.cix.domain.model.chequerecebido;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.data.jpa.repository.Query;

import br.com.brb.cix.domain.model.terminal.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChequeRecebidoRepository extends JpaRepository<ChequeRecebido, ChequeRecebidoId> {
    ChequeRecebido findByIdAndDtRecebimento(ChequeRecebidoId id, Date dtRecebimento);
   
    @Query(value = "SELECT * "
            + "FROM {h-schema}TB_CHEQUE_RECEBIDO "
            + "WHERE CD_CMC7 = ?1", nativeQuery = true)
    ChequeRecebido findByCmc7(String cmc7);
    
    ChequeRecebido findByValorChequeAndCdUnidadeAndDtRecebimentoAndTerminal(BigDecimal valorCheque, Long cdUnidade, Date dtRecebimento, Terminal terminal);
}
package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class DepositoContaIdentificadoDTO extends AbstractDTO {
    private Long nrConta;
    private Integer nrAgencia;
    private String nomeTitular;
    private EnumTipoConta tipoDeConta;
    private EnumTipoModalidade modalidadeDeConta;
    private String tipoMovimentacao;
    private BigDecimal valorDinheiro = BigDecimal.ZERO;
    private BigDecimal valorChequeBRB = BigDecimal.ZERO;
    private BigDecimal valorChequeExterno = BigDecimal.ZERO;
    @LogValorTransacao
    private BigDecimal valorTotal = BigDecimal.ZERO;
    private String finalidade;
    private Long codigoTransacao;
    private String cpfCnpj;
    private String depositante;
    private boolean gaveta;
    private List<ChequeRecebidoDTO> chequesBRB = new ArrayList<>();
    private List<ChequeRecebidoDTO> chequesExterno = new ArrayList<>();
    private EnumFormaMovimentacao formaMovimentacao;
}
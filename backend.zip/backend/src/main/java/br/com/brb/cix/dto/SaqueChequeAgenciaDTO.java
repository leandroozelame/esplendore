package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**@auto
 * @author u654764
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class SaqueChequeAgenciaDTO extends AbstractDTO {  
    private EnumFormaMovimentacao formaMovimentacao;
    private Long nrConta;
    private Integer nrAgencia;
    private String nomeTitular;
    private EnumTipoConta tipoDeConta;
    private String modalidadeDeConta;
    private Long codigoTransacao;
    private Long tctCod;
    private String tipoMovimentacao;
    private String linha;
    private Integer nrCheque;
    private boolean gaveta;
    @LogValorTransacao
    private BigDecimal valorChequeBRB = BigDecimal.ZERO;
    private PendenciaDTO pendencia;
}
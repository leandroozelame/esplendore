package br.com.brb.cix.config;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.UUID;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
@Slf4j
public class RequestLoggingFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        MDC.put("requestId", UUID.randomUUID().toString());

        long timestampInicial = System.currentTimeMillis();

        String url = getURL(request);
        log.info("{}", url);

        try {
            filterChain.doFilter(request, response);
        } finally {

            int status = response.getStatus();
            long tempoDecorrido = System.currentTimeMillis() - timestampInicial;

            log.info("Status {} - {}ms - {}", status, tempoDecorrido, url);

            MDC.remove("requestId");
        }
    }

    private String getURL(HttpServletRequest request) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(request.getMethod());
        stringBuilder.append(" ");
        stringBuilder.append(request.getContextPath());
        stringBuilder.append(request.getServletPath());
        if (request.getQueryString() != null) {
            stringBuilder.append("?");
            stringBuilder.append(request.getQueryString());
        }
        stringBuilder.append(" - ");
        stringBuilder.append(request.getRemoteAddr());
        return stringBuilder.toString();
    }
}
package br.com.brb.cix.dto;

import java.util.ArrayList;
import java.util.List;

import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class MenuDTO {
    @Data
    class SubItem {
        private String subItem;
        private Integer sequencial;
        private String icone;
        private String rota;
        @JsonIgnore
        private Long codigo;
    }

    @Data
    class Item {
        private String item;
        private Integer sequencial;
        private String icone;
        private String rota;
        @JsonIgnore
        private Long codigo;
        private List<SubItem> subItens = new ArrayList<>();
    }

    private List<Item> menu = new ArrayList<>();

    public MenuDTO(List<Funcionalidade> funcionalidades) {
        for (Funcionalidade funcionalidade : funcionalidades) {
            if (funcionalidade.getFuncionalidadePai() == null) {
                Item item = new Item();

                item.item = funcionalidade.getNome();
                item.sequencial = funcionalidade.getCodigoMenu();
                item.codigo = funcionalidade.getCodigo();
                item.rota = funcionalidade.getRota();
                
                menu.add(item);
            } else {
                SubItem subItem = new SubItem();

                subItem.subItem = funcionalidade.getNome();
                subItem.sequencial = funcionalidade.getCodigoMenu();
                subItem.codigo = funcionalidade.getCodigo();
                subItem.rota = funcionalidade.getRota();
                
                for (Item item : menu) {
                    if (item.getCodigo().equals(funcionalidade.getFuncionalidadePai())) {
                        item.subItens.add(subItem);
                        break;
                    }
                }
            }
        }
    }
}
package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumOperacaoEmprestimo implements EnumDominio {
    OPERACAO_CONSULTA_EMPRESTIMO(1, "Consultar Empréstimo"),
    OPERACAO_CONFIRMACAO_EMPRESTIMO(2, "Confirmação de Empréstimo");

    private static final Map<Integer, EnumOperacaoEmprestimo> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumOperacaoEmprestimo e : EnumOperacaoEmprestimo.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumOperacaoEmprestimo get(int codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumOperacaoEmprestimo criaEnum(Object tipo) {
        EnumOperacaoEmprestimo retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumOperacaoEmprestimo criaEnumString(String descricao) {
        EnumOperacaoEmprestimo retorno = null;
        Iterator<Map.Entry<Integer, EnumOperacaoEmprestimo>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumOperacaoEmprestimo> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

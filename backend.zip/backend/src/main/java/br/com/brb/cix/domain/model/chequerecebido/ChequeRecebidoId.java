package br.com.brb.cix.domain.model.chequerecebido;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class ChequeRecebidoId implements Serializable {

    private static final long serialVersionUID = -6382645111104393928L;

    @Column(name = "NR_CHEQUE", nullable = false)
    private Integer nrCheque;
    
    @Column(name = "CD_BANCO", nullable = false)
    private Integer nrBanco;
    
    @Column(name = "NR_AGENCIA", nullable = false)
    private Integer nrAgencia;
    
    @Column(name = "NR_COMPENSACAO", nullable = false)
    private Integer nrCompensacao;
    
    @Column(name = "NR_CONTA_CHEQUE", nullable = false)
    private Long nrConta;
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import br.com.brb.cix.enums.EnumTipoTransacao;
import br.com.brb.cix.enums.EnumTipoTransacaoGaveta;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GavetaDTO {
    private Long id;
    private Date dataOperacao;
    private String Ip;   
    private Boolean statusAtiva;
    private List<GavetaNumerarioDTO> listaNumerarios;
    private List<GavetaNumerarioDTO> listaNumerariosFisico;
    private EnumTipoTransacaoGaveta tipoTransacaoGaveta;
    private EnumTipoTransacao tipoTransacao;
    // PAGAMENTO E RECEBIMENTO
    private BigDecimal valorTransacao;
    // RECEBIMENTO
    private BigDecimal valorEntregueRecebimento;
    private BigDecimal troco;
    // TROCA NUMERÁRIO
    private BigDecimal valorEntregueTroca;
    private BigDecimal valorRecebidoTroca;
    private List<GavetaNumerarioDTO> listaEntradaTroca;
    private List<GavetaNumerarioDTO> listaSaidaTroca;
    private String saldoDiferenca;
    private String textoResumo;
}
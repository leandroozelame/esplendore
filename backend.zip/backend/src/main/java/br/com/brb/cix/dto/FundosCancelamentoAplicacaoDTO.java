package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.ws.consulta.dto.RespostaConsultaFundosCancelamento;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FundosCancelamentoAplicacaoDTO extends RespostaConsultaFundosCancelamento {
	private List<FundoCancelamentoAplicacaoDTO> fundosCancelamentoAplicacao;
}
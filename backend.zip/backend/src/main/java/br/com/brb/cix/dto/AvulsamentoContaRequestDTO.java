package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter @Setter
public class AvulsamentoContaRequestDTO {
    private Long agencia;
    private Long conta;
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade modalidade;
    private Boolean indicadorAvulsada;
}

package br.com.brb.cix.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ConsultaInformacoesContaDTO extends AbstractDTO{
    @NotNull
    private Integer codigoAgencia;
    @NotNull
    private Long numeroConta;
    private Long numeroCPF;
    private Long numeroContaOrigem;
    private String terminal;
    private Integer tipoConta;
    private String usuario;
    private Boolean flagRecuperaSaldosDaConta = true;

}

package br.com.brb.cix.dto;


import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class BobinaDTO extends AbstractDTO {
    private Long codigo;
    private Date dataAbertura;
    private Date dataFechamento;
    private Long matriculaOperador;
    private Long bobinaPai;
    private TerminalDTO terminal;
    private String textoBobina;
    private String textoBobinaHtml;
}
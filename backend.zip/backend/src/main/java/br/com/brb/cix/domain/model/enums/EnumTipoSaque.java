package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author u653949
 *
 */
@AllArgsConstructor
@Getter
public enum EnumTipoSaque implements EnumDominio {
    SAQUE_CONTA_JUDICIAL(560, "Saque Conta Judicial"),
    SAQUE_GUIA_CONTA_CORRENTE(1514, "Saque Guia de Retirada Conta Corrente"), 
    SAQUE_GUIA_CONTA_SALARIO(1515, "Saque Guia de Retirada Conta Salário"), 
    SAQUE_GUIA_POUPANCA_INTEGRADA(2510, "Saque Guia de Retirada Conta Poupança/Integrada"), 
    SAQUE_CHEQUE_AGENCIA(1518, "Saque Cheque Agência"), 
    SAQUE_CHEQUE_INTERAGENCIA(1519, "Saque Cheque Interagência"),
    SAQUE_BENEFICIO_SOCIAL(3595, "Saque Benefício Social"),
    SAQUE_BENEFICIO_EVENTUAL(182, "Saque Benefício Eventual"),
    SAQUE_INSS(3560, "Saque INSS"),
    SAQUE_ELETRONICO_CONTA_CORRENTE(1550, "Saque Eletrônico Conta Corrente"),
    SAQUE_ELETRONICO_CONTA_SALARIO(1555, "Saque Eletrônico Conta Salário"),
    SAQUE_ELETRONICO_POUPANCA_INTEGRADA(2512, "Saque Eletrônico Poupança/Integrada");
    
    private Integer codigo;
    private String descricao;

    static List<EnumTipoSaque> listaEnum = Arrays.asList(EnumTipoSaque.values());
    private static final Map<Integer, EnumTipoSaque> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

    /**
     * @param codigo
     * @return
     */
    @JsonCreator
    public static EnumTipoSaque get(int codigo) {
        return MAP.get(codigo);
    }

    /**
     * @return
     */
    public static List<Object> listarTiposSaque() {
        return listaEnum.stream().map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

package br.com.brb.cix.dto;


import javax.persistence.Lob;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsultaOnlineBobinaCaixaAdmDTO {
    private Long sqBobina;
    @Lob
    private String txBobina;
    private Long nrMatriculaOperador;
    private String oprNom;
    private String nrTerminal; 
    private String textBobina;
    
	public ConsultaOnlineBobinaCaixaAdmDTO(Long sqBobina) {
		super();
		this.sqBobina = sqBobina;
	}
    
}
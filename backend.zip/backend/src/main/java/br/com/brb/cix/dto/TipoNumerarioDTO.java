package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * @author u653865
 *
 */
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TipoNumerarioDTO extends AbstractDTO {

    private Long id;
    private String descricao;
    private Integer numeroDescricaoNumerario;
}

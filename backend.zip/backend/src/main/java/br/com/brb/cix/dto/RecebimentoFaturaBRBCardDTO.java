package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RecebimentoFaturaBRBCardDTO extends ContaTipoDTO {
    private EnumFormaMovimentacao formaMovimentacao;
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Long numeroFichaContabil;
    private Long codigoTransacao;
    private String numeroDocumento;
    private Date dataDocumento;
    @LogValorTransacao
    private BigDecimal valorTransacao;
    private String numeroCartao;
    private Integer numeroCheque;
    private String codigoBarras;
    private Date dataVencimento;
    //private BigDecimal valorMinimo;
    private BigDecimal valorTotal;
    // cheque
    private String cmc7;
    private Integer formaMovimentacaoFinanceira;
}
package br.com.brb.cix.config;

import br.com.brb.cix.domain.model.enums.*;
import br.com.brb.cix.dto.AlteracaoSenhaContaCaixaDTO;
import br.com.brb.cix.enums.EnumTipoEventoAuditoria;
import br.com.brb.cix.enums.EnumTipoTransacao;
import br.com.brb.cix.ws.dto.entrada.EntradaAlteracaoSenhaContaCaixaDTO;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.modelmapper.Converter;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.config.Configuration.AccessLevel;
import org.modelmapper.convention.NamingConventions;
import org.modelmapper.spi.MappingContext;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.context.annotation.FilterType;

@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "10m")
@EnableCaching
@ComponentScan(basePackages = { "br.com.brb" },excludeFilters = {
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CustomCorsFilter.class) })
public class ApplicationBasicConfig {

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("situacaoLegados");
    }

	@Bean
	public ModelMapper modelMapper() {
		ModelMapper modelMapper = new ModelMapper();
        modelMapper.getConfiguration().setFieldMatchingEnabled(true)
                .setFieldAccessLevel(AccessLevel.PRIVATE)
                .setSourceNamingConvention(NamingConventions.JAVABEANS_MUTATOR);
      
            modelMapper.addConverter(EnumTipoPessoaConverter);
            modelMapper.addConverter(EnumTipoContaConverter);
            modelMapper.addConverter(EnumTipoContaReverseConverter);

            modelMapper.addConverter(EnumStatusContaConverter);
            modelMapper.addConverter(EnumStatusContaAvulsadaConverter);
            modelMapper.addConverter(EnumTipoTitularidadeContaConverter);

            modelMapper.addConverter(EnumTipoModalidadeConverter);
            modelMapper.addConverter(EnumTipoModalidadeReverseConverter);
            
            modelMapper.addConverter(EnumValorRegraConverter);
            modelMapper.addConverter(EnumValorRegraReverseConverter);
            
            modelMapper.addConverter(EnumValorRegraTipoPessoaConverter);
            modelMapper.addConverter(EnumValorRegraTipoPessoaReverseConverter);
            
            modelMapper.addConverter(EnumTipoTransacaoConverter);
            modelMapper.addConverter(EnumTipoTransacaoReverseConverter);

            modelMapper.addConverter(EnumTipoEventoAuditoriaConverter);
            modelMapper.addConverter(EnumTipoEventoAuditoriaReverseConverter);            
            
            modelMapper.addMappings(EntradaAlteracaoSenhaContaCaixaDTOMappings);

            return modelMapper;
	}
        
        private Converter<Integer, EnumTipoPessoa> EnumTipoPessoaConverter = new Converter<Integer, EnumTipoPessoa>()
        {
            @Override
            public EnumTipoPessoa convert(MappingContext<Integer, EnumTipoPessoa> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoPessoa.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumTipoConta> EnumTipoContaConverter = new Converter<Integer, EnumTipoConta>()
        {
            @Override
            public EnumTipoConta convert(MappingContext<Integer, EnumTipoConta> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoConta.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumTipoConta, Integer> EnumTipoContaReverseConverter = new Converter<EnumTipoConta, Integer>()
        {
            @Override
            public Integer convert(MappingContext<EnumTipoConta, Integer> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoConta.criaEnum(mappingContext.getSource()).getCodigo();
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumStatusConta> EnumStatusContaConverter = new Converter<Integer, EnumStatusConta>()
        {
            @Override
            public EnumStatusConta convert(MappingContext<Integer, EnumStatusConta> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumStatusConta.get(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumTipoTitularidadeConta> EnumTipoTitularidadeContaConverter = new Converter<Integer, EnumTipoTitularidadeConta>()
        {
            @Override
            public EnumTipoTitularidadeConta convert(MappingContext<Integer, EnumTipoTitularidadeConta> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoTitularidadeConta.get(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumTipoModalidade> EnumTipoModalidadeConverter = new Converter<Integer, EnumTipoModalidade>()
        {
            @Override
            public EnumTipoModalidade convert(MappingContext<Integer, EnumTipoModalidade> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoModalidade.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumTipoModalidade, Integer> EnumTipoModalidadeReverseConverter = new Converter<EnumTipoModalidade, Integer>()
        {
            @Override
            public Integer convert(MappingContext<EnumTipoModalidade, Integer> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoModalidade.criaEnum(mappingContext.getSource()).getCodigo();
                }
                return null;
            }
        };

        private Converter<Character, EnumValorRegra> EnumValorRegraConverter = new Converter<Character, EnumValorRegra>()
        {
            @Override
            public EnumValorRegra convert(MappingContext<Character, EnumValorRegra> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumValorRegra.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumValorRegra, Character> EnumValorRegraReverseConverter = new Converter<EnumValorRegra, Character>()
        {
            @Override
            public Character convert(MappingContext<EnumValorRegra, Character> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumValorRegra.criaEnum(mappingContext.getSource()).getCodigo();
                }
                return null;
            }
        };
        
        private Converter<Character, EnumValorRegraTipoPessoa> EnumValorRegraTipoPessoaConverter = new Converter<Character, EnumValorRegraTipoPessoa>()
        {
            @Override
            public EnumValorRegraTipoPessoa convert(MappingContext<Character, EnumValorRegraTipoPessoa> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumValorRegraTipoPessoa.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumValorRegraTipoPessoa, Character> EnumValorRegraTipoPessoaReverseConverter = new Converter<EnumValorRegraTipoPessoa, Character>()
        {
            @Override
            public Character convert(MappingContext<EnumValorRegraTipoPessoa, Character> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumValorRegraTipoPessoa.criaEnum(mappingContext.getSource()).getCodigo();
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumTipoTransacao> EnumTipoTransacaoConverter = new Converter<Integer, EnumTipoTransacao>()
        {
            @Override
            public EnumTipoTransacao convert(MappingContext<Integer, EnumTipoTransacao> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoTransacao.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumTipoTransacao, Integer> EnumTipoTransacaoReverseConverter = new Converter<EnumTipoTransacao, Integer>()
        {
            @Override
            public Integer convert(MappingContext<EnumTipoTransacao, Integer> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoTransacao.criaEnum(mappingContext.getSource()).getCodigo().intValue();
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumTipoEventoAuditoria> EnumTipoEventoAuditoriaConverter = new Converter<Integer, EnumTipoEventoAuditoria>()
        {
            @Override
            public EnumTipoEventoAuditoria convert(MappingContext<Integer, EnumTipoEventoAuditoria> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoEventoAuditoria.criaEnum(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private Converter<EnumTipoEventoAuditoria, Integer> EnumTipoEventoAuditoriaReverseConverter = new Converter<EnumTipoEventoAuditoria, Integer>()
        {
            @Override
            public Integer convert(MappingContext<EnumTipoEventoAuditoria, Integer> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumTipoEventoAuditoria.criaEnum(mappingContext.getSource()).getCodigo().intValue();
                }
                return null;
            }
        };
        
        private Converter<Integer, EnumStatusContaAvulsada> EnumStatusContaAvulsadaConverter = new Converter<Integer, EnumStatusContaAvulsada>()
        {
            @Override
            public EnumStatusContaAvulsada convert(MappingContext<Integer, EnumStatusContaAvulsada> mappingContext) {
                if(mappingContext.getSource() != null) {
                    return EnumStatusContaAvulsada.get(mappingContext.getSource());
                }
                return null;
            }
        };
        
        private PropertyMap<AlteracaoSenhaContaCaixaDTO, EntradaAlteracaoSenhaContaCaixaDTO> EntradaAlteracaoSenhaContaCaixaDTOMappings = new PropertyMap<AlteracaoSenhaContaCaixaDTO, EntradaAlteracaoSenhaContaCaixaDTO>()
        {
            @Override
            protected void configure() {
            	map().setSenha(source.getSenhaNova());
            }
        };
}


package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TarifaDTO extends ContaTipoDTO {
    
    private EnumFormaMovimentacao formaMovimentacao;
    @LogValorTransacao
    private BigDecimal valorTotal;
    private String numeroDocumento;
    private Date dataDocumento;
    private Long numeroProtocolo;
    private String descricao;
    
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Integer numeroCheque;
    private Long numeroContaCheque;
    private String cmc7;
    private String matriculaSupervisor;

}

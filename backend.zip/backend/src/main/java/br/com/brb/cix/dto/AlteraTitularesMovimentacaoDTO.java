package br.com.brb.cix.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AlteraTitularesMovimentacaoDTO {

    private String tipoAutorizador;
    private long cpf;
    private Integer quantidadeMinimaAssinaturas;
}


package br.com.brb.cix.domain.model.transacaoreenvio;

import br.com.brb.cix.enums.EnumTransacaoEnvioStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TransacaoReenvioFactory {

    @Autowired
    private TransacaoStatusRepository transacaoStatusRepository;
           
    public TransacaoReenvioFactory() {
        
    }
    
    public TransacaoReenvio criaReenvioStatusDefaultCriado(){
        TransacaoReenvio novoRegistroReenvio = new TransacaoReenvio();
        TransacaoStatus statusCriado = transacaoStatusRepository.findByCodigoSituacao(EnumTransacaoEnvioStatus.CRIADO.getCodigo());
        novoRegistroReenvio.setTransacaoStatus(statusCriado);
        
        return novoRegistroReenvio;
    }

    
}

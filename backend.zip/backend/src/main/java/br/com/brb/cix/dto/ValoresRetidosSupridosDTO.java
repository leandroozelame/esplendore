package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ValoresRetidosSupridosDTO {
    
    private BigDecimal valorRetido;
    private List<ValoresSupridosDTO> valoresSupridosDTO;
    private Long sequenceValorRetido;
}
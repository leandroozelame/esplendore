package br.com.brb.cix.auditoria;

import br.com.brb.cix.enums.EnumCanal;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumCanalConverter implements AttributeConverter<EnumCanal, Integer> {

    @Override
    public Integer convertToDatabaseColumn(EnumCanal enumCanal) {
        return enumCanal != null ? enumCanal.getCodigo() : null;
    }

    @Override
    public EnumCanal convertToEntityAttribute(Integer codigo) {
        return EnumCanal.get(codigo);
    }
}

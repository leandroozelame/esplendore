package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumSituacaoSacadoBrbGTE;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AgregadoDTO extends AbstractDTO {
    private Long cpfCnpj;
    private String nome;
    private EnumSituacaoSacadoBrbGTE situacao;
    private EnumTipoPessoa tipoPessoa;
}
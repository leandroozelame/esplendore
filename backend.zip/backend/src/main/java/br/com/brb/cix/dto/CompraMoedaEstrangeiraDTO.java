package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CompraMoedaEstrangeiraDTO extends ContaTipoDTO {
    
    private EnumFormaMovimentacao formaMovimentacao;
    private String tipoMoeda;
    private String simbolo;
    private BigDecimal valorMoedaEstrangeira;
    private BigDecimal valorMoedaNacional;
    private BigDecimal valorIOF;
    private Long numeroProtocolo;
    private BigDecimal valorTarifa;
    @LogValorTransacao
    private BigDecimal valorTotal;
    private String nomeTitular1;
    
    //P/ Depósito
    private String tipoMovimentacao;
    private BigDecimal valorDinheiro = BigDecimal.ZERO;
    private String cpfCnpjDepositante;
    private PendenciaDTO pendencia;
}

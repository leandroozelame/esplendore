package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumStatusConta implements EnumDominio {
	
	LIBERADA(0, "Liberada (sem bloqueio)"),
	BLQ_DEPOSITO(1, "Bloqueada para depósito"),
	BLQ_SAQUE(2, "Bloqueada para saque"),
	BLQ_DEPSAQ(4, "Bloqueada para depósito e saque"),
	BLQ_TOTAL(5, "Bloqueada totalmente (dep/saq/cad)"),
	BLQ_JUDICIAL(6, "Bloqueada Judicialmente"),
	EXCLUSAO(7, "Com indicador de exclusão"),
	DEFINITIVO(8, "Bloqueada definitivamente");
	
    private static final Map<Integer, EnumStatusConta> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumStatusConta e : EnumStatusConta.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumStatusConta get(int codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumStatusConta criaEnum(String statusConta) {
        EnumStatusConta retorno = null;
        Iterator<Map.Entry<Integer, EnumStatusConta>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumStatusConta> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(statusConta)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}
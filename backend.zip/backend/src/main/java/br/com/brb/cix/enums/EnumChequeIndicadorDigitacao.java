package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumChequeIndicadorDigitacao implements EnumDominio{
	NAO_INFORMADO(0, "Não Informado"),
	DISPOSITIVO(1, "Dispositivo"),
    MANUAL(2, "Manual");

	@Getter
	private final Integer codigo;
	@Getter
	private final String descricao;
	private static final Map<Integer, EnumChequeIndicadorDigitacao> MAP_ENUM_CHEQUE_INDICADOR_DIGITACAO = new ConcurrentHashMap<>();

	static {
		for (EnumChequeIndicadorDigitacao e : EnumChequeIndicadorDigitacao.values()) {
			MAP_ENUM_CHEQUE_INDICADOR_DIGITACAO.put(e.getCodigo(), e);
		}
	}

	@JsonCreator	
	public static EnumChequeIndicadorDigitacao get(int codigo) {
		return MAP_ENUM_CHEQUE_INDICADOR_DIGITACAO.get(codigo);
	}
	
	@Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }	
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.domain.model.enums.EnumStatusConta;
import br.com.brb.cix.domain.model.enums.EnumStatusContaAvulsada;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.domain.model.enums.EnumTipoMovimentacao;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.domain.model.enums.EnumTipoTitularidadeConta;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class InformacoesContaDTO {
    private Integer agencia;
    private Integer ptaOrigem;
    private Integer ordemTitular;
    private Integer codigoPerfilConta;
    private String descricaoPerfilConta;
    private Long cpfCnpjTitular1;
    private Long cpfCnpjTitular2;
    private Boolean indicadorContaMillenium;
    private Boolean indicadorBloqueioJudicial;
    private EnumTipoModalidade modalidade;
    private String nomeTitular1;
    private String nomeTitular2;
    private BigDecimal saldoDisponivel;
    private BigDecimal saldoDisponivelSemCheque;
    private BigDecimal saldoResgateAutomatico;
    private EnumStatusConta status;
    private EnumTipoConta tipo;
    private EnumTipoPessoa tipoPessoa;
    private EnumTipoTitularidadeConta tipoTitularidadeConta;
    private EnumTipoMovimentacao tipoMovimentacao;
    private EnumStatusContaAvulsada avulsa;
	private Boolean indicadorContaEmCCF;
}
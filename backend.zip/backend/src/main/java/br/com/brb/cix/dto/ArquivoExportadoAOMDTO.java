package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class ArquivoExportadoAOMDTO extends AbstractDTO {
    
    private String nomeArquivo;
    private String caminho;
    private String tamanho;
}

package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsultaAutenticidadeINSSDTO {

	private Long numeroBeneficio;
	private String senhaBeneficio;
}

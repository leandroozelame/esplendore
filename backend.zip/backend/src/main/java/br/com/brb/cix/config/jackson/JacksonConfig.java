package br.com.brb.cix.config.jackson;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;

import javax.xml.datatype.XMLGregorianCalendar;

import com.fasterxml.jackson.databind.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import lombok.extern.slf4j.Slf4j;

@Configuration
public class JacksonConfig {
    public static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm:ss");
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    public static final SimpleDateFormat SIMPLE_DATE_ONLY_FORMAT = new SimpleDateFormat("dd/MM/yyyy");
    private static final Locale BRAZIL = new Locale("pt", "BR");
    public static final DecimalFormatSymbols REAL = new DecimalFormatSymbols(BRAZIL);
    public static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("¤ ###,###,##0.00", REAL);

    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();

        objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        objectMapper.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        JavaTimeModule javaTimeModule = new JavaTimeModule();

        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer());
        javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer());
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer());
        javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer());
        javaTimeModule.addSerializer(Date.class, new DateSerializer());
        javaTimeModule.addDeserializer(Date.class, new DateDeserializer());
        javaTimeModule.addSerializer(XMLGregorianCalendar.class, new XmlGregorianCalendarSerializer());
        objectMapper.registerModule(javaTimeModule);
        return objectMapper;
    }

	@Bean
    public ObjectMapper auditoriaObjectMapper() {
        ObjectMapper auditoriaObjectMapper = new ObjectMapper();

        auditoriaObjectMapper.enable(SerializationFeature.INDENT_OUTPUT);
        auditoriaObjectMapper.enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);
        auditoriaObjectMapper.setSerializationInclusion(Include.NON_NULL);
        auditoriaObjectMapper.setPropertyNamingStrategy(new FormataLabels());
             
        SimpleModule module = new SimpleModule();
        
        module.addSerializer(String.class, new MascaraStringSerializer());
        auditoriaObjectMapper.registerModule(module);  

        JavaTimeModule javaTimeModule = new JavaTimeModule();
        
        javaTimeModule.addSerializer(LocalDate.class, new LocalDateSerializer());
        javaTimeModule.addDeserializer(LocalDate.class, new LocalDateDeserializer());
        javaTimeModule.addSerializer(LocalDateTime.class, new LocalDateTimeSerializer());
        javaTimeModule.addDeserializer(LocalDateTime.class, new LocalDateTimeDeserializer());
        javaTimeModule.addSerializer(Date.class, new DateSerializer());
        javaTimeModule.addDeserializer(Date.class, new DateDeserializer());
        javaTimeModule.addSerializer(BigDecimal.class, new BigDecimalMoedaSerializer());
        javaTimeModule.addDeserializer(BigDecimal.class, new BigDecimalMoedaDeserializer());
        javaTimeModule.addSerializer(XMLGregorianCalendar.class, new XmlGregorianCalendarSerializer());
        auditoriaObjectMapper.registerModule(javaTimeModule); 
        return auditoriaObjectMapper;
    }
}

class DateSerializer extends JsonSerializer<Date> {
    @Override
    public void serialize(Date value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        gen.writeString(JacksonConfig.SIMPLE_DATE_FORMAT.format(value));
    }
}

@Slf4j
class DateDeserializer extends JsonDeserializer<Date> {
    @Override
    public Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        try {
            return JacksonConfig.SIMPLE_DATE_FORMAT.parse(p.getValueAsString());
        } catch (ParseException e) {
            log.error("DateDeserializer.deserialize() ERRO: ", e);
            throw new RuntimeException(e);
        }
    }
}

class LocalDateSerializer extends JsonSerializer<LocalDate> {
    @Override
    public void serialize(LocalDate value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        gen.writeString(value.format(JacksonConfig.DATE_FORMATTER));
    }
}

class LocalDateDeserializer extends JsonDeserializer<LocalDate> {
    @Override
    public LocalDate deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return LocalDate.parse(p.getValueAsString(), JacksonConfig.DATE_FORMATTER);
    }
}

class LocalDateTimeSerializer extends JsonSerializer<LocalDateTime> {
    @Override
    public void serialize(LocalDateTime value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        gen.writeString(value.format(JacksonConfig.DATE_TIME_FORMATTER));
    }
}

class LocalDateTimeDeserializer extends JsonDeserializer<LocalDateTime> {
    @Override
    public LocalDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        return LocalDateTime.parse(p.getValueAsString(), JacksonConfig.DATE_TIME_FORMATTER);
    }
}

class BigDecimalMoedaSerializer extends JsonSerializer<BigDecimal> {
    @Override
    public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        value.setScale(2, BigDecimal.ROUND_HALF_UP);
        gen.writeString(JacksonConfig.DECIMAL_FORMAT.format(value));
    }
}

class BigDecimalMoedaDeserializer extends JsonDeserializer<BigDecimal> {
    @Override
    public BigDecimal deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
        return jp.getDecimalValue().setScale(2, BigDecimal.ROUND_HALF_UP);
    }
}

class XmlGregorianCalendarSerializer extends JsonSerializer<XMLGregorianCalendar> {
    @Override
    public void serialize(XMLGregorianCalendar value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        gen.writeString(JacksonConfig.SIMPLE_DATE_ONLY_FORMAT.format(value.toGregorianCalendar().getTime()));
    }
}
package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumModalidadeTransacaoLiberarCreditoRotativo implements EnumDominio {
    CONSULTAR_CONTRATOS(1, "Consultar Contratos Disponíveis"),
    DESBLOQUEAR_CONTRATO(2, "Desbloquear Consulta de Contrato");

    private static final Map<Integer, EnumModalidadeTransacaoLiberarCreditoRotativo> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumModalidadeTransacaoLiberarCreditoRotativo e : EnumModalidadeTransacaoLiberarCreditoRotativo.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumModalidadeTransacaoLiberarCreditoRotativo get(Integer codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumModalidadeTransacaoLiberarCreditoRotativo criaEnum(Object tipo) {
        EnumModalidadeTransacaoLiberarCreditoRotativo retorno = null;
        if ((Character.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumModalidadeTransacaoLiberarCreditoRotativo criaEnumString(String descricao) {
        EnumModalidadeTransacaoLiberarCreditoRotativo retorno = null;
        Iterator<Map.Entry<Integer, EnumModalidadeTransacaoLiberarCreditoRotativo>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumModalidadeTransacaoLiberarCreditoRotativo> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao) || par.getKey().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

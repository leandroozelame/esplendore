/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.dto;

import java.util.Date;

import lombok.*;

/**
 *
 * @author u842773
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class DadosContaDTO {
    private Long conta;
    private Integer tipoConta;
    private Date dataAbertura;
    private Date ultimoMovimento;

    // '1 - Tributada';
    // '2 - Tributada Depósito Judicial';
    // '3 - Isenta Orgão da Administração Pública';
    // '4 - Isenta Medida Judicial';
    // '5 - Isenta Objeto Social';
    // '6 - Isenta Entidade Beneficente de Assistência Social';
    private Character cpmf;
    // P:PAGA
    // N:NÃO PAGA
    // L:NÃO PAGA POR LIMINAR
    private Character impostoRenda;
    // 0:'Bloqueada Judicial';
    // 1:'Ativa';
    // 2:'Paralisada';
    // 3:'Encerrada pelo Cliente';
    // 4:'Encerrada Normas BACEN';
    // 5:'Desativada';
    // 6:'Encerrada pelo Banco';
    // 7:'Bloqueada pelo Sistema';
    // 8:'Transferida';
    // 9:'Encer. Irreg. CPF/CNPJ';
    private Character situacaoConta;
    // 0:'Não Pagamento';
    // 1:'Pagamento GDF';
    // 2:'Pagamento BRB';
    // 3:'Pagamento Empresa Privada';
    // 4:'Pagamento Federal';
    // 5:'Pagamento Municipal';
    // 6:'Pagamento Outros Estados (Exceto GDF)';
    // 7:'Pagamento Programas Sociais';
    private Character tipoPagamento;
    // 0:'Não'
    // 1:'Sim'
    private Character usoSomenteEletronico;
    // 0:'Não';
    // 1:'Adiant. Depos.';
    // 2:'Créd. Liquid.';
    // 3:'Prejuízo';
    // 4:'Despesa Operacional';
    // 5:'IOF a Cobrar';
    // 9:'Em Atraso';
    private Character operacaoCreditoCursoAnormal;
    // 0:'Não';
    // 1:'Avulsada Automação';
    // 2:'Avulsada CCF';
    private Character bloqueioRetiradaCheque;
    // 0:'Não'
    // 1:'Sim'
    private Character situacaoCCF;
    // 1:'Individual';
    // 2:'Conjunta Solidária';
    // 3:'Conjunta não Solidária';
    private Character tipoTitularidade;
    // 0:'Não';
    // 1:'Sim';
    // 2:'Não';
    private Character sobConsultaJudicial;
    // 0:'Não';
    // 1:'Sim';
    private Character resgateAutomatico;

    public DadosContaDTO(Long conta, Integer tipoConta, Date dataAbertura, Date ultimoMovimento, Character cpmf,
            Character situacaoConta, Character tipoPagamento, Character usoSomenteEletronico,
            Character operacaoCreditoCursoAnormal, Character bloqueioRetiradaCheque, Character situacaoCCF,
            Character tipoTitularidade, Character sobConsultaJudicial) {
        this.conta = conta;
        this.tipoConta = tipoConta;
        this.dataAbertura = dataAbertura;
        this.ultimoMovimento = ultimoMovimento;
        this.cpmf = cpmf;
        this.situacaoConta = situacaoConta;
        this.tipoPagamento = tipoPagamento;
        this.usoSomenteEletronico = usoSomenteEletronico;
        this.operacaoCreditoCursoAnormal = operacaoCreditoCursoAnormal;
        this.bloqueioRetiradaCheque = bloqueioRetiradaCheque;
        this.situacaoCCF = situacaoCCF;
        this.tipoTitularidade = tipoTitularidade;
        this.sobConsultaJudicial = sobConsultaJudicial;
    }

    public DadosContaDTO(Long conta, Integer tipoConta, Date dataAbertura, Date ultimoMovimento,
            Character situacaoConta, Character tipoPagamento, Character usoSomenteEletronico,
            Character operacaoCreditoCursoAnormal, Character tipoTitularidade, Character sobConsultaJudicial) {
        this.conta = conta;
        this.tipoConta = tipoConta;
        this.dataAbertura = dataAbertura;
        this.ultimoMovimento = ultimoMovimento;
        this.situacaoConta = situacaoConta;
        this.tipoPagamento = tipoPagamento;
        this.usoSomenteEletronico = usoSomenteEletronico;
        this.operacaoCreditoCursoAnormal = operacaoCreditoCursoAnormal;
        this.tipoTitularidade = tipoTitularidade;
        this.sobConsultaJudicial = sobConsultaJudicial;
    }

    public DadosContaDTO(Long conta, Integer tipoConta, Date dataAbertura, Date ultimoMovimento,
            Character situacaoConta, Character tipoTitularidade, Character sobConsultaJudicial,
            Character resgateAutomatico) {
        this.conta = conta;
        this.tipoConta = tipoConta;
        this.dataAbertura = dataAbertura;
        this.ultimoMovimento = ultimoMovimento;
        this.situacaoConta = situacaoConta;
        this.tipoTitularidade = tipoTitularidade;
        this.sobConsultaJudicial = sobConsultaJudicial;
        this.resgateAutomatico = resgateAutomatico;
    }
}
package br.com.brb.cix.enums;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Origem: Classe la.foton.componente.common.ErrorCode do BLK
 */
@AllArgsConstructor
public enum EnumErrorCodeBLK {
	/** Senha inválida */
	INVALID_PASSWORD(1),
	/** Senha não cadastrada */
	PASSWORD_NOT_FOUND(2),
	/** Senha Bloqueada */
	BLOCKED_PASSWORD(3),
	/** Identificação positiva inválida */
	INVALID_POSITIVE_IDENTIFICATION(4),
	/** Falta identificação positiva prévia */
	NOT_PREVIOUS_IDENTIFICATION(5),
	/** Senha expirada */
	EXPIRED_PASSWORD(6),
	/** Cartão Bloqueado administrativamente */
	ADMINISTRATIVE_BLOCKED_CARD(11),
	/** Cartão bloqueado por uso de senha incorreta */
	PASSWORD_BLOCKED_CARD(12),
	/** Cartão bloqueado */
	BLOCKED_CARD(13),
	/** Cartão Cancelado */
	CANCELLED_CARD(14),
	/** Cartão Inativo */
	INACTIVE_CARD(15),
	/** Cartão Inválido */
	INVALID_CARD(16),
	/** Cartão não Cadastrado */
	CARD_NOT_FOUND(17),
	/** Cartão Vencido */
	EXPIRED_CARD(18),
	/** Via do cartão inválida */
	INVALID_CARD_ORDER(19),
	/** Conta bloqueada judicialmente */
	JUDICIAL_BLOCKED_ACCOUNT(30),
	/** Conta bloqueada */
	BLOCKED_ACCOUNT(31),
	/** Conta com movimentação controlada */
	MOVEMENT_CONTROLED_ACCOUNT(32),
	/** Conta encerrado */
	CLOSED_ACCOUNT(33),
	/** Conta inativa */
	INACTIVE_ACCOUNT(34),
	/** Transação não permitida para esta conta */
	NOT_AUTHORIZED_TRANSACTION(35),
	/** Conta Pendente */
	PENDING_ACCOUNT(36),
	/** Conta não possui cartão */
	ACCOUNT_WITHOUT_CARD(37),
	/** Numero da conta/agência inválida */
	INVALID_ACCOUNT(38),
	/** Tipo de conta inválido */
	INVALID_ACCOUNT_TYPE(39),
	/** Categoria inexistente */
	INVALID_CATEGORY(40),
	/** Conta não encontrada */
	ACCOUNT_NOT_FOUND(41),
	/** Benefício não encontrado */
	BENEFIT_NOT_FOUND(42),
	/** Benefício vencido */
	BENEFIT_EXPIRED(43),
	/** Benefício pago */
	BENEFIT_PAID(44),
	/** Banco não encontrado. */
	BANK_NOT_FOUND(45),
	/** Ponto de atendimento não encontrado. */
	ATENDIMENT_POINT_NOT_FOUND(46),
	/** Conta não possui cliente */
	ACCOUNT_WITHOUT_CLIENT(47),
	/** Agência bloqueada */
	BLOCKED_BRANCH(51),
	/** Agência Fechada */
	CLOSED_BRANCH(52),
	/** Agência não pertence a rede */
	FOREIGNER_BRANCH(53),
	/** Agência inválida / não encontrada */
	INVALID_BRANCH(54),
	/** Agência off line */
	OFFLINE_BRANCH(55),
	/** Sem comunicação com a agência */
	COMUNICATION_PROBLEM(56),
	/** Time out */
	TIME_OUT(57),
	/** Tipo de Agência Inválido */
	INVALID_BRANCH_TYPE(58),
	/** Tipo de Canal de Atendimento inválido */
	INVALID_RELATIONSHIP_CHANNEL(59),
	/** Relacionamento entre Grupo de Formatação e Ponto de Atendimento não encontrado */
	PTA_GFM_RELATIONSHIP_NOT_FOUND(60),
	/** não existe o(s) ponto(s) de atendimento habilitado(s) para o(s) grupo(s) de formatação */
	PTA_GFM_RELATIONSHIP_NOT_ENABLED(61),
	/** Exedeu limite de saque diário */
	CHECKING_DAYLY_LIMIT_EXEEDED(71),
	/** Excedeu quantidade de saques diário */
	DAYLY_NUMBER_OF_CHECKING_EXEEDED(72),
	/** Saldo insuficiente */
	NO_BALANCE(73),
	/** Saldo pendente */
	PENDING_BALANCE(74),
	/** Excedeu limite de saque do cartão */
	CARD_LIMIT_EXEEDED(75),
	/** Bloqueio para depósito inválido */
	INVALID_BLOCKADE(90),
	/** Banco não permite bloqueio de 2 dias para este tipo de depósito */
	INVALID_2_DAY_BLOCKADE(91),
	/** Banco não permite bloqueio de 3 dias para este tipo de depósito */
	INVALID_3_DAY_BLOCKADE(92),
	/** Banco não permite bloqueio de 4 dias para este tipo de depósito */
	INVALID_4_DAY_BLOCKADE(93),
	/** Banco não permite bloqueio de 5 dias para este tipo de depósito */
	INVALID_5_DAY_BLOCKADE(95),
	/** Banco não permite bloqueio de 6 dias para este tipo de depósito */
	INVALID_6_DAY_BLOCKADE(96),
	/** Moeda não aceita ou inválida para esta transação */
	INVALID_CURRENCY(120),
	/** Versão não permitida/inválida */
	INVALID_VERSION(121),
	/** Horário inválido para esta transação */
	INVALID_SCHEDULE(122),
	/** Data de referência invalida */
	INVALID_REFERENCE_DATE(123),
	/** Dado inválido / não consistente */
	INVALID_DATA(124),
	/** Transação não disponível */
	TRANSACTION_UNAVAIBLE(125),
	/** Status da autorização inválido. */
	INVALID_AUTORIZATION_STATUS(126),
	/** Estorno não permitido */
	NOT_AUTHORIZED_REVERSAL(127),
	/** Norma de notificação habilitada. */
	NOTIFICATION_NORM_ENABLED(130),
	/** Norma de notificação desabilitada. */
	NOTIFICATION_NORM_DISABLED(131),
	/** Norma de notificação não cadastrada. */
	NOTIFICATION_NORM_NOT_FOUND(132),
	/** Notificação não cadatrada. */
	NOTIFICATION_NOT_FOUND(133),
	/** Norma de totalização habilitada. */
	TOTALIZATION_NORM_ENABLED(140),
	/** Norma de totalização desabilitada. */
	TOTALIZATION_NORM_DISABLED(141),
	/** Norma de totalização não cadastrada. */
	TOTALIZATION_NORM_NOT_FOUND(142),
	/** Lançamento de totalização não encontrado. */
	REGISTRATION_TOTALIZATION_NOT_FOUND(143),
	/** Horário de formatação não encontrado */
	FORMATING_SCHEDULE_NOT_FOUND(149),
	/** Formatação não encontrada */
	FORMAT_NOT_FOUND(150),
	/** Grupo de Formatação não encontrado */
	GROUP_FORMAT_NOT_FOUND(151),
	/** Número da formatação maior que o número máximo permitido */
	FORMATING_NUMBER_EXCEEDED(152),
	/** Logs já foram formatador por formatação superior */
	REFORMATING_NOT_NECESSARY(153),
	/** Número da formatação anterior a última realizada */
	PREVIOUS_LAST_FORMATING(154),
	/** Formatação sem sincronismo com processador de logs */
	NOT_SYNC_FORMATING(155),
	/** Formatação inválida */
	INVALID_FORMATING(156),
	/** Não existe formatação para o número especificado */
	FORMANTING_NUMBER_NOT_EXIST(157),
	/** Classe de Log não encontrada. */
	LOG_CLS_NOT_FOUND(158),
	/** Log não encontrado */
	LOG_NOT_FOUND(159),
	/** Logs não ordenados */
	LOG_UNORDER(160),
	/** Sem logs para salvar */
	WITHOUT_LOGS_TO_SAVE(161),
	/** Tipo de carga inválido */
	INVALID_CHARGE_TYPE(162),
	/** Relacionamento entre TotalConta e TipoTransação não encontrado */
	TCT_TTR_RELATIONSHIP_NOT_FOUND(163),
	/** Perfil de canal de atendimento não encnontrado */
	ATENDIMENT_POINT_PROFILE_NOT_FOUND(164),
	/** Relacionamento entre Conta e cliente não encontrado */
	CTA_CLT_RELATIONSHIP_NOT_FOUND(165),
	/** Cotação não encontrado */
	QUOTE_NOT_FOUND(166),
	/** Benefício inativo */
	INACTIVE_BENEFIT(167),
	/** Benefício bloqueado */
	BLOCKED_BENEFIT(168),
	/* Autorização não encontrada */
	AUTHORIZATION_NOT_FOUND(169),
	/** Saldo bloqueado insuficiente para desbloqueio */
	NO_BLOCKED_BALANCE(170),
	/** Total por conta não encontrada */
	ACCOUNT_TOTALIZATION_NOT_FOUND(171),
	/** Limite não encontrado */
	LIMIT_NOT_FOUND(172),
	/** Tipo de empréstimo não encontrado */
	LOAN_TYPE_NOT_FOUND(173),
	/** Cliente já relacionado a conta. */
	CTA_CLT_RELATIONSHIP_ALREADY_EXISTS(174),
	/** Cartão já relacionado a conta x cliente. */
	CTA_CLT_CMG_RELATIONSHIP_ALREADY_EXISTS(175),
	/** Limite definido para o perfil da conta excedido. */
	PROFILE_LIMIT_EXCEEDED(178),
	/** Despachante não encontrado. */
	DESPATCHER_NOT_FOUND(179),
	/** Tipo de transação estornadora não encontrado. */
	REVERSAL_TRANSACTION_TYPE_NOT_FOUND(180),
	/** Localidade não encontrada. */
	LOCALITY_NOT_FOUND(181),
	/** Operador não encontrado. */
	OPERATOR_NOT_FOUND(182),
	/** Tipo de transação não encontrada. */
	TRANSACTION_TYPE_NOT_FOUND(183),
	/** Agendamento não encontrado. */
	SCHEDULE_NOT_FOUND(184),
	/** Agendamento já foi processado. */
	PROCESSED_SCHEDULE(185),
	/** Erro ao autenticar operador no login */
	LOGIN_ERROR(186),
	/** Relacionamento entre Operador e Role não encontrado */
	OPR_RLE_RELATIONSHIP_NOT_FOUND(187),
	/** Dado não encontrado */
	DATA_NOT_FOUND(188),
	/** Competência não encontrada */
	COMPETENCE_NOT_FOUND(190),
	/** Cliente não encontrado */
	CLIENT_NOT_FOUND(191),
	/** Ponto de corte já existe */
	SERVICE_CLOSURE_ALREADY_EXISTS(192),
	/** Cliente não recadastrado */
	CLIENT_NOT_UPDATE_REGISTER(193),
	/** Indicador Econômico não encontrado */
	ECONOMIC_POINTER_NOT_FOUND(200),
	/** Categoria não encontrada */
	CATEGORY_NOT_FOUND(210),
	/** Modalidade não encontrada */
	MODALITY_NOT_FOUND(220),
	/** Regra de tarifação não encontrada */
	TAX_RULE_NOT_FOUND(230),
	/** Tarifa não encontrada */
	TAX_NOT_FOUND(231),
	/** Limite de Quantidade de Saques Febraban excedido */
	FEBRABAN_AMOUNT_LIMIT_EXCEEDED(240),
	/** Limite de Valor de Saque Febraban excedido */
	FEBRABAN_VALUE_LIMIT_EXCEEDED(241),
	/** Limite máximo para DOC excedido */
	DOC_MAXIMUM_LIMIT_EXCEEDED(242),
	/** Limite máximo para TED excedido */
	TED_MAXIMUM_LIMIT_EXCEEDED(243),
	/** Limite mínimo para TED não alcançado */
	TED_MINIMUM_LIMIT_NOT_REACHED(244),
	/** Benefício não liberado */
	BENEFIT_NOT_RELEASED(245),
	/** CPF/CNPJ inválido */
	INVALID_CPF_CNPJ(246),
	/** Banco não operante */
	NOT_OPERATIVE_BANK(247),
	/** Câmara de Compensação fechada */
	CLOSED_CLEARING_HOUSE(248),
	/** Erro na inclusão do log */
	LOG_INSERT_ERROR(249),
	/** Sincronismo não encontrado. */
	SYNC_NOT_FOUND(250),
	/** Perfil da conta não encontrado */
	PROFILE_NOT_FOUND(251),
	/** Não há sincronismos pendentes */
	NOT_SYNC_PENDING(252),
	/** Código de barras inválido */
	INVALID_CODE_BAR(253),
	/** Documento vencido */
	EXPIRED_DOCUMENT(254),
	/** Valor inválido */
	INVALID_VALUE(255),
	/** Valor inválido */
	INVALID_TRANSFER_TYPE(256),
	/** Estrutura incorreta da mensagem, */
	INCORRECT_MESSAGE_STRUCTURE(257),
	/** Agendamento inválido */
	INVALID_DATA_SCHEDULE(258),
	/** Convênio não encontrado */
	AGREEMENT_NOT_FOUND(259),
	/** Número de protocolo DI Siscomex não encontrado */
	PROTOCOL_NUMBER_SISCOMEX_NOT_FOUND(260),
	/** Número de protocolo DI Siscomex já autorizado */
	PROTOCOL_NUMBER_SISCOMEX_AUTHORIZED(261),
	/** Despachante não habilitado para a conta */
	DESPATCHER_NOT_ENABLE_ACCOUNT(262),
	/** Código da receita inválido */
	INVALID_TAX_CODE(263),
	/** Câmara de Compensação não encontrada */
	CLEARING_HOUSE_NOT_FOUND(264),
	/** Participante da câmara de compensação não encontrado. */
	CLEARING_HOUSE_MEMBER_NOT_FOUND(265),
	/** Grade horária SPB não encontrada. */
	WORKING_HOURS_SPB_NOT_FOUND(266),
	/** Transação SPB não encontrada. */
	SPB_TRANSACTION_NOT_FOUND(267),
	/** Trilha 2 do cartão inválida. */
	INVALID_TRACK_2(268),
	/** Título SPB não encontrado */
	SPB_AGREEMENT_NOT_FOUND(269),
	/** Formato de data inválido */
	INVALID_DATE_FORMAT(270),
	/** Fundo não encontrado */
	FUND_NOT_FOUND(271),
	/** Arquivo de conciliação TecBan inválido. */
	ARQUIVO_CONCILIACAO_TECBAN_INVALIDO(272),
	/** Conciliação TecBan não encontrada. */
	CONCILIACAO_TECBAN_NAO_ENCONTRADA(273),
	/** Sequência de arquivo inválida. */
	INVALID_SEQUENCE_FILE(274),
	/** Ordem judicial não encontrada. */
	ORDEM_JUDICIAL_NAO_ENCONTRADA(275),
	/** Mensagem de conta não encontrada. */
	ACCOUNT_MESSAGE_NOT_FOUND(276),
	/** Mensagem de benefício não encontrada. */
	BENEFIT_MESSAGE_NOT_FOUND(277),
	/** Ordem Judicial deve esperar processamento do PDCCI. */
	PROCESS_PDCCI(278),
	/** Cliente não é titular da conta. */
	CLIENT_NOT_TITULAR(279),
	/** Mensagem não encontrada. */
	MESSAGE_NOT_FOUND(280),
	/** não encontrou contas passiveis de bloqueio/desbloqueio */
	CBD_NOT_FOUND(281),
	/** Cheque não encontrado */
	CHECK_NOT_FOUND(282),
	/** Numeração de cheques não encontrado */
	CHECK_NUMERATION_NOT_FOUND(283),
	/** não encontrou transação de conciliação tecban */
	TRANSACAO_CONCILIACAO_NOT_FOUND(284),
	/** Relacionamento ContaAmiga já relacionado a conta. */
	CTA_CAM_RELATIONSHIP_ALREADY_EXISTS(285),
	/** Cadastro de Débito Automático  não encontrado */
	DEBITO_AUTOMATICO_NAO_ENCONTRADO(286),
	/** Lançamento de Débito Automático  não encontrado */
	LANCAMENTO_DEBITO_AUTOMATICO_NAO_ENCONTRADO(287),
	/** Convênio de Débito Automático  não encontrado */
	CONVENIO_DEBITO_AUTOMATICO_NAO_ENCONTRADO(288),
	/** Débito Automático  já encontrado */
	DEBITO_AUTOMATICO_JA_CADASTRADO(289),
	/** Linha de Crédito não Disponível */
	CREDIT_FACILITY_NOT_FOUND(300),
	/** Linha de Crédito Bloqueada */
	CREDIT_FACILITY_BLOCKED(301),
	/** Valor da requisição de linha de crédito inferior ao valor mínimo */
	CREDIT_FACILITY_MINIMUM_LIMIT_NOT_REACHED(302),
	/** Data Base de pagamento da primeira parcela inválida */
	CREDIT_FACILITY_INVALID_DATE_BASE_PAYMENT(303),
	/** Número de Parcelas invalido */
	CREDIT_FACILITY_INVALID_NUMBER_OF_PARCELS(304),
	/** Limite de Crédito insuficiente */
	CREDIT_FACILITY_INSUFFICIENT_LIMIT(305),
	/** Excede o valor da parcela para a linha de crédito */
	CREDIT_FACILITY_PARCEL_VALUE_EXCEED(306),
	/** Dados inválidos para linha de crédito */
	CREDIT_FACILITY_INVALID_DATA(307),
	/** Refaça a transação */
	TRY_AGAIN_LATER(308),
	/** Intituição não pertence a rede */
	BANK_NOT_REGISTERED(309),
	/** Entre em contato com a intituição */
	CONTACT_BANK(310),
	/** Excedeu a frequencia de saque */
	FREQUENCY_OF_CHECKING_EXEEDED(311),
	/** Sem comunicação com sua intituição */
	BANK_COMUNICATION_UNAVAIABLE(312),
	/** Arquivo de retorno Rede Compartilhada inválido. */
	ARQUIVO_RETORNO_REDECOMP_INVALIDO(313),
	/** Contrato de Crédito não encontrado */
	CREDIT_CONTRACT_NOT_FOUND(314),
	/** Excedeu limite de senha inválida */
	INVALID_PASSWORD_LIMIT_EXEEDED(315),
	/** Cartão Suspenso */
	SUSPENDED_CARD(316),
	/** Quantidade de cheques excedida */
	CHECK_AMOUNT_EXCEEDED(317),
	/** Cheque já Sustado **/
	CHECK_SUSPENDED(319),
	/** Conta com restrição **/
	RESTRICTED_ACCOUNT(320),
	/** Quantidade de cheques será excedida **/
	CHECK_AMOUNT_WILL_EXCEED(321),
	/** Natureza da conta não permite transação **/
	INVALID_NATURE_ACCOUNT(322),
	/** Valor de receita bruta de DARF inválido */
	RECEITA_BRUTA_INVALIDA(323),
	/** Valor percentual inválido */
	VALOR_PERCENTUAL_INVALIDO(324),
	/** Valor minimo de DARF inválido */
	INVALID_MINIMUM_VALUE(325),
	/** Identificador de GPS inválido */
	INVALID_GPS_ID(326),
	/** Competência de GPS ou FGTS inválida */
	INVALID_COMPETENCE(327),
	/** Contrato inválido para recebimento desse tipo de DARE */
	INVALID_CONTRACT_DARE(328),
	/** tipo de DARE inválido para recebimento */
	INVALID_DARE_TYPE(329),
	/** Identificador de empresa inválido para DARF */
	INVALID_COMPANY_ID_DARF(330),
	/** não Aceita CPF/CNPJ Normalizado */
	NOT_ACCEPT_CPFCNPJ_NORMAL(331),
	/** Aceita apenas CNPJ */
	ONLY_CNPJ_ACCEPT(332),
	/** Aceita apenas CPF */
	ONLY_CPF_ACCEPT(333),
	/** Número de referencia inválido */
	INVALID_REFERENCE_NUMBER(334),
	/** Período de apuração inválido */
	INVALID_VERIFICATION_PERIOD(335),
	/** Nao pode antecipar o pagamento deste FGTS em mais de 30 dias */
	FGTS_NAO_ANTECIPA_30DIAS(336),
	/** Código de recolhimento inválido */
	INVALID_RECOLHIMENTO_COD(337),
	/** Taxa de remuneração inválido */
	INVALID_TAX_REM(338),
	/** Identificador de FGTS inválido */
	INVALID_FGTS_ID(339),
	/** Tipo de identificação inválido para Caixa - Arrecadação - GRDE */
	INVALID_GRDE_ID(340),
	/** Tipo de identificação de pessoa inválido */
	INVALID_IDE_TYPE(341),
	/** Valor do INSS obrigatório */
	VALUE_INSS_OBRIGATORIO(342),
	/** Valor de outras entidades obrigatório */
	VALUE_OUT_ENT_OBRIGATORIO(343),
	/** Valor de multas e juros inválido */
	INVALID_VALUE_MULTAS_JUROS(344),
	/** Aceito apenas para filiais menores que 300 */
	ONLY_FILIAIS_MENOR_300_ACCEPT(345),
	/** Aceito Somente para Pagamento de Matriz */
	ONLY_MATRIZ_ACCEPT(346),
	/** Saldo insuficiente para tarifa */
	NO_BALANCE_TAX(347),
	/** Quantidade limite de transações excedido. */
	TRANSACTION_AMOUNT_LIMIT_EXCEEDED(348),
	/** Transação não autorizada para conta conjunta */
	NOT_AUTHORIZED_TO_JOINT_ACCOUNT(349),
	/** Transação não autorizada para conta salário */
	NOT_AUTHORIZED_TO_WAGE_ACCOUNT(350),
	/** Não há cédulas disponíveis para este saque */
	BILLS_NOT_ENOUGH_TO_CHECKING(351),
	/** Agência de outro banco não encontrada */
	AGE_OUT_BCO_NOT_FOUND(352),
	/** Limite máximo de notas excedido. */
	NOTES_LIMIT_EXCEEDED(353),
	/** Código de pagamento de de GPS não encontrado */
	CODIGO_PAGAMENTO_GPS_NAO_ENCONTRADO(354),
	/** Não preencher o valor do INSS */
	VALUE_INSS_NAO_PREENCHER(355),
	/** Não preencher o valor de outras entidades */
	VALUE_OUT_ENT_NAO_PREENCHER(356),
	/** Não preencher o valor de multas */
	VALUE_MULTAS_JUROS_NAO_PREENCHER(357),
	/** Competencia não pode ser antecipada */
	COMPETENCIA_NAO_ANTECIPA(358),
	/** Valor minimo pagamento de GPS inválido */
	INVALID_VALUE_MINIMO_PAG_GPS(359),
	/** Numero de referencia do DRAF nao informado */
	NUMERO_REFERENCIA_NAO_INFORMADO(360),
	/** Terminal Bloqueado ou Inativo */
	TERMINAL_BLOQUEADO_INATIVO(361),
	/** IP inválido para o terminal */
	TERMINAL_IP_INVALIDO(362),
	/** Erro na geração da WorkingKey */
	TERMINAL_FALHA_COMUNICACAO_HSM(363),
	/** Intervalo com Cheque já Sustado **/
	INTERVALO_CHECK_SUSPENDED(364),
	/** Cheque Pago **/
	CHECK_PAGO(365),
	/** Intervalo com Cheque Pago **/
	INTERVALO_CHECK_PAGO(366),
	/** Cheque Cancelado **/
	CHECK_CANCELADO(367),
	/** Intervalo com Cheque Cancelado **/
	INTERVALO_CHECK_CANCELADO(368),
	/** CrÃ©dito pago */
	CREDIT_PAID(369),
	/** CrÃ©dito já recebido */
	CREDIT_ALREADY_RECEIVED(370),
	/** Cheque Inutilizado */
	CHECK_UNAVAILABLE(371),
	/** Intervalo com cheque inutilizado */
	INTERVALO_CHECK_UNAVAILABLE(372),
	/** Quantidade de cheques excedida no perÃ­odo */
	CHECK_AMOUNT_EXCEEDED_PERIOD(373),
	/** Conta não habilidada para emissão de cheque */
	ACCOUNT_ISSUE_CHECK_DISABLE(374),
	/** Quantidade de cheques emitida excedera o total permitido */
	CHECK_AMOUNT_ISSUED_WILL_EXCEEDED(375),
	/** Excedido número máximo de transações com a mesma working key */
	CHANGE_WORKINGKEY_IS_MANDATORY(376),
	/** Dados duplicados */
	DUPLICATE_DATA(377),
	/** Número de sÃ©rie inválido para o terminal */
	INVALID_SERIAL_NUMBER_TERMINAL(378),
	/** Pagamento de duas competências inválido para o código de pagamento */
	PAY_TWO_COMPETENCE_INVALID(379),
	/** ContaAmiga não relacionada a conta. */
	CTA_CAM_RELATIONSHIP_NOT_EXISTS(380),
	/** Não foi possÃ­vel conectar-se ao HSM */
	HSM_CONNECTION_UNAVAILABLE(381),
	/** Não foi possÃ­vel decriptar o PIN informado */
	UNABLE_TO_DECRIPT_PIN(382),
	/** Não foi possÃ­vel identificar mensagem de retorno do corporativo */
	UNIDENTIFIED_RESPONSE_HOST(383),
	/** Tempo de resposta do corporativo expirou */
	TIME_OUT_HOST(384),
	/** Transação temporariamente indisponÃ­vel */
	TRANSACTION_TEMPORARILY_UNAVAILABLE(385),
	/** Documento já Agendado */
	DOCUMENT_SCHEDULED(386),
	/** Limite Inválido */
	INVALID_LIMIT(387),
	/** NSU inválido */
	INVALID_NSU(388),
	/** Documento Inválido */
	INVALID_DOCUMENT(389),
	/** Ponto de Atendimento Inválido */
	INVALID_ATENDIMENT_POINT(390),
	/** Terminal Inválido */
	INVALID_TERMINAL(391),
	/** Tipo de Captura Inválido */
	INVALID_TYPE_CAPTURE(392),
	/** Status Inválido */
	INVALID_STATUS(393),
	/** Banco Inválido */
	INVALID_BANK(394),
	/** Praça de Compensação inválida */
	INVALID_SQUARE_COMPENSATION(395),
	/** Nome Inválido */
	INVALID_NAME(396),
	/** Finalidade inválida */
	INVALID_PURPOSE(397),
	/** Sistema Inválido */
	INVALID_SYSTEM(398),
	/** Agendamento Recusado */
	SCHEDULE_REFUSED(399),
	/** Canal Inválido */
	INVALID_CHANNEL(400),
	/** Partição inválida */
	INVALID_PARTITION(401),
	/** Transação inválida */
	INVALID_TRANSACTION(402),
	/** Data inválida */
	INVALID_DATE(403),
	/** Tipo de Documento Inválido */
	INVALID_DOCUMENT_TYPE(404),
	/** Valor de desconto e/ou deduções inválido */
	INVALID_VALUE_DISCOUNT_DEDUCTIONS(405),
	/** Indicador de CPMF inválido */
	INVALID_INDICATOR_CPMF(406),
	/** Grupo já existe */
	GROUP_ALREADY_EXISTS(407),
	/** Grupo com elementos */
	GROUP_CONTAINS_ELEMENTS(408),
	/** Código de produto inválido */
	INVALID_PRODUCT_CODE(409),
	/** Sequencial inválido */
	INVALID_SEQUENTIAL(410),
	/** Cartão não pertence Ã  conta */
	CARD_NOT_ASSOCIATED_ACCOUNT(411),
	/** Ordem do cliente inválida */
	INVALID_CLIENT_ORDER(412),
	/** Grupo inválido */
	INVALID_GROUP(413),
	/** Cliente não possui conta */
	CLIENT_WITHOUT_ACCOUNT(414),
	/** Tipo de extrato inválido */
	INVALID_BANK_STATEMENT_TYPE(415),
	/** Conta sem conta amiga */
	ACCOUNT_WITHOUT_FRIEND_ACCOUNT(416),
	/** não existe conta amiga sem grupo */
	FRIEND_ACCOUNT_WITHOUT_GROUP_NOT_FOUND(417),
	/** Modalidade inválida */
	INVALID_MODALITY(418),
	/** Conta sem aplicação */
	ACCOUNT_WITHOUT_INVESTMENT(419),
	/** Convênio inválido */
	INVALID_AGREEMENT(420),
	/** Transação não permitida para o canal */
	NOT_AUTHORIZED_TRANSACTION_TO_CHANNEL(421),
	/** Extrato sem lançamento */
	BANK_STATEMENT_WITHOUT_RECORD(422),
	/** Código de resposta inválido */
	INVALID_RESPONSE_CODE(423),
	/** Conta amiga sem grupo */
	FRIEND_ACCOUNT_WITHOUT_GROUP(424),
	/** Grupo não encontrado */
	GROUP_NOT_FOUND(425),
	/** Indicador de mesma titularidade inválido */
	INVALID_INDICATOR_SAME_HOLDER(426),
	/** Matrícula operador inválida */
	INVALID_REGISTRATION_OPERATOR(427),
	/** Matrícula supervisor inválida */
	INVALID_REGISTRATION_SUPERVISOR(428),
	/** Situação inválida */
	INVALID_SITUATION(429),
	/** Tipo de grupo inválido */
	INVALID_GROUP_TYPE(430),
	/** Tipo de liberação inválida */
	INVALID_TYPE_RELEASE(431),
	/** DÃ­gito verificador inválido */
	INVALID_DIGIT_VERIFIER(432),
	/** Identificador contribuinte inválido */
	INVALID_HANDLE_CONTRIBUTOR(433),
	/** Tipo de pessoa inválido */
	INVALID_TYPE_PERSON(434),
	/** Código de pagamento de GPS inválido */
	INVALID_PAYMENT_CODE(435),
	/** Câmara inválida */
	INVALID_CLEARING(436),
	/** Tipo de tÃ­tulo inválido */
	INVALID_PAYMENT_SLIP_TYPE(437),
	/** Tipo de Identificacao Positiva inválido */
	INVALID_TYPE_POSITIVE_IDENTIFICATION(438),
	/** Tipo de validação inválido */
	INVALID_TYPE_VALIDATION(439),
	/** Indicador de Transação com Cartão inválido */
	INVALID_TRANSACTION_INDICATOR_WITH_CARD(440), 
	/** Valor do Documento Inválido	 */
	INVALID_DOCUMENT_VALUE(441),
	/** Tipo de Tributo ou Imposto Inválido */
	INVALID_TYPE_TAX(442),
	/** Dados de tributo ou imposto inválidos */
	INVALID_DATA_TAX(443),
	/** Número da Parcela Inválido */
	INVALID_PARCEL_NUMBER(444),
	/** Aceite do Termo de Adesão Inválido */
	INVALID_ACCEPT_TERMS_ACCESSION(445),
	/** Tipo de Cartão Inválido */
	INVALID_CARD_TYPE(446),
	/** Dados de cartão Inválido */
	INVALID_CARD_DATA(447),
	/** CEP Inválido */
	INVALID_ZIP_CODE(448),
	/** Identificação do Convênio inválida */
	INVALID_AGREEMENT_IDENTIFICATION(449),
	/** Ano de ExercÃ­cio Inválido */
	INVALID_EXERCISE_YEAR(450),
	/** Código de Fundo Inválido */
	INVALID_FUND_CODE(451),
	/** Código de Contrato Inválido */
	INVALID_CREDIT_CONTRACT(452),
	/** Situação de Averbação inválida */
	INVALID_REGISTRATION_SITUATION(453), 
	/** Tipo de Operação inválida */
	INVALID_TYPE_OPERATION(454),
	/** Recibo já é Definitivo */
	RECEIPT_IS_FINAL(455),
	/** Recibo não encontrado */
	RECEIPT_NOT_FOUND(456),
	/** Indicador de Resgate Total Inválido */
	INVALID_INDICATOR_TOTAL_REDEMPTION(457),
	/** Identificador do tÃ­tulo inválido */
	INVALID_PAYMENT_SLIP_ID(458),
	/** Tipo de Favorecido Inválido */
	INVALID_TYPE_FAVORED(459),
	/** DDD Telefone Inválido */
	INVALID_DDD(460),
	/** Número Telefone Inválido */
	INVALID_PHONE_NUMBER(461),
	/** Ramal Telefone Inválido */
	INVALID_EXTENSION(462),
	/** Tipo de Lista Inválido */
	INVALID_LIST_TYPE(463),
	/** Motivo Inválido */
	INVALID_REASON(464),
	/** Conta já cadastrada */
	ACCOUNT_ALREADY_REGISTERED(465),
	/** Complemento Inválido */
	INVALID_COMPLEMENT(466),
	/** Indicador de Cadastro Definitivo Inválido */
	INVALID_INDICATOR_FINAL_REGISTRATION(467),
	/** Matrícula do Beneficiario inválida */
	INVALID_BENEFICIARY_REGISTRATION(468),
	/** Hora Limite inválida */
	INVALID_TIME_LIMIT(469),
	/** Valor mínimo Inválido */
	INVALID_VALUE_MINIMUM(470),
	/** Data de Vencimento inválida */
	INVALID_EXPIRATION_DATE(471),
	/** Existe prestação(parcela) em atraso */
	PRESTACAO_EM_ATRASO(472),
	/** Cliente impedido para linha de crédito */
	CLIENTE_IMPEDIDO_LINHA_CREDITO(473),
	/** Cliente não apto para linha de crédito */
	CLIENTE_NAO_APTO_LINHA_CREDITO(474),
	/** Telefone já Cadastrado */
	TELEFONE_JA_CADASTRADO(475),
	/** Telefone não encontrado */
	TELEFONE_NAO_ENCONTRADO(476),
	/** Texto do Termo de Adesão não Encontrado */
	TEXTO_TERMO_ADESAO_NAO_ENCONTRADO(477),
	/** Matrícula inválida */
	MATRICULA_INVALIDA(478),
	/** Conta sem orgão pagador */
	CONTA_SEM_ORGAO_PAGADOR(479),
	/** Cliente já possui conta salário para este orgão pagador */
	CLIENTE_JA_POSSUI_CONTA_SALARIO_PARA_ESTE_ORGAO_PAGADOR(480),
	/** Solicitação de Abertura de Conta Salario já realizada */
	SOLICITACAO_ABERTURA_CONTA_SALARIO_JA_REALIZADA(481),
	/** Solicitação de Abertura de Conta Salario não encontrada */
	SOLICITACAO_ABERTURA_CONTA_SALARIO_NAO_ENCONTRADA(482),
	/** Dados não conferem */
	DADOS_NAO_CONFEREM(483),
	/** Tipo de solicitação inválido */
	TIPO_SOLICITACAO_INVALIDO(484),
	/** Dados sobrepostos */
	DADOS_SOBREPOSTOS(485),
	/** Dados da empresa inválidos */
	DADOS_EMPRESA_INVALIDOS(486),
	/** Dados do empregado inválidos */
	DADOS_EMPREGADO_INVALIDOS(487),
	/** PerÃ­odo inválido */
	PERIODO_INVALIDO(488),
	/** Empresa não encontrada */
	EMPRESA_NAO_ENCONTRADA(489),
	/** Cliente com pendência */
	CLIENTE_COM_PENDENCIA(490),
	/** Valor maior ou igual ao valor do Limite Geral*/
	VALOR_MAIOR_IGUAL_LIM_GERAL(491),
	/** RENAVAM inválido */
	RENAVAM_INVALIDO(492),
	/** Orgão pagador inválido */
	ORGAO_PAGADOR_INVALIDO(493),
	/** Ordem ou CPF do Titular inválido */
	ORDEM_CPF_TITULAR_INVALIDO(494),
	/** Numero Identificacao DDA Invalido */
	IDENTIFICACAO_DDA_INVALIDA(495),
	/** Data Limite Pagamento Invalido */
	DATA_LIMITE_PAGAMENTO_INVALIDA(496),
	/** Tipo Lote Inválido */
	TIPO_LOTE_INVALIDO(497),
	/** Tipo Serviço Inválido */
	TIPO_SERVICO_INVALIDO(498),
	/** Identificador Inválido */
	IDENTIFICADOR_INVALIDO(499),
	/** Indicador Inválido */
	INDICADOR_INVALIDO(500),
	/** Titular da conta associado a outro órgão pagador */
	TITULAR_ASSOCIADO_OUTRO_ORGAO_PAGADOR(501),
	/** Código de Barras com suspeita de fraude */
	CODIGO_BARRAS_SUSPEITO_FRAUDE(502),
	/** Dados para notificação não encontrado */
	DADOS_NOTIFICACAO_NAO_ENCONTRADA(503),
	/** CPF/CNPJ não é 1o titular de uma conta */
	CPF_CNPJ_NAO_E_PRIMEIRO_TITULAR_CONTA(504),
	/** Transação estornavel não encontrada */
	TRANSACAO_ESTORNAVEL_NAO_ENCONTRADA(505),
	/** CPF/CNPJ sem orgão pagador */
	CPF_CNPJ_SEM_ORGAO_PAGADOR(506),
	/** Dados da Conta ou Cartão Inválidos */
	DADOS_CONTA_CARTAO_INVALIDOS(507),
	/** Conta ou CPF/CNPJ inválidos */
	CONTA_CPF_CNPJ_INVALIDOS(508),
	/** Tipo de Documento não permitido para transação */
	TIPO_DOCUMENTO_NAO_PERMITIDO_TRANSACAO(509),
	/** Autorização não pertence a conta */
	AUTORIZACAO_NAO_PERTENCE_CONTA(510),
	/** Cartão não pertence ao titular */
	CARTAO_NAO_PERTENCE_TITULAR(511),
	/** Norma não cadastrada para o tipo de restrição impeditiva */
	NORMA_NAO_CADASTRADA_PARA_TIPO_RESTRICAO_IMPEDITIVA(512),
	/** Código do terminal já cadastrado para o ponto de atendimento*/
	CODIGO_TERMINAL_JA_CADASTRADO_PARA_PONTO_ATENDIMENTO(513),
	/** Nome do terminal já cadastrado para o ponto de atendimento*/
	NOME_TERMINAL_JA_CADASTRADO_PARA_PONTO_ATENDIMENTO(514),
	/** Identificador do terminal já cadastrado para o ponto de atendimento*/
	IDENTIFICADOR_NAO_CADASTRADA_PARA_TIPO_RESTRICAO_IMPEDITIVA(515),
	/** O terminal esta aberto e não pode ser removido */
	TERMINAL_ABERTO_NAO_PODE_SER_REMOVIDO(516),
	/** Lote já agendado */
	LOTE_JA_AGENDADO(517),
	/** Valor excede o limite diário  */
	VALOR_EXCEDE_LIMITE_DIARIO(518),
	/** Tipo de Serviço não esta habilitado para esta transação  */
	TIPO_SERVICO_NAO_HABILITADO_PARA_TRANSACAO(519),
	/** Lote não encontrado  */
	LOTE_NAO_ENCONTRADO(520),
	/** ParÃ¢metro não encontrado  */
	PARAMETRO_NAO_ENCONTRADO(521),
	/** Situação do Lote inválida  */
	SITUACAO_LOTE_INVALIDA(522),
	/** Arquivo de lote inválido  */
	ARQUIVO_LOTE_INVALIDO(523),
	/** Dados do arquivo de lote estão inconsistentes  */
	DADOS_ARQUIVO_LOTE_INCONSISTENTES(524),
	/** Data do Lote é inferior a Data de Referência  */
	DATA_LOTE_INFERIOR_DATA_REFERENCIA(525),
	/** Horáio limite de processamento do Lote foi atingido  */
	HORARIO_LIMITE_PROCESSAMENTO_LOTE_ATINGIDO(526),
	/** Transação de crédito não autorizada */
	TRANSACAO_CREDITO_NAO_AUTORIZADA(527),
	/** Transação de débito não autorizada */
	TRANSACAO_DEBITO_NAO_AUTORIZADA(528),
	/** Valor a ser debitado é igual a zero */
	VALOR_DEBITADO_IGUAL_ZERO(529),
	/** Indicador de crédito PJ inválido */
	INDICADOR_CREDITO_PJ_INVALIDO(530),
	/** Descrição do tipo de serviço inválida */
	DESCRICAO_TIPO_SERVICO_INVALIDA(531),
	/** Código de transação de crédito inválido */
	CODIGO_TRANSACAO_CREDITO_INVALIDO(532),
	/** Código de transação de crédito poupança inválido */
	CODIGO_TRANSACAO_CREDITO_POUPANCA_INVALIDO(533),
	/** Código de transação de débito inválido */
	CODIGO_TRANSACAO_DEBITO_INVALIDO(534),
	/** Código de transação de devolução de TED inválido */
	CODIGO_TRANSACAO_DEVOLUCAO_TED_INVALIDO(535),
	/** Código de transação de estorno de crédito inválido */
	CODIGO_TRANSACAO_ESTORNO_CREDITO_INVALIDO(536),
	/** Código de transação de estorno de crédito poupança inválido */
	CODIGO_TRANSACAO_ESTORNO_CREDITO_POUPANCA_INVALIDO(537),
	/** Código de transação de estorno de débito inválido */
	CODIGO_TRANSACAO_ESTORNO_DEBITO_INVALIDO(538),
	/** Código de transação de estorno de devolução de TED inválido */
	CODIGO_TRANSACAO_ESTORNO_DEVOLUCAO_TED_INVALIDO(539),
	/** Código de transação de estorno de tarifa inválido */
	CODIGO_TRANSACAO_ESTORNO_TARIFA_INVALIDO(540),
	/** Código de transação de tarifa inválido */
	CODIGO_TRANSACAO_TARIFA_INVALIDO(541), 
	/** Tipo de serviço sem permissão para contas de debito  */
	TIPO_SERVICO_NAO_PERMITE_CONTA_DEBITO(542),
	/** Transação não autorizada pelo corporativo  */
	TRANSACAO_NAO_AUTORIZADA_HOST(543),
	/** Documento já pago  */
	DOCUMENTO_JA_PAGO(544),
	/** já existe uma movimentação neste fundo para a data atual  */
	JA_EXISTE_MOVIMENTACAO_NESTE_FUNDO(545),
	/** Tipo de Limite Inválido */
	TIPO_LIMITE_INVALIDO(546),
	/** Descrição inválida */
	DESCRICAO_INVALIDA(547),
	/** Quantidade de parcelas excedida */
	QUANTIDADE_PARCELAS_EXCEDIDA(548),
	/** Parcela Ãºnica não permitida com outras parcelas */
	PARCELA_UNICA_NAO_PERMITIDA_COM_OUTRAS(549),
	/** Transação já cancelada */
	TRANSACAO_JA_CANCELADA(550),
	/** Tipo de agendamento inválido */
	TIPO_AGENDAMENTO_INVALIDO(551),
	/** Documento com pagamento pendente  */
	DOCUMENTO_PAGAMENTO_PENDENTE(552),
	/** Conta bloqueada totalmente */
	CONTA_BLOQUEADA_TOTALMENTE(553),
	/** Conta bloqueada para crédito */
	CONTA_BLOQUEADA_CREDITO(554),
	/** Conta bloqueada para débito */
	CONTA_BLOQUEADA_DEBITO(555),
	/** Data de pagamento inválida */
	DATA_PAGAMENTO_INVALIDA(556),
	/** Conta de crédito igual Ã  conta de débito. */
	CONTA_CREDITO_IGUAL_CONTA_DEBITO(557),
	/** Limite cheque especial inferior ao valor mínimo */
	LIMITE_CHEQUE_ESPECIAL_MENOR_MINIMO(558),
	/** Limite cheque especial não é mÃºltiplo de valor parametrizado */
	LIMITE_CHEQUE_ESPECIAL_NAO_MULTIPLO_VALOR_PARAMETRO(559),
	/** Aplicação não permitida em dia não Ãºtil */
	APLICACAO_NAO_PERMITIDA_DIA_NAO_UTIL(560),
	/** Resgate não permitido em dia não Ãºtil */
	RESGATE_NAO_PERMITIDO_DIA_NAO_UTIL(561),
	/** Tipo de serviço já cadastrado */
	TIPO_SERVICO_JA_CADASTRADO(562),
	/** Conta amiga não encontrada */
	CONTA_AMIGA_NAO_ENCONTRADA(563),
	/** Indicador de liberação de Tipo de Serviço inválido  */
	INDICADOR_LIBERACAO_TIPO_SERVICO_INVALIDO(564),
	/** Tipo de pessoa do sacado inválido */
	TIPO_PESSOA_SACADO_INVALIDO(565),
	/** Tipo de pessoa do agregado inválido */
	TIPO_PESSOA_AGREGADO_INVALIDO(566),
	/** Tipo de serviço possui relacionamentos */
	TIPO_SERVICO_POSSUI_RELACIONAMENTOS(567),
	/** Classe de Log inválida */
	CLASSE_LOG_INVALIDA(568),
	/** Classe de conversão de Log inválida */
	CLASSE_CONVERSAO_LOG_INVALIDA(569),
	/** CPF/CNPJ do Titular da Conta CrÃ©dito Inválido */
	CPF_CNPJ_TITULAR_CONTA_CREDITO_INVALIDO(570),
	/** Nome do Titular da Conta CrÃ©dito Inválido */
	NOME_TITULAR_CONTA_CREDITO_INVALIDO(571),
	/** Titularidade inválida */
	TITULARIDADE_INVALIDA(572),  
	/** Horáio limite para a transação excedido */
	HORARIO_LIMITE_TRANSACAO_EXCEDIDO(573),
	/** Conta de destino não pertence ao titular */
	CONTA_DESTINO_NAO_PERTENCE_TITULAR(574),
	/** Horáio limite de aplicação para o fundo excedido */
	HORARIO_LIMITE_APLICACAO_FUNDO_EXCEDIDO(575),
	/** Fundo sem saldo */
	FUNDO_SEM_SALDO(576),
	/** Próprio banco não permitido */
	PROPRIO_BANCO_NAO_PERMITIDO(577),
	/** Conta de crédito inválida */
	CONTA_CREDITO_INVALIDA(578),
	/** Data de agendamento posterior ao vencimento */
	DATA_AGENDAMENTO_POSTERIOR_VENCIMENTO(579),   
	/** CPF/CNPJ não pertence ao titular da conta */
	CPF_CNPJ_NAO_PERTENCE_TITULAR_CONTA(580),
	/** Transação em Pçãoutorização */
	TRANSACAO_EM_PRE_AUTORIZACAO(581),
	/** Conta Salario não permitida nesta funcionalidade */
	CONTA_SALARIO_NAO_PERMITIDA_NESTA_FUNCIONALIDADE(582),
	/** Perfil esta vinculado Ã  norma de restrição de alçadas */
	PERFIL_VINCULADO_NORMA_RESTRICAO_ALCADA(583),
	/** Nome de Perfil já utilizado */
	NOME_PERFIL_JA_UTILIZADO(584),
	/** Senha não possui quantidade mÃ­nima de caracteres */
	SENHA_NAO_POSSUI_QTD_MIN_CARACTERES(585),
	/** Senha é fraca de acordo com os critÃ©rios de segurança */
	SENHA_FRACA(586),
	/** Senha igual Ã  senha atual ou senhas anteriores */
	SENHA_IGUAL_ATUAL_ANTERIORES(587),
	/** Senha igual Ã  senha do Cartão */
	SENHA_IGUAL_SENHA_CARTAO(588),
	/** Senha EletrÃ´nica igual Ã  Senha de Internet */
	SENHA_ELETRONICA_IGUAL_SENHA_INTERNET(589),
	/** Transação já autorizada por este usuario */
	TRANSACAO_JA_AUTORIZADA_USUARIO(590),   
	/** Usuario não é autorizador da transação */
	USUARIO_NAO_E_AUTORIZADOR_TRANSACAO(591),
	/** Código da receita não encontrado */
	CODIGO_RECEITA_NAO_ENCONTRADO(592),
	/** Data do lote inválida */
	DATA_LOTE_INVALIDA(593),
	/** Logradouro inválido */
	LOGRADOURO_INVALIDO(594),
	/** Bairro inválido */
	BAIRRO_INVALIDO(595),
	/** Cidade inválida */
	CIDADE_INVALIDA(596),
	/** UF inválida */
	UF_INVALIDA(597),
	/** Canal inexistente */
	CANAL_INEXISTENTE(598),
	/** Tipo de conta inexistente */
	TIPO_CONTA_INEXISTENTE(599),
	/** Agendamento não pertence Ã  conta */
	AGENDAMENTO_NAO_PERTENCE_CONTA(600),
	/** Solicitação de Fechamento de Conta Salario já realizada */
	SOLICITACAO_FECHAMENTO_CONTA_SALARIO_JA_REALIZADA(601),
	/** Pagamento só no SIAF" */
	PAGAMENTO_PERMITIDO_SOMENTE_SIAF(602),
	/** Problema de comunicação com o corporativo */
	PROBLEMA_COMUNICACAO_HOST(603),
	/** Horáio de inÃ­cio para a transação não alcançado */
	HORARIO_INICIO_TRANSACAO_NAO_ALCANCADO(604),
	/** não existe tipo de senha definido para o canal */
	NAO_EXISTE_TIPO_SENHA_CANAL(605),
	/** Senha já cadastrada */
	SENHA_JA_CADASTRADA(606),
	/** Senha não informada */
	SENHA_NAO_INFORMADA(607),
	/** Senha atual não confere */
	SENHA_ATUAL_NAO_CONFERE(608),
	/** Identificador do Usuario não informado */
	IDENTIFICADOR_USUARIO_NAO_INFORMADO(609),
	/** Código de segurança não confere */
	CODIGO_SEGURANCA_NAO_CONFERE(610),
	/** Tipo de código de segurança incompatÃ­vel com canal */
	TIPO_CODIGO_SEGURANCA_INCOMPATIVEL_CANAL(611),
	/** Tipo de Código de Segurança não informado */
	TIPO_CODIGO_SEGURANCA_NAO_INFORMADO(612),
	/** Tipo de Código de Segurança Inválido */
	TIPO_CODIGO_SEGURANCA_INVALIDO(613),
	/** Identificador da sessão do usuario não informado */
	IDENTIFICADOR_SESSAO_USUARIO_NAO_INFORMADO(614),
	/** Proprietario da senha não informado */
	PROPRIETARIO_SENHA_NAO_INFORMADO(615),
	/** Dados da senha não informados */
	DADOS_SENHA_NAO_INFORMADOS(616),
	/** Tipo de senha não informado */
	TIPO_SENHA_NAO_INFORMADO(617),
	/** Situação da senha não informada */
	SITUACAO_SENHA_NAO_INFORMADA(618),
	/** Dados da transação não informados */
	DADOS_TRANSACAO_NAO_INFORMADOS(619),
	/** Nome da funcionalidade não informado */
	NOME_FUNCIONALIDADE_NAO_INFORMADO(620),
	/** Indicador de Token Ãºnico não informado */
	INDICADOR_TOKEN_UNICO_NAO_INFORMADA(621),
	/** Dados para envio de token não encontrados */
	DADOS_ENVIO_TOKEN_NAO_ENCONTRADOS(622),
	/** Usuario não possui meio de acesso habilitado */
	USUARIO_SEM_MEIO_ACESSO_HABILITADO(623),
	/** Dispositivo não habilitado para QR Token */
	DISPOSITIVO_NAO_HABILITADO_QR_TOKEN(624),
	/** Usuario não possui dispositivo para o tipo de token */
	USUARIO_NAO_POSSUI_DISPOSITIVO_TIPO_TOKEN(625),
	/** Dispositivo não encontrado */
	DISPOSITIVO_NAO_ENCONTRADO(626),
	/** Dispositivo não esta bloqueado */
	DISPOSITIVO_NAO_BLOQUEADO(627),
	/** Dispositivo não esta pendente */
	DISPOSITIVO_NAO_PENDENTE(628),
	/** Dispositivo não esta liberado */
	DISPOSITIVO_NAO_LIBERADO(629),   
	/** Tipo de Token não encontrado */
	TIPO_TOKEN_NAO_ENCONTRADO(630),
	/** Tipo de token não esta bloqueado para o usuario */
	TIPO_TOKEN_NAO_BLOQUEADO_USUARIO(631),
	/** Tipo de token não esta liberado para o usuario */
	TIPO_TOKEN_NAO_LIBERADO_USUARIO(632),
	/** Tipo de token não esta pendente para o usuario */
	TIPO_TOKEN_NAO_PENDENTE_USUARIO(633),
	/** Relacionamento entre Canal e Tipo de Token não encontrado */
	RELACIONAMENTO_CANAL_TIPO_TOKEN_NAO_ENCONTRADO(634),   
	/** Relacionamento entre Usuario e Tipo de Token não encontrado */
	RELACIONAMENTO_USUARIO_TIPO_TOKEN_NAO_ENCONTRADO(635),
	/** não existe token para o dispositivo */
	NAO_EXISTE_TOKEN_DISPOSITIVO(636),
	/** Identificador do dispositivo não informado */
	IDENTIFICADOR_DISPOSITIVO_NAO_INFORMADO(637),
	/** Endereço IP não informado */
	ENDERECO_IP_NAO_INFORMADO(638),
	/** Motivo de bloqueio não informado */
	MOTIVO_BLOQUEIO_NAO_INFORMADO(639),
	/** Motivo de bloqueio inválido */
	MOTIVO_BLOQUEIO_INVALIDO(640),
	/** Apelido do dispositivo não informado */
	APELIDO_DISPOSITIVO_NAO_INFORMADO(641),
	/** Codigo de ativação do dispositivo não informado */
	CODIGO_ATIVACAO_DISPOSITIVO_NAO_INFORMADO(642),
	/** Indicador de liberação de dispositivo não informado */
	INDICADOR_LIBERACAO_DISPOSITIVO_NAO_INFORMADO(643),
	/** Dispositivo já esta bloqueado */
	DISPOSITIVO_JA_BLOQUEADO(644),
	/** Tipo de token já esta bloqueado */
	TIPO_TOKEN_JA_BLOQUEADO(645),
	/** Situação do dispositivo não permite a operação */
	SITUACAO_DISPOSITIVO_NAO_PERMITE_OPERACAO(646),
	/** Valor inferior ao valor mínimo para abertura de conta */
	VALOR_MENOR_MINIMO_ABERTURA_CONTA(647),   
	/** Valor inferior ao valor mínimo para transferência */
	VALOR_MENOR_MINIMO_TRANSFERENCIA(648), 
	/** Senha não esta bloqueada */
	SENHA_NAO_BLOQUEADA(649),
	/** Token não confere */
	TOKEN_NAO_CONFERE(650),
	/** Token expirado */
	TOKEN_EXPIRADO(651),
	/** Excedeu limite de token inválido */
	EXCEDEU_LIMITE_TOKEN_INVALIDO(652),
	/** QR Token não confere */
	QR_TOKEN_NAO_CONFERE(653),
	/** QR Token expirado */
	QR_TOKEN_EXPIRADO(654),
	/** Excedeu limite de QR token inválido */
	EXCEDEU_LIMITE_QR_TOKEN_INVALIDO(655),
	/** não existe token para o usuario */
	NAO_EXISTE_TOKEN_USUARIO(656),			   
	/** não é um usuario do Internet Banking */
	NAO_E_USUARIO_INTERNET_BANKING(657),   
	/** Descrição de lançamento não encontrada */
	DESCRICAO_LANCAMENTO_NAO_ENCONTRADA(658),
	/** Nome do arquivo inválido */
	NOME_ARQUIVO_INVALIDO(659),
	/** Número sequencial do arquivo inválido */
	NUMERO_SEQUENCIAL_ARQUIVO_INVALIDO(660),   
	/** Valor menor do que o valor mínimo permitido para a aplicação */
	VALOR_MENOR_MINIMO_PERMITIDO_APLICACAO(661),
	/** Agência/conta do header divergem da conta submetida */
	AGENCIA_CONTA_DIVERGENTE(662),
	/** Número sequencial do arquivo no header diverge do nome do arquivo */
	NUMERO_SEQUENCIAL_ARQUIVO_DIVERGENTE(663),
	/** Valor do TÃ­tulo divergente do informado */
	VALOR_TITULO_DIVERGENTE_INFORMADO(664),
	/** Cliente não possui conta ativa */
	CLIENTE_SEM_CONTA_ATIVA(665),
	/** Valor menor do que o valor mínimo permitido para o tÃ­tulo */
	VALOR_MENOR_MINIMO_PERMITIDO_TITULO(682),
	/** Valor maior do que o valor máximo permitido para o tÃ­tulo */
	VALOR_MAIOR_MAXIMO_PERMITIDO_TITULO(683),
	/** NPC em contingência */
	NPC_EM_CONTINGENCIA(684),
	/** NPC em contingência Erro ao Consultar CBR*/
	NPC_EM_CONTINGENCIA_ERRO_CONSULTA_CBR(685),
	/** NPC em contingência Efetivacao nao Permitida*/
	NPC_EFETIVACAO_NAO_PERMITIDA_EM_CONTINGENCIA(687),
	/** Data do agendamento superior ao permitido*/
	AGENDAMENTO_SUPERIOR_PERMITIDO(688),
	NPC_EM_CONTINGENCIA_TITULO_VENCIDO_OUTROS_BANCOS(689),
	NPC_EFETIVACAO_NAO_VALORES_DIVERGENTES(690),   
	RESPOSTA_INVALIDA_QUESTIONARIO_PERFIL_INVESTIDOR(691),
	CODIGO_NAI_INVALIDO(692),
	CPF_CODIGO_NAI_INVALIDO(693),
	COD_BANCO_CODIGO_NAI_INVALIDO(694),
	COD_CONTROLE_CODIGO_NAI_INVALIDO(695),
	TIMESTAMP_CODIGO_NAI_INVALIDO(696),
	CPF_NAO_ENCONTRADO_CODIGO_NAI(697),
	CODIGO_AUTORIZACAO_CARTAO_EXTERIOR_FALHA(699),
	DATA_MAIOR_DATA_REFERENCIA(700),
	MAIS_DE_UM_CODIGO_DE_CLIENTE_PARA_O_CPF_DO_TITULAR(702),
	CADASTRO_DA_CONTA_EM_ATUALIZACAO(703),
	INCLUSAO_FORMULARIO_PROVISIONAMENTO_ESPECIE(704),
	CPF_CNPJ_NAO_CADASTRADO_OU_ENCONTRADO(705),
	FRM_HORARIO_NAO_PERMITIDO(706),
	FRM_DATA_SOLICITACAO_NAO_UTIL(707),
	FRM_DATA_SAQUE_NAO_UTIL(708),
	FRM_SAQUE_INFERIOR_TRES_DIAS_UTEIS(709),  
	INVALID_LIMIT_TYPE(710),
	DATA_VENCIMENTO_CONTRATO_INVALIDA(711),
	VALOR_LIMITE_MENOR_OU_IGUAL_AO_LIMITE_ANTERIOR(712),
	FRM_SAQUE_MENOR_50MIL(713),
	TRANSACAO_NAO_PODE_SER_REALIZADA_EM_DIA_NAO_UTIL(714),
	INVALID_EMAIL(727);
	
    @Getter
    private Integer codigo;
    
    private static final Map<Integer, EnumErrorCodeBLK> MAP = new HashMap<>();
    
    static {
        for (EnumErrorCodeBLK e : EnumErrorCodeBLK.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumErrorCodeBLK get(Integer codigo) {
        return MAP.get(codigo);
    }
}

package br.com.brb.cix.config.jackson;

import java.lang.annotation.Annotation;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.cfg.MapperConfig;
import com.fasterxml.jackson.databind.introspect.AnnotatedMethod;

import br.com.brb.cix.config.anotacao.LabelAuditoriaAlcada;
import br.com.brb.cix.util.CixUtil;

public class FormataLabels extends PropertyNamingStrategy {
    private static final long serialVersionUID = 1L;

    /** Caso a propriedade no DTO possua a anotação {@link br.com.brb.cix.config.anotacao.LabelAuditoriaAlcada}, utiliza o valor definido na anotação como label do campo.
     *  Caso contrário, utiliza o formatador automático de labels. */
    @Override
    public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
        Iterable<Annotation> annotations = method.annotations();
        for(Annotation annotation : annotations){
            if (annotation.annotationType().equals(LabelAuditoriaAlcada.class)){
                return ((LabelAuditoriaAlcada) annotation).value();
            }
        }
        return CixUtil.formataLabel(defaultName);
    }
}
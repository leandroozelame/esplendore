package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FormaPagamentoDTO{
    private Long codigo;
    private String descricao;
    private Date dataCriacao;
    private Date dataAlteracao;
    private Boolean habilitado;
    private BigDecimal valorMaximoPagamento;
    private Long codigoFuncionalidadeFormaPagamento;
}

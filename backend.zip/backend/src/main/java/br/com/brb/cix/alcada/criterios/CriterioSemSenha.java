package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.regra.Regra;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CriterioSemSenha implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Sem Senha";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegra.INDIFERENTE.equals(regra.getSemSenha());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        Boolean semSenha = dadosTransacao.getSemSenha();

        if (semSenha == null) {
            log.debug("semSenha: {}", semSenha);
            return false;
        }

        EnumValorRegra regraSemSenha = regra.getSemSenha();
        log.debug("regraSemSenha: {}, semSenha: {}", regraSemSenha, semSenha);

        return (regraSemSenha.equals(EnumValorRegra.NAO) && !semSenha)
                || (regraSemSenha.equals(EnumValorRegra.SIM) && semSenha);
    }
}

package br.com.brb.cix.domain.model.viasrecibo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class ViasReciboId implements Serializable {

    private static final long serialVersionUID = -6382645111104393928L;

    @Column(name = "SQ_FUNCIONALIDADE", nullable = false)
    private Long codigoFuncionalidade;

    @Column(name = "CD_FORMA_PAGAMENTO", nullable = false)
    private Long codigoFormaPagamento;
}

package br.com.brb.cix.auditoria;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;

@Converter(autoApply = true)
public class EnumTipoContaConverter implements AttributeConverter<EnumTipoConta, Integer> {

    @Override
    public Integer convertToDatabaseColumn(EnumTipoConta enumDominio) {
        return enumDominio != null ? enumDominio.getCodigo() : null;
    }

    @Override
    public EnumTipoConta convertToEntityAttribute(Integer codigo) {
        for (EnumTipoConta enumDominio : EnumTipoConta.values()) {
            if (enumDominio.getCodigo().equals(codigo)) {
                return enumDominio;
            }
        }
        return null;
    }
}
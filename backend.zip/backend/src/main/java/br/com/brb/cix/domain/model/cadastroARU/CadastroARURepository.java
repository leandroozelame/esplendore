package br.com.brb.cix.domain.model.cadastroARU;

import br.com.brb.cix.domain.model.modulo.Modulo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CadastroARURepository extends JpaRepository<CadastroARU, Long> {
    List<CadastroARU>findByNumeroContrato(Integer numeroContrato);

    List<CadastroARU> findByNumeroContratoAndModuloAndAtivo(Integer numeroContrato, Modulo modulo, Boolean ativo);

    List<CadastroARU> findByNumeroContratoAndModuloCodigoAndAtivo(Integer numeroContrato, Long moduloCodigo, Boolean ativo);

}
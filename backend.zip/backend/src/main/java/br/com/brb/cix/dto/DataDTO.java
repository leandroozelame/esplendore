package br.com.brb.cix.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class DataDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String extenso;
    private String primeiroDia;
    private String ultimoDia;
    private String mes;
    private String ano;

    public DataDTO(String mes, String ano, String extenso, String primeiroDia, String ultimoDia) {
        this.extenso = extenso;
        this.primeiroDia = primeiroDia;
        this.ultimoDia = ultimoDia;
        this.mes = mes;
        this.ano = ano;
    }

    @Override
    public String toString() {
        return extenso;
    }
}
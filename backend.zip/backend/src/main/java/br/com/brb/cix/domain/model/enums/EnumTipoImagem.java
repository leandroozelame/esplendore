package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoImagem implements EnumDominio {
    DOCUMENTO_INTEIRO(1, "Documento Inteiro"),
    RECORTE(2, "Recorte"), 
    SOMENTE_ASSINATURA(3, "Somente Assinatura"); 

    private static final Map<Integer, EnumTipoImagem> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoImagem e : EnumTipoImagem.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoImagem get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumTipoImagem criaEnum(int tipoImagem) {
        return MAP.get(tipoImagem);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
}
package br.com.brb.cix.enums;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumEnquadramento {
    SIM(0, "Sim, enquadrado"), NAO(1, "Não enquadrado");

    private static final Map<Integer, EnumEnquadramento> MAP = new HashMap<>();
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumEnquadramento e : EnumEnquadramento.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumEnquadramento get(Integer codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}
package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultaFuncionalidadeFormaDTO {

    private Long idFuncionalidadeFormaPagamento;
    private Integer codigoModulo;
    private String nomeModulo;
    private Integer codigoUnidade;
    private String nomeUnidade;
    private Long codigoTerminal;
    private String descricaoTerminal; 
    private Long codigoFuncionalidade;
    private String nomeFuncionalidade;
    private Long codigoFormaPagamento;
    private String nomeFormaPagamento;
    private BigDecimal valorMaximoPagamento;
    private Boolean aceitaFormaPagamento;
    private Boolean selecionado;
}

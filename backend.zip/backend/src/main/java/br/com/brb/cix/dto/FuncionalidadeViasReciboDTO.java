package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
public class FuncionalidadeViasReciboDTO {
    @NotNull
    private Long codigoFuncionalidade;
    private String nomeFuncionalidade;
    @NotNull
    private List<FormaPagamentoViasReciboDTO> formasPagamento;
}
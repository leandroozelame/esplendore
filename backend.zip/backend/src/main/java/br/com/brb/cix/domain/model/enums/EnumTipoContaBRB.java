package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoContaBRB {
    CORRENTE(1, "Conta Corrente", "CC"), 
    POUPANCA(2, "Conta Poupança", "CP"),
    POUPANCA_INTEGRADA(8, "Poupança Investimento", "PI"),
    SALARIO(11, "Conta Salário", "CS"),
    CONTA_INVESTIMENTO(12, "Conta Investimento", "CI"),
    CONTA_VINCULADA(14,"Conta Vinculada", "CV");

    private static final Map<Integer, EnumTipoContaBRB> MAP_TIPO_CONTA_ENUM = new HashMap<>();
    
    @Getter
    private int valor;
    @Getter
    private String descricao;
    @Getter
    private String sigla;
    @Getter
    private final Integer tipoConta;

    static {
        for (EnumTipoContaBRB e : EnumTipoContaBRB.values()) {
            MAP_TIPO_CONTA_ENUM.put(e.getTipoConta(), e);
        }
    }

    private EnumTipoContaBRB(int tipoConta, String descricao, String sigla) {
        this.tipoConta = tipoConta;
        this.descricao = descricao;
        this.sigla = sigla;
    }

    public static EnumTipoContaBRB get(int tipoConta) {
        return MAP_TIPO_CONTA_ENUM.get(tipoConta);
    }
}
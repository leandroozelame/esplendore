package br.com.brb.cix.auditoria;

import java.util.LinkedHashMap;
import java.util.Map;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.brb.cix.config.ContextProvider;
import lombok.extern.slf4j.Slf4j;

@Converter(autoApply = true)
@Slf4j
public class MapConverter implements AttributeConverter<Map<String, Object>, String> {

    private ObjectMapper auditoriaObjectMapper;
	
    @Override
    public String convertToDatabaseColumn(Map<String, Object> mapa) {
        try {
			return getAuditoriaObjectMapper().writeValueAsString(mapa);
		} catch (Exception e) {
			log.error("convertToDatabaseColumn()", e);
		}
        return null;
    }

    @Override
    public Map<String, Object> convertToEntityAttribute(String json) {
    	try {
			Map<String, Object> mapa = getAuditoriaObjectMapper().readValue(json, new TypeReference<LinkedHashMap<String,Object>>() {});
			return mapa;
		} catch (Exception e) {
			log.error("convertToEntityAttribute()", e);
		} 
        return null;
    }
    
    public ObjectMapper getAuditoriaObjectMapper() {
    	if(auditoriaObjectMapper == null) {
    		auditoriaObjectMapper = (ObjectMapper) ContextProvider.getBean("auditoriaObjectMapper");
    	}
    	return auditoriaObjectMapper;
    }
}

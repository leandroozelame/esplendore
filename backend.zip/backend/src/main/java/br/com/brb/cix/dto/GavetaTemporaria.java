package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import br.com.brb.cix.infraestrutura.CixException;
import br.com.brb.cix.util.CixUtil;

@Component
@Scope(value = WebApplicationContext.SCOPE_APPLICATION)
@EnableScheduling
public class GavetaTemporaria {
    @Autowired
    private HttpServletRequest httpReq;
	
    private List<GavetaDTO> gavetas = new ArrayList<GavetaDTO>();
    
    private int findGaveta() {
    	String Ip = CixUtil.getClientIp(httpReq);
    	
        for (int i = 0; i < gavetas.size(); i++) {
        	if (gavetas.get(i).getIp().equals(Ip)) return i; 
        }
    	return -1;  
    }
    
    public GavetaDTO getGaveta() throws CixException {
    	int i = findGaveta();
    	
    	if (i > -1) return gavetas.get(i);
    	throw new CixException("Gaveta não encontrada, refaça operação da Gaveta");
    }

    public void setGaveta(GavetaDTO gaveta) {
    	int i = findGaveta();

		gaveta.setIp(CixUtil.getClientIp(httpReq));
    	if (i > -1) { 
    		gavetas.set(i, gaveta);
    	} else { 
    		gavetas.add(gaveta);
    	}
    }
    
    public void removeGaveta() {
    	int i = findGaveta();

    	if (i > -1)	gavetas.remove(i);
    }
    
    public void zeraValores() throws CixException {
    	GavetaDTO gaveta = getGaveta();
    	
    	gaveta.setValorTransacao(BigDecimal.ZERO);
    	gaveta.setValorEntregueRecebimento(BigDecimal.ZERO);
    	gaveta.setValorEntregueTroca(BigDecimal.ZERO);
    	gaveta.setValorRecebidoTroca(BigDecimal.ZERO);
    }

    @Scheduled(cron = "0 0 0 * * *") // meia noite
    public void removeAllGavetas() {
    	gavetas.clear();
    }
}

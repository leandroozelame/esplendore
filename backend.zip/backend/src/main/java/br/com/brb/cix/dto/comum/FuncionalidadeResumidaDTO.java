package br.com.brb.cix.dto.comum;

import br.com.brb.cix.dto.AbstractDTO;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FuncionalidadeResumidaDTO extends AbstractDTO {
    private Long codigo;
    private Integer codigoMenu;
    private String codigoFuncionalidade;
    private String nome;
    private Integer modulo;
    private Boolean impressao;
}
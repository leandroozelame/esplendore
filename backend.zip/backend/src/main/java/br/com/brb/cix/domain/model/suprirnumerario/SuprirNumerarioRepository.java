package br.com.brb.cix.domain.model.suprirnumerario;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SuprirNumerarioRepository extends JpaRepository<SuprirNumerario, Long> {
    @Query(value = " SELECT * FROM {h-schema}TB_NUMERARIO_SUPRIDO s "
            + "WHERE s.CD_UNIDADE = ?1 ", nativeQuery = true)
    List<SuprirNumerario> listaExisteValoresASuprir(Long codigoUnidade);	

    @Query(value = " SELECT * FROM {h-schema}TB_NUMERARIO_SUPRIDO s, {h-schema}TB_NUMERARIO_RETIDO r "
            + "WHERE r.SQ_NUMERARIO_RETIDO = s.SQ_NUMERARIO_RETIDO "
            + "AND r.SQ_NUMERARIO_RETIDO = ?1 ", nativeQuery = true)
    List<SuprirNumerario> listaValoresSupridosPelaSequence(Long codigoReterNumerario);

    Optional<SuprirNumerario> findByDataSuprimentoAndMatriculaOperadorAndCodigoUnidadeAndValorSuprido(Date dataSuprimento, Long matriculaOperador, Long codigoUnidade, BigDecimal valorSuprido);
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.enums.EnumStatusExecucaoSupertransacao;
import lombok.Data;

@Data
public class SupertransacaoSimplesDTO {
	
	private EnumStatusExecucaoSupertransacao status;
	private BigDecimal subtotal;
}

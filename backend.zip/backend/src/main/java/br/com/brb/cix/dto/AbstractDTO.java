package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@EqualsAndHashCode
public abstract class AbstractDTO {

	@JsonProperty
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	protected List<ContaTipoDTO> contasOrigem = new ArrayList<ContaTipoDTO>();
	@JsonProperty
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	protected List<ContaTipoDTO> contasDestino = new ArrayList<ContaTipoDTO>();
	@JsonProperty
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
    protected String origemDestinoRecurso;
	
    public static final SimpleDateFormat SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");

	public void addContaOrigem(Long conta, Long agencia, EnumTipoConta tipoConta, EnumTipoModalidade tipoModalidade) {
		contasOrigem.add(new ContaTipoDTO(conta, agencia, tipoConta, tipoModalidade));		
	}

	public void addContaDestino(Long conta, Long agencia, EnumTipoConta tipoConta, EnumTipoModalidade tipoModalidade) {
		contasDestino.add(new ContaTipoDTO(conta, agencia, tipoConta, tipoModalidade));		
	}
}
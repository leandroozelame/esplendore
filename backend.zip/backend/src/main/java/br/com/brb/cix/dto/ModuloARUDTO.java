package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.ws.consulta.dto.EnumSimNao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ModuloARUDTO {
    private Long codigoModulo;
    private String descricaoModulo;
    private EnumSimNao estorno;
    private List<FormaPagamentoARUDTO> formasPagamentos;
}
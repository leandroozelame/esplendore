package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ConsultaTransacaoEstornoDTO {

    private Boolean aceitaEstorno;
    private String horaLimiteEstorno;
    private BigDecimal valorLimiteEstorno;
}

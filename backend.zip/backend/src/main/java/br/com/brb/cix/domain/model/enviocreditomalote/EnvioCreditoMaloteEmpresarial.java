package br.com.brb.cix.domain.model.enviocreditomalote;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TB_ENVIO_CREDITO_MALOTE")
public class EnvioCreditoMaloteEmpresarial {
	@Id
	@SequenceGenerator(name = "envio_credito_malote_sequence", sequenceName = "SQ_ENVIO_CREDITO_MALOTE", allocationSize = 1)
    @GeneratedValue(generator = "envio_credito_malote_sequence")
    @Column(name = "SQ_ENVIO_CREDITO_MALOTE")
    private Long codigo;
	
    @Column(name = "NR_NSU")
    private Long nsu;
	
	@Column(name = "NR_CORRESPONDENTE")
    private Long numeroCorrespondente;
	
	@Column(name = "NO_CORRESPONDENTE")
    private String nomeCorrespondente;
	
    @JsonBackReference(value = "formaPagamento")
    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO", referencedColumnName = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;
    
    @Column(name = "VL_ENVIO")
    private BigDecimal valorEnviado;
    
    @Column(name = "NR_FICHA_CONTABIL")
    private Long numeroFichaContabil;
    
    @Column(name = "NR_CONTA")
    private Long numeroConta;
    
    @Column(name = "CD_CMC7")
    private String cmc7;
    
    @Column(name = "NR_CHEQUE")
    private Integer nrCheque;
}
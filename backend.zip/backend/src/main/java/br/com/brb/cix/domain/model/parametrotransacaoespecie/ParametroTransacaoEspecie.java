package br.com.brb.cix.domain.model.parametrotransacaoespecie;


import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.util.ConvertCharToBoolean;
import br.com.brb.cix.util.ConvertRecebimentoPagamento;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TB_TRANSACAO_ESPECIE")
public class ParametroTransacaoEspecie  {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name = "parametro_transacao_especie_sequence", sequenceName = "SQ_TRANSACAO_ESPECIE", allocationSize = 1)
    @GeneratedValue(generator = "parametro_transacao_especie_sequence")
    @Column(name = "SQ_TRANSACAO_ESPECIE")
    private Long codigo;
  
    @Column(name = "CD_MODULO")
    private Integer modulo;
  
    //@JsonBackReference(value = "funcionalidade")
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE", nullable = true)
    private Funcionalidade funcionalidade;
    
    @Convert(converter = ConvertRecebimentoPagamento.class)
    @Column(name = "ST_IDENTIFICACAO")
    private String destinoOrigem;
    
    @Column(name = "VL_TRANSACAO")
    private BigDecimal valor;
  
    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_HABILITADO")
    private Boolean habilitado;
}

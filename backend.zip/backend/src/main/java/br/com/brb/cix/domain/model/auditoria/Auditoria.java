package br.com.brb.cix.domain.model.auditoria;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters.LocalDateTimeConverter;

import br.com.brb.cix.auditoria.EnumCanalConverter;
import br.com.brb.cix.auditoria.EnumSituacaoExecucao;
import br.com.brb.cix.auditoria.EnumSituacaoExecucaoConverter;
import br.com.brb.cix.auditoria.EnumTipoContaConverter;
import br.com.brb.cix.auditoria.MapConverter;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumCanal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor()
@NoArgsConstructor()
@EqualsAndHashCode(callSuper = false)
@ToString
@Table(name = "TB_LOG_AUDITORIA")
public class Auditoria  {

    private static final long serialVersionUID = -9183640981662144834L;

    @Id
    @GeneratedValue(generator = "auditoria_sequence")
    @SequenceGenerator(name = "auditoria_sequence", sequenceName = "SQ_LOG_AUDITORIA", allocationSize = 1)
    @Column(name = "SQ_LOG_AUDITORIA", nullable = true)
    private Long id;

    @Convert(converter = LocalDateTimeConverter.class)
    @Column(name = "DT_OPERACAO", columnDefinition = "date")
    private LocalDateTime dataOperacao;

    @Column(name = "NR_TERMINAL", nullable = true)
    private Integer nrTerminal;

    @Column(name = "DS_IP_CLIENTE", nullable = true)
    private String ip;

    @Column(name = "DS_NOME_SERVIDOR ", nullable = true)
    private String servidor;

    @Column(name = "CD_RESPOSTA", nullable = true)
    private Integer cdResposta;

    @Column(name = "DS_MATRICULA_OPERADOR", nullable = true)
    private String operador;

    @Column(name = "DS_AGENCIA_OPERADOR", nullable = true)
    private String agenciaOperador;

    @Column(name = "DS_NOME_OPERADOR", nullable = true)
    private String nomeOperador;

    @Column(name = "CD_UNIDADE_OPERADOR", nullable = true)
    private Long codigoUnidadeOperador;

    @Column(name = "DS_UNIDADE_OPERADOR", nullable = true)
    private String descricaoUnidadeOperador;

    @OneToMany(mappedBy = "auditoria", fetch = FetchType.LAZY)
    private List<SupervisorLogAuditoria> supervisores;

    @Column(name = "DS_CPF_CLIENTE", nullable = true)
    private String cpfCliente;

    @Column(name = "DS_NOME_CLIENTE", nullable = true)
    private String nomeCliente;

    @Column(name = "CD_TIPO_CONTA_CLIENTE", nullable = true)
    @Convert(converter = EnumTipoContaConverter.class)
    private EnumTipoConta tpConta;

    @Column(name = "DS_CONTA_CLIENTE", nullable = true)
    private String conta;

    @Column(name = "VL_OPERACAO", nullable = true)
    private BigDecimal vlOperacao;

    @Column(name = "CD_CODIGO_TRANSACAO", nullable = true)
    private Integer cdTransacao;

    @Column(name = "DS_NOME_TRANSACAO ", nullable = true)
    private String nomeTransacao;

    @Column(name = "NR_CANAL", nullable = true)
    @Convert(converter = EnumCanalConverter.class)
    private EnumCanal nrCanal;

    @Column(name = "DS_FUNCIONALIDADE", nullable = true)
    private String funcionalidade;

    @Column(name = "CD_NSU_CANAL", nullable = true)
    private Integer cdNsuCanal;

    @Column(name = "CD_NSU_AUTORIZACAO", nullable = true)
    private Long cdNsuAutorizacao;

    @Column(name = "CD_NSU_LOG", nullable = true)
    private Integer cdNsuLog;

    @Column(name = "DS_MENSAGEM", nullable = true)
    private String mensagem;
    
    @Column(name = "DS_EVENTO", nullable = true)
    private String evento;

    @Column(name = "ST_EXECUCAO", nullable = true)
    @Convert(converter = EnumSituacaoExecucaoConverter.class)
    private EnumSituacaoExecucao situacaoExecucao;

    @Convert(converter = MapConverter.class)
    @Column(name = "TX_REQUISICAO", columnDefinition = "clob")
    private LinkedHashMap<String, Object> mapaParametroEntrada;

    @Convert(converter = MapConverter.class)
    @Column(name = "TX_RESPOSTA", columnDefinition = "clob")
    private LinkedHashMap<String, Object> mapaParametrosSaida;
}
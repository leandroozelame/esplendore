package br.com.brb.cix.domain.model.grupocnp;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GrupoCNPRepository extends JpaRepository<GrupoCNP, Long> {
    
    static final String SQL_NATIVE_BUSCA_GRUPOSCNP_POR_UNIDADE = "SELECT * FROM {h-schema}TB_GRUPO tg WHERE tg.SQ_GRUPO IN ("
            + "SELECT tgc.SQ_GRUPO FROM {h-schema}TB_GRUPO_CORRESPONDENTE tgc "
            + "WHERE tgc.CD_UNIDADE = ?1)";
    
    static final String SQL_NATIVE_BUSCA_CNP_EM_TIPO_GRUPO = "SELECT * FROM {h-schema}TB_GRUPO tg WHERE tg.TP_GRUPO = ?1 AND tg.SQ_GRUPO IN ("
            + "SELECT tgc.SQ_GRUPO FROM {h-schema}TB_GRUPO_CORRESPONDENTE tgc "
            + "WHERE tgc.CD_UNIDADE = ?2)";
    
    @Query(nativeQuery = true, value = SQL_NATIVE_BUSCA_GRUPOSCNP_POR_UNIDADE)
    List<GrupoCNP> findByUnidade(Long codigoUnidade);
    
    @Query(nativeQuery = true, value = SQL_NATIVE_BUSCA_CNP_EM_TIPO_GRUPO)
    GrupoCNP cnpEstaEmTipoGrupo(Long codigoCNP, Character tipoGrupo);
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(nativeQuery=true, value = "DELETE FROM {h-schema}TB_GRUPO tg WHERE tg.SQ_GRUPO = ?1")
    void deleteByCodigo(Long codigo);
    
    @Transactional
    @Modifying(clearAutomatically = true)
    @Query(nativeQuery=true, value = "DELETE FROM {h-schema}TB_GRUPO_CORRESPONDENTE tgc WHERE tgc.SQ_GRUPO = ?1")
    void deleteAllCorrespondentes(Long codigo);
}

package br.com.brb.cix.dto;

import java.util.Date;
import java.util.List;

import lombok.*;

/**
 *
 * @author NUCAN
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class PerfilDTO {
    private Long codigo;
    private String nome;
    private String descricao;
    private Character ativo;
    private Integer matricula;
    private Date dataCriacao;
    private Date dataAlteracao;
    private Integer modulo;
    private List<GrupoDTO> listaGrupos;
    private List<FuncionalidadeDTO> listaFuncionalidades;
    private MenuDTO menu;

    public PerfilDTO(String nome, String descricao, Integer matricula, Integer modulo) {
        this.nome = nome;
        this.descricao = descricao;
        this.matricula = matricula;
        this.modulo = modulo;
    }
}

package br.com.brb.cix.domain.model.unidade;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UnidadeRepository extends JpaRepository<Unidade, Long> {
    
    static final String SQL_LISTA_UNIDADES_POR_GRUPOCNP = "SELECT vu.* FROM {h-schema}VW_UND vu "
            + "LEFT JOIN {h-schema}TB_GRUPO_CORRESPONDENTE tgc ON tgc.CD_UNIDADE = vu.UNDCOD "
            + "WHERE vu.UNDTIP = 2 AND tgc.SQ_GRUPO = ?1 "
            + "ORDER BY vu.UNDCOD";
    
    List<Unidade> findByCategoriaGreaterThanAndTransacionavelOrderByCodigo(Integer categoria, Integer transacionavel);

    List<Unidade> findByCategoriaGreaterThanEqualAndTransacionavelOrderByCodigo(Integer categoria, Integer transacionavel);

    @Query(value = "SELECT undcat FROM {h-schema}VW_OPR o, {h-schema}VW_UND u WHERE oprmat = ?1 AND o.undcod = u.undcod",
            nativeQuery = true)
    Integer findCategoriaByMatricula(String matricula);

    Unidade findByCodigo(Long codigo);
    
    List<Unidade> findAllByOrderByCodigo();
    
    List<Unidade> findByTipoOrderByCodigo(Integer tipo);
    
    @Query(value = SQL_LISTA_UNIDADES_POR_GRUPOCNP, nativeQuery = true)
    List<Unidade> findByCodigoGrupo(Long codigo);
    
}

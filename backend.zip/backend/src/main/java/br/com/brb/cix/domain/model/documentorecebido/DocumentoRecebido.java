package br.com.brb.cix.domain.model.documentorecebido;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.terminal.Terminal;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_DOCUMENTO_RECEBIDO")
public class DocumentoRecebido  {
	
	private static final long serialVersionUID = -228452393603798534L;

	@Id
	@SequenceGenerator(name = "sequence_doc_recebido", sequenceName = "SQ_DOCUMENTO_RECEBIDO", allocationSize = 1)
	@GeneratedValue(generator = "sequence_doc_recebido")
	@Column(name = "SQ_DOCUMENTO_RECEBIDO")
	private Long id;
	
	@Column(name = "DS_CODIGO_BARRA", nullable = false)
	private String codigoBarras;
	
	@Column(name = "CD_UNIDADE")
    private Long unidade;
	
	@ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;
	
	@Column(name = "CD_TRANSACAO")
    private Long numeroTransacao;
    
    @Column(name = "NR_NSU")
    private Long nsu;
    
    @Column(name = "DT_RECEBIMENTO")
    private Date dataRecebimento;
}

package br.com.brb.cix.domain.model.enums.converter;

import br.com.brb.cix.enums.EnumFormaMovimentacao;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumFormaMovimentoConverter implements AttributeConverter<EnumFormaMovimentacao, Integer> {

    @Override
    public Integer convertToDatabaseColumn(EnumFormaMovimentacao valorRegra) {
        return valorRegra != null ? valorRegra.getCodigo() : null;
    }

    @Override
    public EnumFormaMovimentacao convertToEntityAttribute(Integer codigo) {
        return EnumFormaMovimentacao.get(codigo);
    }
}

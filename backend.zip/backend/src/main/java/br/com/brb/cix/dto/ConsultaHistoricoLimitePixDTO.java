package br.com.brb.cix.dto;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ConsultaHistoricoLimitePixDTO extends AbstractDTO {
    private Long conta;
    private Date dataInicio;
    private Date dataFim;
    private String cpfCnpj;
    protected Integer situacao;
}
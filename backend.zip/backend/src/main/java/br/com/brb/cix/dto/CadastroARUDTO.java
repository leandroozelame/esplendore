package br.com.brb.cix.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CadastroARUDTO {
    private ContratoARUDTO contratoARUDTO;
    private List<ModuloARUDTO> moduloARUDTO;
}
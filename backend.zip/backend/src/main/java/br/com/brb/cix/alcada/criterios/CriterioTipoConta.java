package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoConta;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.ws.consulta.dto.InformacaoConta;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CriterioTipoConta implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Tipo de Conta";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegraTipoConta.INDIFERENTE.equals(regra.getTipoConta());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        InformacaoConta informacaoConta = dadosTransacao.getInformacaoConta();
        if (informacaoConta == null) {
            log.debug("informacaoConta: {}", informacaoConta);
            return false;
        }

        EnumValorRegraTipoConta regraTipoConta = regra.getTipoConta();
        Integer tipoConta = informacaoConta.getTipo();
        Integer modalidade = informacaoConta.getModalidade();
        EnumValorRegraTipoConta tipoContaConvertido = converteTipoContaDoBlk(EnumTipoConta.get(tipoConta), EnumTipoModalidade.get(modalidade));
        log.debug("regraTipoConta: {}, tipoConta: {}, modalidade: {}, tipoContaConvertido: {}", regraTipoConta, tipoConta, modalidade, tipoContaConvertido);

        return regraTipoConta.equals(tipoContaConvertido);
    }

    private EnumValorRegraTipoConta converteTipoContaDoBlk(EnumTipoConta tipoConta, EnumTipoModalidade modalidade) {
        if (modalidade.equals(EnumTipoModalidade.CONTA_VINCULADA)) {
            return EnumValorRegraTipoConta.CONTA_VINCULADA;
        }
        if (tipoConta.equals(EnumTipoConta.POUPANCA)){
            if(modalidade.equals(EnumTipoModalidade.POUPANCA_INTEGRADA)){
                return EnumValorRegraTipoConta.POUPANCA_INTEGRADA;
            }else{
                return EnumValorRegraTipoConta.CONTA_POUPANCA;
            }
        }
        if(tipoConta.equals(EnumTipoConta.SALARIO)){
            return EnumValorRegraTipoConta.CONTA_SALARIO;
        }
        return EnumValorRegraTipoConta.CONTA_CORRENTE;
    }
}

package br.com.brb.cix.config.jackson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import br.com.brb.cix.domain.model.unidade.Unidade;

public class CustomUnidadeSerializer extends StdSerializer<List<Unidade>> {

    private static final long serialVersionUID = -6436189492307793383L;

    public CustomUnidadeSerializer(){
        this(null);
    }
    
    public CustomUnidadeSerializer(Class<List<Unidade>> t){
        super(t);
    }
    
    @Override
    public void serialize(List<Unidade> units, 
            JsonGenerator generator, SerializerProvider provider)
            throws IOException {
        
        List<Unidade> unidades = new ArrayList<>();
        
        for (Unidade unidade : units) {
            unidade.setListaGrupos(null);
            unidades.add(unidade);
        }
        
        generator.writeObject(unidades);
    }

    

}

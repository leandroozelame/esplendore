package br.com.brb.cix.domain.model.regra;

import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoConta;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoPessoa;
import br.com.brb.cix.domain.model.enums.converter.EnumFormaMovimentoConverter;
import br.com.brb.cix.domain.model.enums.converter.EnumValorRegraConverter;
import br.com.brb.cix.domain.model.enums.converter.EnumValorRegraTipoContaConverter;
import br.com.brb.cix.domain.model.enums.converter.EnumValorRegraTipoPessoaConverter;
import br.com.brb.cix.domain.model.grupo.Grupo;
import br.com.brb.cix.domain.model.pendencia.Pendencia;
import br.com.brb.cix.dto.GrupoDTO;
import br.com.brb.cix.dto.RegraDTO;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "TB_REGRA")
@ToString
public class Regra  {
    private static final long serialVersionUID = -7884383952009631330L;

    @Id
    @SequenceGenerator(name = "regra_sequence", sequenceName = "SQ_REGRA", allocationSize = 1)
    @GeneratedValue(generator = "regra_sequence")
    @Column(name = "SQ_REGRA")
    private Long codigo;

    @Column(name = "NO_REGRA")
    private String nome;

    @Column(name = "NR_PRIORIDADE")
    private Integer prioridade;

    @Column(name = "SQ_FUNCIONALIDADE")
    private Long codigoFuncionalidade;

    @Column(name = "ST_CONTA_OPERADOR")
    @Convert(converter = EnumValorRegraConverter.class)
    private EnumValorRegra contaOperador;

    @Column(name = "ST_CONTA_OUTRO_PA")
    @Convert(converter = EnumValorRegraConverter.class)
    private EnumValorRegra contaOutroPA;

    @Column(name = "ST_ESTORNO")
    @Convert(converter = EnumValorRegraConverter.class)
    private EnumValorRegra estorno;

    @Column(name = "ST_SEM_SALDO")
    @Convert(converter = EnumValorRegraConverter.class)
    private EnumValorRegra semSaldo;

    @Column(name = "ST_SEM_SENHA")
    @Convert(converter = EnumValorRegraConverter.class)
    private EnumValorRegra semSenha;

    @Column(name = "TP_CONTA")
    @Convert(converter = EnumValorRegraTipoContaConverter.class)
    private EnumValorRegraTipoConta tipoConta;

    @Column(name = "CD_FORMA_PAGAMENTO")
    @Convert(converter = EnumFormaMovimentoConverter.class)
    private EnumFormaMovimentacao formaPagamento;

    @Column(name = "TP_PESSOA")
    @Convert(converter = EnumValorRegraTipoPessoaConverter.class)
    private EnumValorRegraTipoPessoa tipoPessoa;

    @Column(name = "VL_TRANSACAO")
    private BigDecimal valorTransacao;

    @OneToMany(mappedBy = "regra", fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<Pendencia> listaPendencias;

    @Setter
    @ManyToMany
    @JoinTable(name = "TB_REGRA_GRUPO_OPERADOR",
            joinColumns = @JoinColumn(name = "SQ_REGRA", referencedColumnName = "SQ_REGRA"),
            inverseJoinColumns = @JoinColumn(name = "GRPCOD", referencedColumnName = "GRPCOD"))
    private List<Grupo> gruposOperador;

    @Setter
    @ManyToMany
    @JoinTable(name = "TB_REGRA_GRUPO_AUT_PRI",
            joinColumns = @JoinColumn(name = "SQ_REGRA", referencedColumnName = "SQ_REGRA"),
            inverseJoinColumns = @JoinColumn(name = "GRPCOD", referencedColumnName = "GRPCOD"))
    private List<Grupo> gruposPrimeiroAutorizador;

    @Setter
    @ManyToMany
    @JoinTable(name = "TB_REGRA_GRUPO_AUT_SEC",
            joinColumns = @JoinColumn(name = "SQ_REGRA", referencedColumnName = "SQ_REGRA"),
            inverseJoinColumns = @JoinColumn(name = "GRPCOD", referencedColumnName = "GRPCOD"))
    private List<Grupo> gruposSegundoAutorizador;

    @Setter
    @ManyToMany
    @JoinTable(name = "TB_REGRA_GRUPO_AUT_ALT",
            joinColumns = @JoinColumn(name = "SQ_REGRA", referencedColumnName = "SQ_REGRA"),
            inverseJoinColumns = @JoinColumn(name = "GRPCOD", referencedColumnName = "GRPCOD"))
    private List<Grupo> gruposAutorizadorAlternativo;

    public Regra() {
        super();
    }

    public Regra(RegraDTO regraDTO) {
        nome = regraDTO.getNome();
        codigo = regraDTO.getCodigo();
        prioridade = regraDTO.getPrioridade();
        codigoFuncionalidade = regraDTO.getCodigoFuncionalidade();
        contaOperador = regraDTO.getContaOperador();
        contaOutroPA = regraDTO.getContaOutroPA();
        estorno = regraDTO.getEstorno();
        semSaldo = regraDTO.getSemSaldo();
        semSenha = regraDTO.getSemSenha();
        tipoConta = regraDTO.getTipoConta();
        formaPagamento = regraDTO.getFormaPagamento();
        tipoPessoa = regraDTO.getTipoPessoa();
        valorTransacao = regraDTO.getValorTransacao();
        carregaGruposOperador(regraDTO);
        carregaGruposPrimeiroAutorizador(regraDTO);
        carregaGruposSegundoAutorizador(regraDTO);
        carregaGruposAutorizadorAlternativo(regraDTO);
    }

    private void carregaGruposOperador(RegraDTO regraDTO) {
        gruposOperador = new ArrayList<Grupo>();

        for (GrupoDTO grupoDTO : regraDTO.getGruposOperador()) {
            gruposOperador.add(new Grupo(grupoDTO));
        }
    }

    private void carregaGruposPrimeiroAutorizador(RegraDTO regraDTO) {
        gruposPrimeiroAutorizador = new ArrayList<Grupo>();

        for (GrupoDTO grupoDTO : regraDTO.getGruposPrimeiroAutorizador()) {
            gruposPrimeiroAutorizador.add(new Grupo(grupoDTO));
        }
    }

    private void carregaGruposSegundoAutorizador(RegraDTO regraDTO) {
        gruposSegundoAutorizador = new ArrayList<Grupo>();

        for (GrupoDTO grupoDTO : regraDTO.getGruposSegundoAutorizador()) {
            gruposSegundoAutorizador.add(new Grupo(grupoDTO));
        }
    }

    private void carregaGruposAutorizadorAlternativo(RegraDTO regraDTO) {
        gruposAutorizadorAlternativo = new ArrayList<Grupo>();

        for (GrupoDTO grupoDTO : regraDTO.getGruposAutorizadorAlternativo()) {
            gruposAutorizadorAlternativo.add(new Grupo(grupoDTO));
        }
    }
}

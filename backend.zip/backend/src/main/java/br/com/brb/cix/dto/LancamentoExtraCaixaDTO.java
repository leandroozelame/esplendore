package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LancamentoExtraCaixaDTO {
    private Long tctcod;
    private Long agencia;
    private Long conta;
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade tipoModalidade;
    @LogValorTransacao
    private BigDecimal valor;
    private Integer numeroDocumento;
    private Date dataValorizacao;
    private Long nsuEstornada;
}
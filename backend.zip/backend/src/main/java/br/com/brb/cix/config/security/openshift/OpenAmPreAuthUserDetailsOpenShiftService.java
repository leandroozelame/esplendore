package br.com.brb.cix.config.security.openshift;

import br.com.brb.cix.config.security.CixUserDetailsService;
import br.com.brb.cix.security.CixUser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.userdetails.AuthenticationUserDetailsService;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Profile({"openShift", "weblogic"})
public class OpenAmPreAuthUserDetailsOpenShiftService extends CixUserDetailsService implements AuthenticationUserDetailsService<PreAuthenticatedAuthenticationToken> {
	@Override
	public CixUser loadUserDetails(PreAuthenticatedAuthenticationToken preAuthToken) {
		String matriculaOperador = preAuthToken.getName();
        return criaCixUser(matriculaOperador);
	}
}
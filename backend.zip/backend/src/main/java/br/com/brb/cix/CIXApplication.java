package br.com.brb.cix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

@SpringBootApplication
public class CIXApplication extends SpringBootServletInitializer {
    private static final String PROFILE_WEBLOGIC = "weblogic";
    private static final String PROFILE_DEFAULT = "default";

    public static void main(String... args) {	
    	System.setProperty("java.net.preferIPv4Stack" , "true");
        SpringApplication.run(CIXApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        application.profiles(PROFILE_DEFAULT, PROFILE_WEBLOGIC);
        return application.sources(CIXApplication.class);
    }  
}
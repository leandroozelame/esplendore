package br.com.brb.cix.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UrlDTO {
    String url;
    String nomeRelatorio;
}
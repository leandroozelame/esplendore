package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SaqueBeneficioInssFormularioDTO {
    
    private Long nrAgencia;
    private Long nrBeneficio;
    private String indicadorTransacaoSemCartao;
    private String procurador;
    private String documentoProcurador;
    private String beneficiario;
    private Date dataHoraAutorizacao;
    private String docIdentificacao;
    private Date dataEmissao;
    private String telefone;
    private BigDecimal valorTransacao;
    private EnumFormaMovimentacao formaMovimentacao;
    
}


package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsultaContasSobJudiceDTO {
	private Long cpfCnpj;
	private Integer agencia;
	private Long conta;
}
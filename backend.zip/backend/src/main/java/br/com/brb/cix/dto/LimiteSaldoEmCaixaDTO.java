package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.domain.model.limitesaldocaixa.LimiteSaldoEmCaixa;
import br.com.brb.cix.domain.model.limitesaldocaixa.LimiteSaldoEmCaixaRepository;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;


@Data
@Getter
@EqualsAndHashCode(callSuper = false)
public class LimiteSaldoEmCaixaDTO extends AbstractDTO {

    private Long codigo;
    private Integer codigoModulo;
    private Long codigoUnidade;
    private BigDecimal valorLimiteSaldoCheque;
    private BigDecimal valorLimiteSaldoDinheiro;
   
    
    public LimiteSaldoEmCaixaDTO(LimiteSaldoEmCaixa limiteSaldoEmCaixa) {
        this.codigo = limiteSaldoEmCaixa.getCodigo();
        this.codigoModulo = limiteSaldoEmCaixa.getCodigoModulo();
        this.codigoUnidade = limiteSaldoEmCaixa.getCodigoUnidade();
        this.valorLimiteSaldoCheque = limiteSaldoEmCaixa.getValorLimiteSaldoCheque();
        this.valorLimiteSaldoDinheiro = limiteSaldoEmCaixa.getValorLimiteSaldoDinheiro();
    }
   
    public LimiteSaldoEmCaixaDTO() {
    }
    
    public LimiteSaldoEmCaixa atualizar(Long codigo, LimiteSaldoEmCaixaRepository limiteEmCaixaRepository) {
        LimiteSaldoEmCaixa limite = limiteEmCaixaRepository.getOne(codigo);
        limite.setCodigoModulo(this.getCodigoModulo());
        limite.setCodigoUnidade(this.getCodigoUnidade());
        limite.setValorLimiteSaldoCheque(this.valorLimiteSaldoCheque);
        limite.setValorLimiteSaldoDinheiro(this.valorLimiteSaldoDinheiro);
        return limite;
    }
//
//    public LimiteSaldoEmCaixa converter(LimiteSaldoEmCaixaRepository limiteEmCaixaRepository) {
//        LimiteSaldoEmCaixa convertido = limiteEmCaixaRepository.getOne(codigo);
//        return new LimiteSaldoEmCaixa(codigo, codigoModulo, codigoUnidade, valorLimiteSaldoCheque, valorLimiteSaldoDinheiro);
//    }
    
}

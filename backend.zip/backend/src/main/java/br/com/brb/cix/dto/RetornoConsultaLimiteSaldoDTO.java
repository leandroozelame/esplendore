package br.com.brb.cix.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class RetornoConsultaLimiteSaldoDTO implements Serializable {

    private static final long serialVersionUID = -2002943864098014322L;

    @Builder.Default
    private Integer codigoErro = 0;
    @Builder.Default
    private String mensagem = "";
    @Builder.Default
    private Integer severidade = 0;
    private Object resultado;
    
    
    public RetornoConsultaLimiteSaldoDTO(Object resultado) {
        this.resultado = resultado;
    }
    
    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    
}

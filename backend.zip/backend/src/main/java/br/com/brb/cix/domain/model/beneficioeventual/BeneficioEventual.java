package br.com.brb.cix.domain.model.beneficioeventual;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Entity
@Table(name = "TB_BENEFICIO_EVENTUAL")
@AllArgsConstructor()
@NoArgsConstructor()
public class BeneficioEventual  {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "beneficio_eventual_sequence", sequenceName = "SQ_BENEFICIO_EVENTUAL", allocationSize = 1)
	@GeneratedValue(generator = "beneficio_eventual_sequence")
	@Column(name = "SQ_BENEFICIO_EVENTUAL", nullable = false)
	private Long codigo;
	
	@Column(name = "CD_MODULO", nullable = false)
	private Integer codigoModulo;
	
	@Column(name = "DS_PROGRAMA")
	private String programa;
	
	@Column(name = "NO_PROGRAMA")
	private String codigoPrograma;
	
	@Column(name = "ST_BENEFICIO")
	private int situacao;
	
	@Column(name = "DT_CRIACAO")
	private Date dataCriacao;
	
	@Column(name = "DT_ULTIMA_ALTERACAO")
	private Date dataUltimaAlteracao;
	
	@Column(name = "NR_MATRICULA")
	private Long matricula;
}

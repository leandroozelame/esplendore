package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ParametroPldDTO {
    
    private Long codigo;
    private Integer modulo;
    private Long codigoFuncionalidade;
    private Long codigoFormaPagamento;
    private String funcionalidade;
    private String formaPagamento;
    private BigDecimal valor;
    private Boolean habilitado;
    private List<Long> camposPld;
    
}
package br.com.brb.cix.domain.model.enums;

public interface EnumDominio {
	<T> T getCodigo();
}

package br.com.brb.cix.dto;


import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import java.util.Date;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ConsultaHistoricoSenhaDTO extends AbstractDTO {
    private Long conta;
    private EnumTipoConta tipoConta;
    private Integer ordem;
    private Date dataInicio;
    private Date dataFim;
}
package br.com.brb.cix.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.brb.cix.config.jackson.DateOnlySerializer;
import br.com.brb.cix.config.anotacao.LabelAuditoriaAlcada;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlteracaoSenhaContaCaixaDTO extends ContaTipoDTO {
    private String nomeTitular;
    private Integer ordemConta;
    @LabelAuditoriaAlcada(value = "CPF")
    private String cpf;
    private String nomeProcurador;
    private String numeroDocumento;
    @JsonSerialize(using = DateOnlySerializer.class)
    private Date dataDocumento;
    private String telefone;
    private String numeroCartao;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Integer tipoCartao;
    @JsonProperty(access = Access.WRITE_ONLY)
    private String senhaAtual;
    @JsonProperty(access = Access.WRITE_ONLY)
    private String senhaNova;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Boolean indicadorAlteraSenhaBase;
}

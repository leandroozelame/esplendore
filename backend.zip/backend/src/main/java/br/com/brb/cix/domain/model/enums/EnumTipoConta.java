package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoConta implements EnumDominio{
    VAZIO(-1,"n/a", "", Boolean.FALSE),
    CORRENTE(0, "Conta Corrente", "CC", Boolean.TRUE), 
    POUPANCA(1, "Conta Poupança", "CP", Boolean.TRUE), 
    FUNDOS(2, "Fundos", "CF", Boolean.FALSE), 
    SALARIO(3, "Conta Salário", "CS", Boolean.TRUE), 
    BENEFICIO(4, "Conta Benefício", "CB", Boolean.FALSE), 
    MENRPR(5, "Menor Representado", "MR", Boolean.FALSE), 
    PAGAMENTO(6, "Conta Pagamento", "PG", Boolean.FALSE), 
    POUPANCA_SALARIO(7, "Poupança Salário", "PS", Boolean.TRUE),
    FUNDO_BRB_ACOES_500(902, "FIC FIA BRB ACOES 500", "FUN", Boolean.FALSE),
    FUNDO_BRB_FIRF_(913, "BRB FIC FIRF DI LP 25 MIL", "FUN", Boolean.FALSE),
    FUNDO_FIC_FI_MULTIM(916, "BRB FIC FI MULTIM LP 500 ", "FUN", Boolean.FALSE),
    FUNDO_FI_RF_BRB_LIQUIDEZ(918, "FI RF BRB LIQUIDEZ", "FUN", Boolean.FALSE),
    FUNDO_BRB_FIC_FI_RF_GOVERNO(927, "BRB FIC FI RF GOVERNO", "FUN", Boolean.FALSE),
    FUNDO_BRB_FIC_FI_RF_DI_LP_500(928, "BRB FIC FI RF DI LP 500", "FUN", Boolean.FALSE),
    FUNDO_FI_RF_BRB_MAIS(931,"FI RF BRB MAIS", "FUN", Boolean.FALSE),
    FUNDO_BRB_FIC_FIRF_PUB_LP_(933,"BRB FIC FIRF PUB LP 5MIL", "FUN", Boolean.FALSE),
    FUNDO_FIA_BRB_PETROVALE(934,"FIA BRB PETROVALE", "FUN", Boolean.FALSE),
    FUNDO_BRB_FICFIRF_PUB_LP(935,"BRB FICFIRF PUB LP 300MIL", "FUN", Boolean.FALSE),
    FUNDO_BRB_RF_PUBLICO_LP(940,"BRB FIC FI RF PUBLICO LP", "FUN", Boolean.FALSE),
    FUNDO_BRB_LP_IMA(944,"BRB FIC FI RF LP IMA B", "FUN", Boolean.FALSE),
    FUNDO_BRB_PREMIUM_FI_MULTIM(956,"BRB PREMIUM FI MULTIM LP", "FUN", Boolean.FALSE),
    FUNDO_FICFI_RF_DI_LP_1_MILHAO(961,"FICFI RF DI LP 1 MILHAO", "FUN", Boolean.FALSE),
    FUNDO_BRB_FIRF_DI_100_MIL(965,"BRB FIC FIRF DI 100 MIL L", "FUN", Boolean.FALSE);

    private static final Map<Integer, EnumTipoConta> MAP = new HashMap<>();
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;
    @Getter
    private String sigla;
    @Getter
    private Boolean doc;
    static List<EnumTipoConta> listaEnum = Arrays.asList(EnumTipoConta.values());


    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

    public static EnumTipoConta get(int codigo) {
        return MAP.get(codigo);
    }
    
    /**
     * @return
     */
    public static List<Object> listarEnumTipoContaDOC() {
        return listaEnum.stream().filter(r -> r.getDoc()) .map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());

    }
    
    @JsonCreator
    public static EnumTipoConta criaEnum(Object tipo) {
        EnumTipoConta retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumTipoConta criaEnumString(String descricao) {
        EnumTipoConta retorno = null;
        Iterator<Map.Entry<Integer, EnumTipoConta>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumTipoConta> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
}
package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TerminalFechadoSuprirDTO {
    
    private String terminal;
    private Boolean terminalFechado;
}
package br.com.brb.cix.dto;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AtendimentoDTO extends AbstractDTO {
    private String nomeCliente;
    private String cpfCliente;
    private Long telefoneCliente;
}
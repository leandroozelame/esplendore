package br.com.brb.cix.domain.model.parametrotransacaoestorno;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ParametroTransacaoEstornoRepository extends JpaRepository<ParametroTransacaoEstorno, Long> {

    ParametroTransacaoEstorno findByCodigo(Long codigo); 
    
    boolean existsByCodigo (Long codigo);

    @Query(value = "SELECT * FROM {h-schema}TB_PARAMETRIZAR_ESTORNO WHERE (:codigoModulo = -1 OR CD_MODULO = :codigoModulo) AND (:codigoFuncionalidade = -1 OR SQ_FUNCIONALIDADE = :codigoFuncionalidade)" +
            " AND (:codigoFormaPagamento = -1 OR CD_FORMA_PAGAMENTO = :codigoFormaPagamento) ORDER BY CD_MODULO, SQ_FUNCIONALIDADE, CD_FORMA_PAGAMENTO, HR_LIMITE_ESTORNO", nativeQuery = true)
    List<ParametroTransacaoEstorno> findByModuloAndFuncionalidadeAndFormaPagamento(@Param("codigoModulo") Integer codigoModulo, @Param("codigoFuncionalidade") Long codigoFuncionalidade, @Param("codigoFormaPagamento") Long codigoFormaPagamento);

}

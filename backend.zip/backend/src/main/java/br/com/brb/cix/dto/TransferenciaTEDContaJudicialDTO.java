package br.com.brb.cix.dto;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.enums.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class TransferenciaTEDContaJudicialDTO extends AbstractDTO {
    
    private EnumFormaMovimentacao formaMovimentacao;
    private EnumTipoTransacaoTed tipoTransacao;
    private String nomeBeneficiario;
    private String tipoPessoa;
    private Long cnpjTribunal;
    private String nomeTribunal;
    private Long cpfCnpjBeneficiario;
    private Integer alvara;
    private BigDecimal saldo;
    private String numeroIF;
    private String tipoTed;
    private EnumTipoConta tipoContaDestino;
    private Integer agenciaDestino;
    private Long numeroContaDestino;
    private Long cpfCnpjFavorecido;
    private String nomeFavorecido;
    private EnumFinalidadeTED finalidade;
    private String identificadorTransferencia;
    private String historico;
    private String numeroProcesso;
    private String tipoPessoaFavorecido;
    private Integer bancoDestCod;
    private String bancoDestNome;
    private Integer codTipoContaDestino;
    private String origemDestinoRecurso;
    private String IdentificacaoDeposito;

}
package br.com.brb.cix.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlteraSenhaContaDTO extends ContaTipoDTO {
    private Integer dddCelular;
    private Integer numeroCelular;
    private String email;
}
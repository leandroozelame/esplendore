package br.com.brb.cix.dto;

import br.com.brb.cix.ws.autorizacao.dto.LimitesFinanceirosDTO;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
public class LimitesFinanceirosAgrupadosDTO {

    public String canal;
    public BigDecimal totalValorLimite;
    public BigDecimal totalValorUtilizado;
    public BigDecimal totalValorSaldo;
    List<LimitesFinanceirosDTO> limitesFinanceiros;
}
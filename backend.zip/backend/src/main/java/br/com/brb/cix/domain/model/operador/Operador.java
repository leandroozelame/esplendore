package br.com.brb.cix.domain.model.operador;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;

@Entity
@Getter
@Table(name = "VW_OPR")
public class Operador  {
    private static final long serialVersionUID = -7884383952009631320L;

    @Id
    @Column(name = "OPRMAT")
    private String matricula;

    @Column(name = "OPRNOM")
    private String nome;
    
    @Column(name = "OPRCPF")
    private String cpf;

    @Column(name = "UNDCOD")
    private Long codigoUnidade;
    
    @Column(name = "UNDDSC")
    private String descricaoUnidade;

    @Column(name = "GRPCOD")
    private Long codigoGrupo;
    
    @Column(name = "GRPDSC")
    private String descricaoGrupo;
    
    @Column(name = "SQ_EQUIPE")
    private Long codigoEquipe;
    
    @Column(name = "NO_NOME")
    private String nomeEquipe;

}

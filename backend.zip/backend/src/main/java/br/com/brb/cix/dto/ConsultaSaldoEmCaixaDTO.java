package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.*;

@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class ConsultaSaldoEmCaixaDTO {
    private Long codigo;
    private Integer codigoModulo;
    private String descricaoModulo;
    private Long codigoUnidade;
    private String descricaoUnidade;
    private BigDecimal valorLimiteSaldoCheque;
    private BigDecimal valorLimiteSaldoDinheiro;

    /**
     * @param codigoModulo
     * @param codigoUnidade
     */
    public ConsultaSaldoEmCaixaDTO(Integer codigoModulo, Long codigoUnidade) {
        super();
        this.codigoModulo = codigoModulo;
        this.codigoUnidade = codigoUnidade;
    }
}
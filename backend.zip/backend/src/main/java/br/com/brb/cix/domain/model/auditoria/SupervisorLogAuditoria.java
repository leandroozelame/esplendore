package br.com.brb.cix.domain.model.auditoria;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_LOG_AUDITORIA_SUPERVISOR")
public class SupervisorLogAuditoria {
    @Id
    @GeneratedValue(generator = "auditoria_supervisor_sequence")
    @SequenceGenerator(name = "auditoria_supervisor_sequence", sequenceName = "SQ_LOG_AUDITORIA_SUPERVISOR",
            allocationSize = 1)
    @Column(name = "SQ_LOG_AUDITORIA_SUPERVISOR")
    private Long codigoSupervisor;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_LOG_AUDITORIA", nullable = false)
    private Auditoria auditoria;

    @Column(name = "DS_MATRICULA_SUPERVISOR")
    private String matricula;

    @Column(name = "NR_ORDEM_SUPERVISAO")
    private Integer ordem; // Ordem = 0 é autorizador alternativo

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;

        result = prime * result + ((codigoSupervisor == null) ? 0 : codigoSupervisor.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        SupervisorLogAuditoria other = (SupervisorLogAuditoria) obj;
        if (codigoSupervisor == null) {
            if (other.codigoSupervisor != null)
                return false;
        } else if (!codigoSupervisor.equals(other.codigoSupervisor))
            return false;
        return true;
    }
}
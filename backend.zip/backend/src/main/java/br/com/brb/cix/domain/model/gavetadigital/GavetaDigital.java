package br.com.brb.cix.domain.model.gavetadigital;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.com.brb.cix.domain.model.terminal.Terminal;
import br.com.brb.cix.enums.EnumTipoTransacaoGaveta;
import br.com.brb.cix.util.ConvertCharToBoolean;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TB_GAVETA_DIGITAL")
public class GavetaDigital  {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "gaveta_digital_sequence", sequenceName = "SQ_GAVETA_DIGITAL", allocationSize = 1)
    @GeneratedValue(generator = "gaveta_digital_sequence")
    @Column(name = "SQ_GAVETA_DIGITAL")
    private Long id;

    @Column(name = "DT_OPERACAO")
    private Date dataOperacao;

    @ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_ATIVA")
    private Boolean statusAtiva;

    @OneToMany(mappedBy = "gavetaDigital", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JsonManagedReference
    List<GavetaNumerario> listaNumerarios;

    @Transient
    private EnumTipoTransacaoGaveta tipoTransacao;

    // ===================================
    public final static String OBRIGATORIA = "0";
    public final static String OPCIONAL = "1";
    public final static String DESATIVADA = "2";
    public final static String CANAL_AGENCIA_PARAM = "GAVETA_OBRIGAT_AGENCIA";
    public final static String CANAL_CORRESP_PARAM = "GAVETA_OBRIGAT_CORRESP";

    /**
     * @param dataOperacao
     * @param terminal
     */
    public GavetaDigital(Date dataOperacao, Terminal terminal, Boolean statusAtiva) {
        super();
        this.dataOperacao = dataOperacao;
        this.terminal = terminal;
        this.statusAtiva = statusAtiva;
    }
}

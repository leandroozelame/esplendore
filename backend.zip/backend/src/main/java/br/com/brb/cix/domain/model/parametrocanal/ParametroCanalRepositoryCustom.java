package br.com.brb.cix.domain.model.parametrocanal;

import java.util.List;

import br.com.brb.cix.dto.ParametroCanalDTO;

public interface ParametroCanalRepositoryCustom {
    List<ParametroCanalDTO> buscaSecoes();
}
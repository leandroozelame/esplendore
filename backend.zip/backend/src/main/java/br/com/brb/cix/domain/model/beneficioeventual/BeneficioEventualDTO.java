package br.com.brb.cix.domain.model.beneficioeventual;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class BeneficioEventualDTO {

	private Long codigo;
    private Integer codigoModulo;
    private String programa;
    private String codigoPrograma;
    private int situacao;
    private Long matricula;
    private Date dataCriacao;
    private Date dataUltimaAlteracao;

    /**
     * @param codigo
     */
   
    public BeneficioEventualDTO() {
    	
    }
    
    public BeneficioEventualDTO(Long codigo) {
        super();
        this.codigo = codigo;
    }
    
	public BeneficioEventualDTO (BeneficioEventual beneficioEventual) {
		super();
		this.codigo = beneficioEventual.getCodigo();
		this.codigoModulo = beneficioEventual.getCodigoModulo();
		this.programa = beneficioEventual.getPrograma();
		this.codigoPrograma = beneficioEventual.getCodigoPrograma();
		this.situacao = beneficioEventual.getSituacao();
		this.dataCriacao = beneficioEventual.getDataCriacao();
		this.matricula = beneficioEventual.getMatricula();
		this.dataUltimaAlteracao = beneficioEventual.getDataUltimaAlteracao();
	}
    
}

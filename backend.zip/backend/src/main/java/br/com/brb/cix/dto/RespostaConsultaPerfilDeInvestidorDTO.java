package br.com.brb.cix.dto;

import br.com.brb.cix.enums.EnumEnquadramento;
import br.com.brb.cix.enums.EnumQuestionario;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaConsultaPerfilDeInvestidorDTO extends AbstractDTO {
    private EnumQuestionario statusQuestionario = EnumQuestionario.SEM_PERFIL;
    private String perfilCliente;
    private String perfilProduto;
    private EnumEnquadramento enquadramento = EnumEnquadramento.NAO;
    private String termoRecusa;
    private String termoCiencia;
    private String dispensa;
    private Date dataDispensa;
}
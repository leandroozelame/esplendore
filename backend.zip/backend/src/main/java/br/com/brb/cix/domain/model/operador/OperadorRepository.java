package br.com.brb.cix.domain.model.operador;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OperadorRepository extends JpaRepository<Operador, Long> {
    Operador findByMatriculaIgnoreCase(String matricula);
}

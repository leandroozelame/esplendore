package br.com.brb.cix.domain.model.reternumerario;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TB_NUMERARIO_RETIDO")
public class ReterNumerario {
	@Id
	@SequenceGenerator(name = "numerario_retido_sequence", sequenceName = "SQ_NUMERARIO_RETIDO", allocationSize = 1)
    @GeneratedValue(generator = "numerario_retido_sequence")
    @Column(name = "SQ_NUMERARIO_RETIDO")
    private Long codigo;
	
    @Column(name = "CD_UNIDADE", nullable = true)
    private Long codigoUnidade;
	
	@Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;
	
	@Column(name = "VL_RETIDO")
    private BigDecimal valorRetido;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "DT_RETENCAO")
	private Date dataRetencao;
	
    @Column(name = "ST_ATIVO")
    private Boolean ativo;
}
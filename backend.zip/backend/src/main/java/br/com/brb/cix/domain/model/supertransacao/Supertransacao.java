package br.com.brb.cix.domain.model.supertransacao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import br.com.brb.cix.domain.model.terminal.Terminal;
import br.com.brb.cix.domain.model.transacaoSupertransacao.TransacaoSupertransacao;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_SUPERTRANSACAO_EXECUCAO")
public class Supertransacao  {
	
	private static final long serialVersionUID = 623334414738169809L;

	@Id
	@SequenceGenerator(name = "sequence_supertransacao_execucao", sequenceName = "SQ_SUPERTRANSACAO_EXECUCAO", allocationSize = 1)
	@GeneratedValue(generator = "sequence_supertransacao_execucao")
	@Column(name = "SQ_SUPERTRANSACAO_EXECUCAO")
	private Long id;

	@ManyToOne
	@JoinColumn(name = "SQ_SUPERTRANSACAO")
	private ParametroSupertransacao parametrizacao;
	
	@ManyToOne
	@JoinColumn(name = "SQ_TERMINAL")
	private Terminal terminal;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "CD_SITUACAO_SUPERTRANSACAO")
	private SituacaoSupertransacao situacaoExecucao;
	
	@Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;
	
	@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_INICIO_EXECUCAO")
    private Date dataInicioExecucao;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_FIM_EXECUCAO")
    private Date dataFimExecucao;
    
    @Column(name = "DT_ATUALIZACAO")
    private Date dataAtualizacao;
    
    @Column(name = "VL_TOTAL")
    private BigDecimal subtotal;
    
    @Column(name = "VL_FICHA_CONTABIL")
    private BigDecimal valorFichaContabil;
    
    @Lob
    @Column(name = "TX_CABECALHO")
    private String cabecalhoFormaMovimentacao;
    
    @Column(name = "NR_NSU")
    private Long nsu;
    
    @OneToMany(mappedBy = "supertransacao", orphanRemoval = true, cascade = CascadeType.PERSIST)
    private List<TransacaoSupertransacao> transacoes = new ArrayList<TransacaoSupertransacao>();
    
    @Transient
    private Integer status;
    
    public void adicionarTransacao(TransacaoSupertransacao transacao) {
    	this.transacoes.add(transacao);
    	transacao.setSupertransacao(this);
    }
    
    public void removerTransacao(TransacaoSupertransacao transacao) {
    	this.transacoes.remove(transacao);
    }
    
    public void setSituacaoExecucao(SituacaoSupertransacao situacaoSupertransacao) {
    	this.situacaoExecucao = situacaoSupertransacao;
    	this.status = situacaoSupertransacao.getCodigo();
    }
    
    public Integer getStatus() {
    	return situacaoExecucao.getCodigo();
    }
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TransacaoDTO {

	private Long id;
	private Long numero;
	private String descricao;
	private Integer tipoTransacao;
	private Integer status;
	private BigDecimal valor;
	private BigDecimal valorTarifa;
	private String dados;
	private Long nsu;
	private String mensagem;
	private String codigoBarras;
	private String comprovante;
	private String numeroProtocoloFRM;
	private List<Integer> camposPld = new ArrayList<Integer>();
	private String origemDestinoRecurso;
}

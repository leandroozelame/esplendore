package br.com.brb.cix.dto;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParametroTransacaoEspecieDTO {
    
    private Long codigo;
    private Integer modulo;
    private Long codigoFuncionalidade;
    private String destinoOrigem;
    private BigDecimal valor;
    private Boolean habilitado;
    
}
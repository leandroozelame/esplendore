package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.tiponumerario.TipoNumerario;
import lombok.*;

@Setter
@Getter
public class EstornoListaInsertEntradaDTO {
   private String quantidadeNumerario;
   private String valorNumerario;
   private TipoNumerario tipoNumerario;



}
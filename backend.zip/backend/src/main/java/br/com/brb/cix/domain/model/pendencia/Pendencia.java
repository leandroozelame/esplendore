package br.com.brb.cix.domain.model.pendencia;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.enums.EnumSituacaoPendencia;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_PENDENCIA_AUTORIZACAO")
public class Pendencia  {
    private static final long serialVersionUID = -7884383952009731340L;
    @Id
    @SequenceGenerator(name = "pendencia_autorizacao_sequence", sequenceName = "SQ_PENDENCIA_AUTORIZACAO",
            allocationSize = 1)
    @GeneratedValue(generator = "pendencia_autorizacao_sequence")
    @Column(name = "SQ_PENDENCIA_AUTORIZACAO")
    private Long codigo;

    @Column(name = "NR_NSU_CIX")
    private Long nsuCix;

    @Column(name = "NR_NSU_BLK")
    private Long nsuBlk;

    @Column(name = "NR_NSU_CIX_ESTORNADO")
    private Long nsuCixEstornado;

    @Column(name = "ST_PENDENCIA_AUTORIZACAO")
    private Character situacao = '0';

    @Column(name = "NR_RECIBO_BLK")
    private Long numeroRecibo;

    @Column(name = "DT_CADASTRO_PENDENCIA")
    private Date dataCadastro;

    @Column(name = "DT_ULTIMA_ATUALIZACAO")
    private Date dataAtualizacao;

    @Column(name = "VL_TRANSACAO_PENDENTE")
    private BigDecimal valor;

    @Column(name = "DS_TRANSACAO")
    private String descricao;

    @Column(name = "NR_CONTA_ORIGEM")
    private Long contaOrigem;

    @Column(name = "NR_CONTA_DESTINO")
    private Long contaDestino;

    @Column(name = "NR_TERMINAL_TRANSACAO")
    private Integer terminal;

    @Column(name = "OPRMAT")
    private String matricula;

    @Column(name = "NR_MATRICULA_ULT_AUTORIZADOR")
    private Integer matriculaUltimoAutorizador = 0;

    @Column(name = "UNDCOD")
    private Integer unidade;

    @Column(name = "DS_DETALHAMENTO_TRANSACAO")
    @JsonIgnore
    private String detalhamento;

    @Column(name = "DS_MOTIVO_REJEICAO")
    private String motivoRejeicao;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_REGRA", nullable = false)
    @JsonBackReference
    private Regra regra;

    public Pendencia() {
        super();
        dataCadastro = new Date();
    }

    public String getMensagem() {
    	EnumSituacaoPendencia situacao = EnumSituacaoPendencia.get(Integer.parseInt(String.valueOf(getSituacao())));
    	
    	if (situacao != null) {
    		switch (situacao) {
	            case AUTORIZADA:
	                return ""; // Aprovada
	            case PENDENTE_1_AUTORIZACAO:
	                return "Pendente de uma autorização.";
	            case PENDENTE_2_AUTORIZACAO:
	                return "Pendente de duas autorizações.";
	            case REJEITADA: // Rejeitada
	                return "Transação rejeitada\nmatrícula: " + getMatriculaUltimoAutorizador() + "\nmotivo: "
	                        + getMotivoRejeicao();
	            case CANCELADA: // Cancelada
	                return "Transação cancelada pelo operador.";
	            default:
	                return "";
    		}
        } else {
        	return "";
        }
    }
    
    public boolean autorizada() {
    	return getMensagem().equals("");
    }
}

package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.modulo.Modulo;
import lombok.*;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ParametroCadastroARUDTO {
    private Integer numeroContrato;
    private Long modulo;
    private Integer formaPagamento;;
    private Boolean ativo;
}
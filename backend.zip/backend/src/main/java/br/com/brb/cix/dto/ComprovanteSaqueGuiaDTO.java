package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoOperacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.enums.EnumTipoTransacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComprovanteSaqueGuiaDTO {

    private Long agencia;
    private Long conta;
    private EnumTipoConta tipoConta;
    private Integer ptaOrigem;
    private EnumTipoTransacao tipoTransacao;
    private Long numeroCpfCnpjTitular;
    private Integer ordemTitularConta;
    private String numeroDocumento;
    private Date dataDocumento;
    private String telefoneNumero;
    private EnumTipoOperacao tipoOperacao;
    private Integer brbTctCod;
    private BigDecimal valorTransacao;
    private EnumFormaMovimentacao formaMovimentacao;
}

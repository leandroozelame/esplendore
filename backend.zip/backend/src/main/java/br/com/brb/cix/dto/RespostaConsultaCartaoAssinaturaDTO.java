package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.ws.consulta.dto.RespostaConsultaCartaoAssinatura;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaConsultaCartaoAssinaturaDTO {
    
   private List<RespostaConsultaCartaoAssinatura> consultaCartaoAssinatura;
}

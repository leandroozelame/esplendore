package br.com.brb.cix.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AjudaDTO extends AbstractDTO {
    private String ajuda;
}
package br.com.brb.cix.auditoria.anotacao;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import br.com.brb.cix.enums.EnumCanal;
import br.com.brb.cix.enums.EnumFuncionalidade;

/**
 * Esta anotação deverá ser colocada nos métodos dos serviços que realizam
 * auditoria.
 * 
 * Funciona apenas em métodos, não privados, que possuam retorno.
 *
 * @author Núcleo de Canais
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogAuditoria {

	/**
	 * @return {@link String} Funcionalidade
	 */
	EnumFuncionalidade value();

	/**
	 * @return {@link String} Canal selecionado
	 */
	EnumCanal canal() default EnumCanal.NENHUM;

	/**
	 * @return {@link String} Ignora parametros de entrada do metodo
	 */
	boolean ignoraSaida() default false;

	/**
	 * @return {@link String} Ignora retorno do metodo
	 */
	boolean ignoraEntrada() default false;

}

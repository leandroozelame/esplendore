package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.List;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OrdemBancariaDTO extends AbstractDTO {
    private Long conta;
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade modalidade;
    private String identificadorOB;
    private String referencia;
    private BigDecimal valor;
    private Integer transacao;
    private Integer transacaoCC;
    private Integer transacaoCP;
    private Integer transacaoCV;
    private Integer transacaoCS;
    private List<OrdemBancariaCreditoDTO> creditos;
}
package br.com.brb.cix.dto;

import lombok.Data;

@Data
public class ContatoDTO {
    private Integer codigoTipo;
    private String tipo;
    private Integer ddd;
    private Integer numero;
}
package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum EnumTipoSenha implements EnumDominio {
    ALTERAR_SENHA_CONTA_CORRENTE_SALARIO(422,"Cadastramento de Senha C/C ou C/S"),
    ALTERAR_SENHA_CONTA_POUPANCA(423,"Cadastramento de Senha C/P"), 
    ALTERAR_SENHA_BENEFICIO_BFE(415,"Cadastramento de Senha Benefícios - BFE"), 
    ALTERAR_SENHA_INSS(412,"Cadastramento de Senha INSS"), 
    LIBERACAO_IDENTIFICACAO_POSITIVA(425,"Liberação de Identificação Positiva para o Auto Atendimento");
    
    
    private Integer codigo;
    private String descricao;

    static List<EnumTipoSenha> listaEnum = Arrays.asList(EnumTipoSenha.values());
    private static final Map<Integer, EnumTipoSenha> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

 
    @JsonCreator
    public static EnumTipoSenha get(int codigo) {
        return MAP.get(codigo);
    }


    public static List<Object> listarEnumTipoSenha() {
        return listaEnum.stream().map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return "0" + getCodigo() + " - " + getDescricao();
    }
}

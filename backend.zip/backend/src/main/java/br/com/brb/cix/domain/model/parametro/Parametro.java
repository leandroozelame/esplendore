package br.com.brb.cix.domain.model.parametro;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;


import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@SuppressWarnings("serial")
@Entity
@Immutable
@Getter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Table(name = "VW_PMT")
public class Parametro  {

	@Column(name = "PMTCOD")
	@Id
	private Long codigo;

	@Column(name = "PMTDES")
	private String descricao;

	@Column(name = "PMTTIP")
	private Integer tipo;

	@Column(name = "PMTVAL")
	private String valor;

	@Column(name = "PMTCAT")
	private Integer categoria;
}

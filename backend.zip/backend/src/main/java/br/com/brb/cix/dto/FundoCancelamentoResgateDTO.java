package br.com.brb.cix.dto;

import br.com.brb.cix.ws.consulta.dto.FundoCancelamentoResgate;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class FundoCancelamentoResgateDTO extends FundoCancelamentoResgate {
    private String descricaoCanal;
}
package br.com.brb.cix.dto.comum;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class RetornoErroDTO implements Serializable {
    private static final long serialVersionUID = 3325601943950782918L;
    private Integer codigoErro;
    private String mensagem;
    private Integer severidade;
    
    public RetornoErroDTO(Exception e) {
    	this.mensagem = e.getMessage();
    }
}
package br.com.brb.cix.domain.model.beneficioeventual.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.brb.cix.domain.model.beneficioeventual.BeneficioEventualRepositoryCustom;
import br.com.brb.cix.dto.ConsultaBeneficioEventualDTO;
import br.com.brb.cix.util.ObjectUtil;
import br.com.brb.cix.util.SqlUtil;
import lombok.Getter;

/**
 * @author u653865
 *
 */
@Repository
public class BeneficioEventualRepositoryImpl implements BeneficioEventualRepositoryCustom {
    @Getter
    private final EntityManager em;
    @Autowired
    public BeneficioEventualRepositoryImpl(EntityManager em) {
        this.em = em;
    }

	@Override
	public List<ConsultaBeneficioEventualDTO> consultarPorModulo(Integer codigoModulo) {
		Query query = em.createNativeQuery(retornarSQL());

		query.setParameter("modulo", codigoModulo);
		
		@SuppressWarnings("unchecked")
		List<Object[]> lista = query.getResultList();
		
		return ObjectUtil.isNull(lista) ? new ArrayList<ConsultaBeneficioEventualDTO>()
                : lista.stream().map(i -> new ConsultaBeneficioEventualDTO(SqlUtil.toLong(i[0]), SqlUtil.toInteger(i[1]),
                        SqlUtil.toString(i[2]), SqlUtil.toString(i[3]), SqlUtil.toString(i[4]), SqlUtil.toInteger(i[5]),
                        SqlUtil.toDate(i[6]).getTime(), SqlUtil.toLong(i[7]),  SqlUtil.toDate(i[8]).getTime())).collect(Collectors.toList());
	}
	
	private String retornarSQL() {
		StringBuilder sql = new StringBuilder();
		sql.append(" SELECT                              ");
		sql.append("    b.sq_beneficio_eventual,         ");
		sql.append("    b.cd_modulo,                     ");
		sql.append("    m.no_modulo,                     ");
		sql.append("    b.ds_programa,                   ");
		sql.append("    b.no_programa,                   ");
		sql.append("    b.st_beneficio,                  ");
		sql.append("    b.dt_criacao,                    ");
		sql.append("    b.nr_matricula,                  ");
		sql.append("    b.dt_ultima_alteracao            ");
		sql.append(" FROM CIX.TB_BENEFICIO_EVENTUAL b     ");
		sql.append(" INNER JOIN CIX.TB_MODULO m ON b.cd_modulo = m.CD_MODULO ");
		sql.append(" WHERE b.cd_modulo = :modulo                             ");
		return sql.toString();
	}
}
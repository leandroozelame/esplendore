package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class RespostaConsultaInformacoesTitularesTiposContasDTO extends AbstractDTO {
    private Integer codigoPerfilConta;
    private Integer codigoSenhaEncontrada;
    private String descricaoPerfilConta;
    private boolean indicadorContaMillenium;
    private boolean senhaEncontrada;
    private EnumTipoPessoa tipoPessoa;
    private Integer tipoTitularidade;
    private InformacoesClienteContaDTO informacoesClienteContaDTO;
}
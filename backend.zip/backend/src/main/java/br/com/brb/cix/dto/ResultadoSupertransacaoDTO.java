package br.com.brb.cix.dto;

import br.com.brb.cix.ws.dto.saida.SaidaSupertransacaoDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultadoSupertransacaoDTO {
    private SaidaSupertransacaoDTO autorizacaoBlk;
    private SupertransacaoDTO supertransacao;
}
package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.enums.EnumFinalidadeDOC;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.enums.EnumTipoCartaoBLK;
import br.com.brb.cix.enums.EnumTipoContaDOC;
import br.com.brb.cix.enums.EnumTipoTransacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransferenciaDocDTO extends AbstractDTO {

	private EnumTipoTransacao tipoTransacao;
	
    private Long agencia;
    private Integer ptaOrigem;
    private Integer ptaOrigemConta;
    private Long conta;
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade modalidadeContaDebito;
    private Long cpfCnpjTitular;
    private EnumTipoPessoa tipoPessoaDebito;
    private String nomeRemetente;
    private Integer ordemTitular;
    private String documentoIdentificacao;
    private String dataEmissao;
    private String telefoneRemetente;
    
    private Integer codigoBancoCredito;
    private EnumTipoContaDOC tipoContaCredito;
    private Integer codigoAgenciaCredito;
    private Long numeroContaCredito;
    private Long cpfCnpjCredito;
    private String nomeTitularCredito1;
    private EnumTipoPessoa tipoPessoaCredito;
    
    private EnumFinalidadeDOC finalidadeDoc;
    private String identificadorTransferencia;
    @LogValorTransacao
    private BigDecimal valorTransacao;
    private BigDecimal valorTarifa;
    private EnumFormaMovimentacao formaMovimentacaoFinanceira;  
    private Long numeroProtocolo;
    
    private EnumTipoCartaoBLK tipoCartao;
    private Integer tipoCodigoSeguranca;
    private Integer canalAtendimentoSenha;
    private Date dataTransacao;
    private Integer tipoDoc;
    private EnumTipoConta tipoContaDoc;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Boolean transferenciaNovoFavorecido;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Boolean mesmaTitularidade;
    private Date dataReferencia;
    private Date dataPagamento; 
    private Boolean transacaoMultipla;
    

    /**
     * Construtor utilizado como Filtro para Pesquisa de Tarifa
     * 
     * @param conta
     * @param tipoConta
     * @param modalidadeContaDebito
     * @param cpfCnpjTitular
     * @param valorTransacao
     */
    public TransferenciaDocDTO(Long conta, EnumTipoConta tipoConta, EnumTipoModalidade modalidadeContaDebito, Long cpfCnpjTitular, BigDecimal valorTransacao,
            Integer ptaOrigemConta) {
        super();
        this.ptaOrigemConta = ptaOrigemConta;
        this.conta = conta;
        this.tipoConta = tipoConta;
        this.modalidadeContaDebito = modalidadeContaDebito;
        this.cpfCnpjTitular = cpfCnpjTitular;
        this.valorTransacao = valorTransacao;
    }

}

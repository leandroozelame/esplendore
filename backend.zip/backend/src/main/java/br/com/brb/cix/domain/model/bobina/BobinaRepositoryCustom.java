package br.com.brb.cix.domain.model.bobina;

public interface BobinaRepositoryCustom {
    
    

}

package br.com.brb.cix.domain.model.gavetadigital;

import java.io.Serializable;

import br.com.brb.cix.domain.model.tiponumerario.TipoNumerario;
import lombok.Getter;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Setter
@Getter
public class GavetaNumerarioId implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private GavetaDigital gavetaDigital;

    private TipoNumerario tipoNumerario;

}

package br.com.brb.cix.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FuncionalidadeFormaPagamentoDTO extends AbstractDTO {
    private Long codigo;
    private Integer unidade;
    private String nomeUnidade;
    private TerminalDTO terminal;
    @JsonIgnore
    private FuncionalidadeDTO funcionalidade;
    private FormaPagamentoDTO formaPagamento;
    private Boolean aceitaFormaPagamento;
    private Boolean statusSuperTransacao;
    private BigDecimal valorMaximoPagamento;
    private BigDecimal valorPld;
    private Date dataCriacao;
    private Date dataAlteracao;
    private Integer modulo;
    private Character ativo;

    /**
     * @param codigo
     * @param funcionalidade
     * @param formaPagamento
     */
    public FuncionalidadeFormaPagamentoDTO(Long codigo, FuncionalidadeDTO funcionalidade,
            FormaPagamentoDTO formaPagamento) {
        super();
        this.codigo = codigo;
        this.funcionalidade = funcionalidade;
        this.formaPagamento = formaPagamento;
    }
}
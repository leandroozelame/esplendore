package br.com.brb.cix.domain.model.parametrotransacaoespecie;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ParametroTransacaoEspecieRepository extends JpaRepository<ParametroTransacaoEspecie, Long> {

    ParametroTransacaoEspecie findByCodigo(Long codigo);
  
    List<ParametroTransacaoEspecie> findByModulo(Integer modulo);
  
    List<ParametroTransacaoEspecie> findByModuloAndFuncionalidadeCodigo(Integer modulo, Long funcionalidade);
    
    boolean existsByCodigo(Long codigo);
  
    boolean existsByModuloAndFuncionalidadeCodigo(Integer modulo, Long funcionalidade);
    
    // Consulta para o componente origem/Destinação de recursos
    List<ParametroTransacaoEspecie> findByFuncionalidadeNumeroTransacaoAndValorLessThanEqualAndHabilitadoAndModulo(Integer nrTransacao, BigDecimal valor, Boolean habilitado, Integer modulo);
}

package br.com.brb.cix.domain.model.perfil;

import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.nomePerfil;
import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.nomePerfilExato;
import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.numeroCanal;
import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.ordenaPorNome;
import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.ordenaPorSituacao;
import static br.com.brb.cix.domain.model.perfil.PerfilPredicateBuilder.situacao;

import br.com.brb.cix.domain.model.grupo.Grupo;
import br.com.brb.cix.infraestrutura.CixException;
import com.querydsl.core.types.Predicate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;

@Service
@Transactional(readOnly = true)
@Validated
public class PerfilServiceImpl implements PerfilService {
    @Autowired
    private PerfilRepository perfilRepository;

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public Perfil incluirPerfil(Perfil perfil) {        
        return perfilRepository.save(perfil);
    }

    @Override
    public List<Perfil> buscaPerfis(String nome, Character ativo, Integer modulo) {
        Predicate predicate = numeroCanal(modulo).and(nomePerfil(nome).and(situacao(ativo)));

        return (List<Perfil>) perfilRepository.findAll(predicate, ordenaPorSituacao(), ordenaPorNome());
    }
    
    @Override
    public List<Perfil> buscaPerfisNomeExato(String nome, Integer modulo) {
        Predicate predicate = numeroCanal(modulo).and(nomePerfilExato(nome));

        return (List<Perfil>) perfilRepository.findAll(predicate, ordenaPorSituacao(), ordenaPorNome());
    }

    @Override
    public Perfil buscaPorId(Long id) {
        return perfilRepository.findOne(id);
    }

    @Override
    public void excluirPerfil(Long id) throws CixException{
        try {
            perfilRepository.delete(id);
        } catch (NullPointerException e) {
            e.printStackTrace();
            throw new CixException("Perfil não existe");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean existsByNomeIgnoreCaseAndModuloAndCodigoNot(String nome, Integer modulo, Long codigo) {
        return perfilRepository.existsByNomeIgnoreCaseAndModuloAndCodigoNot(nome, modulo, codigo);
    }

    @Override
    public Optional<Perfil> buscarPerfilPorGrupo(Integer modulo, List<Grupo> grupos) {
        return perfilRepository.findByModuloAndListaGruposIn(modulo, grupos);
    }
}
package br.com.brb.cix.domain.model.tiponumerario;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "TB_TIPO_NUMERARIO")
public class TipoNumerario  {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "SQ_TIPO_NUMERARIO")
    private Long id;

    @Column(name = "DS_DESCRICAO")
    private String descricao;

    @Column(name = "NR_DESC_NUMERICA")
    private Integer numeroDescricaoNumerario;

    // ======================================
    public final static Integer DOIS = 2;
    public final static Integer CINCO = 5;
    public final static Integer DEZ = 10;
    public final static Integer VINTE = 20;
    public final static Integer CINQUENTA = 50;
    public final static Integer CEM = 100;
    public final static Integer MOEDA = 101;

}

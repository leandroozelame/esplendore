package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoConta;
import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoPessoa;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.brb.cix.domain.model.grupo.Grupo;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegraDTO extends AbstractDTO {
    private Long codigo;
    private String nome;
    private Integer prioridade;
    private Long codigoFuncionalidade;
    private String nomeFuncionalidade = "";
    private EnumValorRegra contaOperador;
    private EnumValorRegra contaOutroPA;
    private EnumValorRegra estorno;
    private EnumValorRegra semSaldo;
    private EnumValorRegra semSenha;
    private EnumValorRegraTipoConta tipoConta;
    private EnumFormaMovimentacao formaPagamento;
    private EnumValorRegraTipoPessoa tipoPessoa;
    private BigDecimal valorTransacao;
    private List<GrupoDTO> gruposOperador = new ArrayList<>();
    private List<GrupoDTO> gruposPrimeiroAutorizador = new ArrayList<>();
    private List<GrupoDTO> gruposSegundoAutorizador = new ArrayList<>();
    private List<GrupoDTO> gruposAutorizadorAlternativo = new ArrayList<>();

    public RegraDTO() {
        super();
    }

    public RegraDTO(Regra regra) {
        nome = regra.getNome();
        codigo = regra.getCodigo();
        prioridade = regra.getPrioridade();
        codigoFuncionalidade = regra.getCodigoFuncionalidade();
        contaOperador = regra.getContaOperador();
        contaOutroPA = regra.getContaOutroPA();
        estorno = regra.getEstorno();
        semSaldo = regra.getSemSaldo();
        semSenha = regra.getSemSenha();
        tipoConta = regra.getTipoConta();
        formaPagamento = regra.getFormaPagamento();
        tipoPessoa = regra.getTipoPessoa();
        valorTransacao = regra.getValorTransacao();
        moveListas(regra);
    }

    private void moveListas(Regra regra) {
        for (Grupo grupo : regra.getGruposOperador()) {
            gruposOperador.add(new GrupoDTO(grupo));
        }
        for (Grupo grupo : regra.getGruposPrimeiroAutorizador()) {
            gruposPrimeiroAutorizador.add(new GrupoDTO(grupo));
        }
        for (Grupo grupo : regra.getGruposSegundoAutorizador()) {
            gruposSegundoAutorizador.add(new GrupoDTO(grupo));
        }
        for (Grupo grupo : regra.getGruposAutorizadorAlternativo()) {
            gruposAutorizadorAlternativo.add(new GrupoDTO(grupo));
        }
    }
    
}
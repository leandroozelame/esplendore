package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumStatusConta;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.domain.model.enums.EnumTipoTitularidadeConta;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class TransferenciaEletronicaDTO extends AbstractDTO {    
    private EnumFormaMovimentacao formaMovimentacao;

    private String nomeTitularDebito;
    private Integer agenciaDebito;
    private Long contaDebito;
    private EnumTipoConta tipoContaDebito;
    private EnumTipoModalidade modalidadeContaDebito;

    private Integer codigoPerfilContaDebito;
    private Long cpfCnpjTitular1Debito;
    private String descricaoPerfilContaDebito;
    private Boolean indicadorContaMilleniumDebito;
    private BigDecimal saldoDisponivelDebito;
    private EnumStatusConta statusDebito;
    private EnumTipoPessoa tipoPessoaDebito;
    private EnumTipoTitularidadeConta tipoTitularidadeContaDebito;

    private String nomeTitularCredito;
    private Integer agenciaCredito;
    private Long contaCredito;
    private EnumTipoConta tipoContaCredito;
    private EnumTipoModalidade modalidadeContaCredito;

    private Integer codigoPerfilContaCredito;
    private Long cpfCnpjTitular1Credito;
    private String descricaoPerfilContaCredito;
    private Boolean indicadorContaMilleniumCredito;
    private BigDecimal saldoDisponivelCredito;
    private EnumStatusConta statusCredito;
    private EnumTipoPessoa tipoPessoaCredito;
    private EnumTipoTitularidadeConta tipoTitularidadeContaCredito;

    @LogValorTransacao
    private BigDecimal valor;
    private String finalidade;
    
    private String documentoIdentificacao;
    private Date dataEmissaoDocumento;
    
    private Boolean indicadorChequeEspecial;
    private Boolean indicadorSemSaldo;
    private Boolean senhaPreenchida;
}
package br.com.brb.cix.domain.model.limitesaldocaixa;

import br.com.brb.cix.dto.ConsultaSaldoEmCaixaDTO;

/**
 * @author u653865
 *
 */
public interface LimiteSaldoEmCaixaRepositoryCustom {

    /**
     * @param filtro
     * @return
     */
    ConsultaSaldoEmCaixaDTO consultar(ConsultaSaldoEmCaixaDTO filtro);
}

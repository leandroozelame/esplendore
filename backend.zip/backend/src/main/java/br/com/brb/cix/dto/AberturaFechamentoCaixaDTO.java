package br.com.brb.cix.dto;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AberturaFechamentoCaixaDTO extends AbstractDTO {

    private Long nsu;
    private Integer numeroMatricula;
    private Date dataTransacao;

}

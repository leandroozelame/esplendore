package br.com.brb.cix.dto;

import br.com.brb.cix.ws.consulta.dto.EnumSimNao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ArrecadacaoUnicaDTO {

    private String descricaoContrato;
    private Integer numeroContrato;
    private EnumSimNao estornoCaixa;
    private EnumSimNao estornoCorrespondente;
}

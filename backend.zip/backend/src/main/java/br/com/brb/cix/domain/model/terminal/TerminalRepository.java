package br.com.brb.cix.domain.model.terminal;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TerminalRepository extends JpaRepository<Terminal, Long> {
    List<Terminal> findByIpTerminal(String ipTerminal);
    
    Terminal findByIpTerminalAndCodigoNot(String ipTerminal, Long codigo);

    Terminal findByCodigo(Long codigo);

    List<Terminal> findByNumeroTerminal(Integer numeroTerminal);

    Terminal findByNumeroTerminalAndModulo(Integer numeroTerminal, Integer modulo);

    List<Terminal> findByCodigoUnidade(Long codigoUnidade);

    List<Terminal> findByCodigoUnidadeAndNumeroTerminal(Long codigoUnidade, Integer numeroTerminal);

    @SuppressWarnings("unchecked")
    Terminal save(Terminal terminal);

    @Transactional
    List<Terminal> deleteByCodigo(Long codigo);
}

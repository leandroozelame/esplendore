package br.com.brb.cix.domain.model.enums.converter;

import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoConta;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumValorRegraTipoContaConverter implements AttributeConverter<EnumValorRegraTipoConta, Character> {

    @Override
    public Character convertToDatabaseColumn(EnumValorRegraTipoConta valorRegra) {
        return valorRegra != null ? valorRegra.getCodigo() : null;
    }

    @Override
    public EnumValorRegraTipoConta convertToEntityAttribute(Character codigo) {
        return EnumValorRegraTipoConta.get(codigo);
    }
}

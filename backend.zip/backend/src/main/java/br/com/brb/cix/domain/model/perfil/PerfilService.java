/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.perfil;

import br.com.brb.cix.domain.model.grupo.Grupo;
import br.com.brb.cix.infraestrutura.CixException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

/**
 *
 * @author u842773
 */
public interface PerfilService {
    
    Perfil incluirPerfil(@Valid Perfil perfil);

    List<Perfil> buscaPerfis(String nome, Character ativo, Integer modulo);
    
    List<Perfil> buscaPerfisNomeExato(String nome, Integer modulo);
    
    boolean existsByNomeIgnoreCaseAndModuloAndCodigoNot(String nome, Integer modulo, Long codigo);

    Perfil buscaPorId(Long id);
    
    void excluirPerfil(Long id) throws CixException;
    
    Optional<Perfil> buscarPerfilPorGrupo(Integer modulo, List<Grupo> grupos);
    
}

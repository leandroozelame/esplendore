package br.com.brb.cix.dto;

import java.util.Date;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlteracaoSenhaBeneficioBfeDTO {
    private Long numeroBeneficio;
    private Integer tipoCartao;
    private String nomeBeneficiario;
    private String cpf;
    private String nomeProcurador;
    private String numeroDocumento;
    private Date dataDocumento;
    private String telefone;
    private String senhaNova;
}
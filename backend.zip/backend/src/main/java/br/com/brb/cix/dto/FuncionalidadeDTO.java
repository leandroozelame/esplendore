package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FuncionalidadeDTO extends AbstractDTO {
    private Long codigo;
    private Integer codigoMenu;
    private String codigoFuncionalidade;
    private String nome;
    private Date dataCriacao = new Date();
    private Integer modulo;
    private Character ativo;
    private Long funcionalidadePai;
    private Long numeroRelatorio;
    private Character autorizavel;
    private boolean statusFormaPagamento;
    private boolean statusViasRecibo;
    private boolean statusFormaAutenticacao;
    private Integer numeroTransacao;
    private BigDecimal valorPld;
    private List<FuncionalidadeFormaPagamentoDTO> listaFormaPagamento;
    private List<FormaAutenticacaoDTO> listaFormaAutenticacao;

    /**
     * @param nome
     * @param numeroTransacao
     */
    public FuncionalidadeDTO(String nome, Integer numeroTransacao) {
        super();
        this.nome = nome;
        this.numeroTransacao = numeroTransacao;
    }
}

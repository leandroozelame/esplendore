package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoBloqueioHabilitacaoContasSobJudice implements EnumDominio{
    BLOQUEIO(6, "Bloqueio de Conta Sob Consulta Judicial"), 
    DESBLOQUEIO(8, "Desbloqueio de Conta Sob Consulta Judicial"); 

    private static final Map<Integer, EnumTipoBloqueioHabilitacaoContasSobJudice> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoBloqueioHabilitacaoContasSobJudice e : EnumTipoBloqueioHabilitacaoContasSobJudice.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoBloqueioHabilitacaoContasSobJudice get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumTipoBloqueioHabilitacaoContasSobJudice criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
package br.com.brb.cix.config.security.autocontido;

import br.com.brb.cix.infraestrutura.CixException;
import br.com.brb.cix.security.CixAccessDeniedHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;

import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@EnableWebSecurity
@Order(Ordered.LOWEST_PRECEDENCE)
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Profile("autoContido")
public class AutocontidoSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
    private OpenAmPreAuthUserDetailsAutocontidoService openAmPreAuthUserDetailsAutocontidoService;
	
	@Autowired
	private CixAccessDeniedHandler cixAccessDeniedHandler;

	private static final String[] AUTH_WHITELIST = {
			// -- Swagger UI v2
			"/v2/api-docs",
			"/swagger-resources",
			"/swagger-resources/**",
			"/configuration/ui",
			"/configuration/security",
			"/swagger-ui.html",
			"/webjars/**",
			// -- Swagger UI v3 (OpenAPI)
			"/v3/api-docs/**",
			"/swagger-ui/**",

			// -- Swagger UI v2
			"/cix/v2/api-docs",
			"/cix/swagger-resources",
			"/cix/swagger-resources/**",
			"/cix/configuration/ui",
			"/cix/configuration/security",
			"/cix/swagger-ui.html",
			"/cix/webjars/**",
			// -- Swagger UI v3 (OpenAPI)
			"/cix/v3/api-docs/**",
			"/cix/swagger-ui/**"
	};
	
    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
        	.sessionManagement()
        		.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
        	.csrf()
        		.disable()
			//TODO habilitar o cors no security do spring depois da migracao do backend para o openshift
//        	.cors()
//        		.and()
        	.anonymous()
        		.disable()
    		.authorizeRequests()
				.antMatchers(AUTH_WHITELIST).permitAll()
            	.antMatchers("/**").authenticated()
            	.and()
        	.addFilter(preAuthFilter())
        	.exceptionHandling()
        		.accessDeniedHandler(cixAccessDeniedHandler);
    }

    @Override
    public void configure(WebSecurity web) {
        web
        	.ignoring()
        	.antMatchers(AUTH_WHITELIST);
    }

    @Bean
    protected Filter preAuthFilter() {
    	OpenAmPreAuthAutocontidoFilter filter = new OpenAmPreAuthAutocontidoFilter();
		filter.setAuthenticationManager(preAuthAuthenticationManager());
		return filter;
	}
	
	@Bean
	protected AuthenticationManager preAuthAuthenticationManager() {

		PreAuthenticatedAuthenticationProvider preAuthProvider= new PreAuthenticatedAuthenticationProvider();
		preAuthProvider.setPreAuthenticatedUserDetailsService(openAmPreAuthUserDetailsAutocontidoService);
		
		List<AuthenticationProvider> providers = new  ArrayList<>();
		providers.add(preAuthProvider);
		
		return new ProviderManager(providers);
	}
	
	public static class OpenAmPreAuthAutocontidoFilter extends AbstractPreAuthenticatedProcessingFilter {

		@Value("${cix.mock.operador:#{null}}")
		private String matriculaOperador;

		private static final Pattern MATRICULA_PATTERN = Pattern.compile("u\\d+");
		
		@Override
		protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
			if (matriculaOperador != null) {
				return matriculaOperador;
			}

			String matricula = System.getProperty("user.name");
			Matcher matcher = MATRICULA_PATTERN.matcher(matricula);

			if (!matcher.matches()) {
				throw new CixException("Matrícula inválida");
			}

			return matricula;
		}

	    /**
	     * Returns a fixed dummy value.
	     */
		@Override
	    protected Object getPreAuthenticatedCredentials(HttpServletRequest httpRequest) {
	        return "N/A";
	    }
		
	}
}

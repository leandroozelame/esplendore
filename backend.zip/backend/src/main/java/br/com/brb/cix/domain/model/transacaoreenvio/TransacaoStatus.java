package br.com.brb.cix.domain.model.transacaoreenvio;


import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.ToString;


@Entity
@Getter
@Table(name = "TB_SITUACAO_TRANSACAO")
@ToString
public class TransacaoStatus  {
    
    private static final long serialVersionUID = 3396484451071543661L;
    
    @Id
    @Column(name = "CD_SITUACAO_TRANSACAO")
    private Long codigoSituacao;

    @Column(name = "NO_SITUACAO_TRANSACAO")
    private String situacao;
    
    @OneToMany(mappedBy = "transacaoStatus", fetch = FetchType.LAZY)
    private List<TransacaoReenvio> transacaoReenvios;
    
}

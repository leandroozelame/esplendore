package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EstornarTransacaoRegraDTO {
	
	private Long nsu;
	private String descricaoTransacao;
	private EnumFormaMovimentacao formaMovimentacao;
	private Date dataHoraPagamento;
	private BigDecimal valorTransacao;
    private String motivoEstorno;
}
package br.com.brb.cix.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CadastroARRDTO {
    private Integer numeroContrato;
    private String descricaoContrato;
    private Integer codigoReceita;
    private String grupoArr;
    private String indicadorUsoCodigoBarra;
}
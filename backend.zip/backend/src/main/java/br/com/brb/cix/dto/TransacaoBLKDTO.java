package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransacaoBLKDTO {
    
    private String hora;
    private Date data;
    private String nsu;
    private String descricao;
    private BigDecimal valor;
}

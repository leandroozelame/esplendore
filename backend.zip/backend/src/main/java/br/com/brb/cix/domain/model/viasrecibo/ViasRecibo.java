package br.com.brb.cix.domain.model.viasrecibo;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Table(name = "TB_VIAS_RECIBO")
public class ViasRecibo {

    private static final long serialVersionUID = -7884383952009631336L;

    @EmbeddedId
    private ViasReciboId viasReciboId;

    @ManyToOne
    @JoinColumn(name = "SQ_FUNCIONALIDADE", insertable = false, updatable = false)
    private Funcionalidade funcionalidade;

    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO",insertable = false, updatable = false)
    private FormaPagamento formaPagamento;

    @Column(name = "QT_VIAS_RECIBO", nullable = false)
    private Integer quantidadeViasRecibo;

}

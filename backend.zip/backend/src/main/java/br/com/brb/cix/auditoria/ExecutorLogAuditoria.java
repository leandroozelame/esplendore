package br.com.brb.cix.auditoria;

import br.com.brb.cix.domain.model.auditoria.Auditoria;
import br.com.brb.cix.dto.AbstractDTO;
import br.com.brb.cix.pld.ComplementoPldService;
import br.com.brb.cix.service.AuditoriaService;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class ExecutorLogAuditoria {
    @Setter
    @Getter
    private Auditoria auditoria;
    @Setter
    @Getter
    private List<String> supervisores;
    @Autowired
    private AuditoriaService auditoriaService;
    @Autowired
    private LogAuditoriaBuilder logAuditoriaBuilder;
    
    @Autowired
    private ComplementoPldService complementoPldService;

    public void executa() {
        try {
            auditoria = auditoriaService.incluirLogAuditoria(auditoria, supervisores);
            logAuditoriaBuilder.comConta(null);
            gravaComplementoDoPld();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    private void gravaComplementoDoPld() {
        try {
            if (auditoria.getCdNsuAutorizacao() != null && auditoria.getMapaParametroEntrada() != null) {
                AbstractDTO abstractDTO = getFirstEntryOfAbstractDTO(auditoria.getMapaParametroEntrada());
                if (abstractDTO != null && StringUtils.isNotEmpty(abstractDTO.getOrigemDestinoRecurso())) {
                    Long conta = auditoria.getConta() != null ? Long.parseLong(auditoria.getConta()) : null;
                    complementoPldService.gravaLog(abstractDTO.getOrigemDestinoRecurso(), auditoria.getVlOperacao(),
                            conta, auditoria.getCdNsuAutorizacao().intValue());
                }
            }
        }catch (Exception e){
            log.error(e.getMessage(), e);
        }
    }

    private AbstractDTO getFirstEntryOfAbstractDTO(Map<String, Object> argumentos){
        return (AbstractDTO) argumentos.entrySet().stream().filter(map -> map.getValue() instanceof AbstractDTO)
                .map(map -> map.getValue()).findFirst().orElse(null);
    }
}
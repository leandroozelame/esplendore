package br.com.brb.cix.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaLancamentosEstornaveisDTO {
    private Long numeroConta;
    private String nomeTitular;
    private List<LancamentoEstornavelDTO> lancamentosEstornaveis = new ArrayList<LancamentoEstornavelDTO>();
}
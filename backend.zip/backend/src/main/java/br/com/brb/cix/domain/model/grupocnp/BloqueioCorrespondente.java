package br.com.brb.cix.domain.model.grupocnp;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import br.com.brb.cix.domain.model.unidade.Unidade;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Table(name = "TB_BLOQUEIO_CORRESPONDENTE")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "codigo")
public class BloqueioCorrespondente {
    
    private static final long serialVersionUID = 2851159539111833118L;

    @Id
    @SequenceGenerator(name = "bloqueiocnp_sequence", 
        sequenceName = "SQ_BLOQUEIO_CORRESPONDENTE", allocationSize = 1)
    @GeneratedValue(generator = "bloqueiocnp_sequence")
    @Column(name = "SQ_BLOQUEIO_CORRESPONDENTE", unique=true)
    private Long codigo;

    @Column(name = "DT_BLOQUEIO")
    private Date data;
    
    @Column(name = "DS_MOTIVO_BLOQUEIO")
    private String motivo;

    @OneToOne(cascade = CascadeType.REFRESH)
    @JoinColumn(name = "CD_UNIDADE", referencedColumnName="UNDCOD")
    private Unidade unidade;
    
    public BloqueioCorrespondente() {
        super();
    }
    
    public BloqueioCorrespondente(Long codigo, Date data, String motivo, Unidade unidade) {
        super();
        this.codigo = codigo;
        this.data = data;
        this.motivo = motivo;
        this.unidade = unidade;
    }

}

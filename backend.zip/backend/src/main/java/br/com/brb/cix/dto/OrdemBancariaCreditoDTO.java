package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class OrdemBancariaCreditoDTO extends AbstractDTO {
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade modalidade;
    private String descTipoConta; // dummy requerido pelo frontend
    private Long nrContaCredito;
    private BigDecimal valor;
    private String nomeTitular; // dummy requerido pelo frontend
}
package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.service.TerminalComponent;
import br.com.brb.cix.util.CixUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CriterioContaOutroPA implements CriterioAlcada {

    @Autowired
    private TerminalComponent terminalComponent;

    @Override
    public String getNomeCriterio() {
        return "Conta de Outro PA";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumValorRegra.INDIFERENTE.equals(regra.getContaOutroPA());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        Boolean isContaDebito = dadosTransacao.getContaDebito();
        Long numeroConta = dadosTransacao.getConta();

        if (!isContaDebito || numeroConta == null) {
            log.debug("isContaDebito: {}, numeroConta: {}", isContaDebito, numeroConta);
            return false;
        }

        EnumValorRegra regraContaOutroPA = regra.getContaOutroPA();
        Long unidadeOperador = terminalComponent.getCodigoUnidadeLong();
        log.debug("regraContaOutroPA: {}, isContaDebito: {}, agencia: {}, unidadeOperador: {}", regraContaOutroPA, isContaDebito, CixUtil.getAgencia(numeroConta), unidadeOperador);

        return     (regraContaOutroPA.equals(EnumValorRegra.NAO) && (CixUtil.getAgencia(numeroConta).equals(unidadeOperador.intValue())))
                || (regraContaOutroPA.equals(EnumValorRegra.SIM) && (!CixUtil.getAgencia(numeroConta).equals(unidadeOperador.intValue())));
    }
}

package br.com.brb.cix.dto.comum;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.dto.AbstractDTO;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode
public class FormaPagamentoFuncionalidadeDTO extends AbstractDTO {
    private char ativo;
    private Boolean superTransacao;
    private Integer unidade;
    private Date dataCriacao;
    private Date dataAlteracao;
    private FormaPagamento formaPagamento;
    private List<FuncionalidadeResumidaDTO> funcionalidades;
    private BigDecimal valorPLD;
    private Boolean aceitaFormaPagamento;
}

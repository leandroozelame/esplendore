/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.*;

/**
 *
 * @author u842773
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class DadosAcumuladoresLimitesDTO {
    private BigDecimal valorSaqueCashBB;
    private BigDecimal valorSaquesFebraban;
    private BigDecimal valorTransferencias;
    private BigDecimal valorPagamentos;
    private BigDecimal valorAcumuladoRedesExternas;
    private BigDecimal valorAcumuladoTedsEnviadas;

    public DadosAcumuladoresLimitesDTO(BigDecimal valorSaqueCashBB, BigDecimal valorSaquesFebraban,
            BigDecimal valorTransferencias, BigDecimal valorAcumuladoRedesExternas,
            BigDecimal valorAcumuladoTedsEnviadas) {
        this.valorSaqueCashBB = valorSaqueCashBB;
        this.valorSaquesFebraban = valorSaquesFebraban;
        this.valorTransferencias = valorTransferencias;
        this.valorAcumuladoRedesExternas = valorAcumuladoRedesExternas;
        this.valorAcumuladoTedsEnviadas = valorAcumuladoTedsEnviadas;
    }
}
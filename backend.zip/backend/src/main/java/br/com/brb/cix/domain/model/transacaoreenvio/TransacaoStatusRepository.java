package br.com.brb.cix.domain.model.transacaoreenvio;


import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoStatusRepository extends JpaRepository<TransacaoStatus, Long> {
    
    TransacaoStatus findByCodigoSituacao(Long codigo);

}

package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.regra.Regra;

public interface CriterioAlcada {
    String getNomeCriterio();
    boolean isCriterioDesabilitado(Regra regra);
    boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao);
}
package br.com.brb.cix.domain.model.funcionalidadeformapagamento;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.domain.model.terminal.Terminal;
import br.com.brb.cix.util.ConvertCharToBoolean;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author u653865
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "TB_FUNCIONALIDADE_FORMA_PAGTO")
public class FuncionalidadeFormaPagamento  {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "func_forma_parametro_sequence", sequenceName = "SQ_FUNCIONALIDADE_FORMA_PAGTO", allocationSize = 1)
    @GeneratedValue(generator = "func_forma_parametro_sequence")
    @Column(name = "SQ_FUNCIONALIDADE_FORMA_PAGTO")
    private Long codigo;

    @Column(name = "CD_UNIDADE")
    private Integer unidade;

    @ManyToOne
    @JoinColumn(name = "SQ_TERMINAL")
    private Terminal terminal;

    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "SQ_FUNCIONALIDADE", nullable = true)
    @JsonBackReference
    private Funcionalidade funcionalidade;

    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_ACEITA_FORMA_PAGAMENTO")
    private Boolean aceitaFormaPagamento;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_SUPERTRANSACAO")
    private Boolean statusSuperTransacao;

    @Column(name = "VL_MAXIMO_PAGAMENTO")
    private BigDecimal valorMaximoPagamento;

    @Column(name = "VL_PLD")
    private BigDecimal valorPld;
    
    @Column(name = "DT_CRIACAO")
    @CreationTimestamp
    private Date dataCriacao;

    @Column(name = "DT_ALTERACAO")
    @UpdateTimestamp
    private Date dataAlteracao;

    @Column(name = "CD_MODULO")
    private Integer modulo;

    @Column(name = "ST_ATIVO")
    private Character ativo;
}
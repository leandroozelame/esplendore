package br.com.brb.cix.config;

import br.com.brb.cix.domain.model.enums.converter.EnumGenericoConverter;
import br.com.brb.cix.enums.EnumCanal;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import net.kaczmarzyk.spring.data.jpa.web.SpecificationArgumentResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.SortHandlerMethodArgumentResolver;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.AllowableListValues;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.time.*;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

@Configuration
@EnableSwagger2
public class WebConfig extends WebMvcConfigurerAdapter {

	public static final String API_VERSION = "/api/v1.0.0";

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ApplicationProperties applicationProperties;

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
		registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> argumentResolvers) {
		argumentResolvers.add(new SpecificationArgumentResolver());
		argumentResolvers.add(new SortHandlerMethodArgumentResolver());
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {
		super.configureMessageConverters(converters);
		converters.add(new MappingJackson2HttpMessageConverter(objectMapper));
	}

	@Override
	public void addFormatters(FormatterRegistry registry) {
		registry.addConverter(new EnumGenericoConverter());
	}

	@Bean
	public Docket swaggerSpringMvcPlugin() {
		Docket docket = new Docket(DocumentationType.SWAGGER_2)
				.groupName("api-negocio")
				.select()
				.paths(PathSelectors.any())
				.build()
				.apiInfo(apiInfo());
		makeDirectModelSubstitute(docket);
		makeGlobalResponseMessage(docket);
		docket.globalOperationParameters(globalHeaders());
		return docket;
	}

	private void makeGlobalResponseMessage(Docket docket) {
		docket.globalResponseMessage(RequestMethod.POST, newArrayList(new ResponseMessageBuilder()
						.code(HttpStatus.UNPROCESSABLE_ENTITY.value())
						.message("Erro de Validação.")
						.responseModel(new ModelRef("ValidationError"))
						.build(),
				new ResponseMessageBuilder()
						.code(HttpStatus.BAD_REQUEST.value())
						.message("Erro de negócio.")
						.responseModel(new ModelRef("ExceptionInfo"))
						.build()
		));
	}

	private void makeDirectModelSubstitute(Docket docket) {
		docket.directModelSubstitute(LocalDate.class, String.class)
				.directModelSubstitute(OffsetDateTime.class, String.class)
				.directModelSubstitute(ZonedDateTime.class, String.class)
				.directModelSubstitute(LocalDate.class, String.class)
				.directModelSubstitute(Instant.class, String.class)
				.directModelSubstitute(LocalDateTime.class, String.class)
				.directModelSubstitute(Duration.class, String.class)
				.directModelSubstitute(LocalTime.class, String.class)
				.directModelSubstitute(MonthDay.class, String.class)
				.directModelSubstitute(OffsetDateTime.class, String.class)
				.directModelSubstitute(OffsetTime.class, String.class)
				.directModelSubstitute(Period.class, String.class)
				.directModelSubstitute(Year.class, String.class)
				.directModelSubstitute(YearMonth.class, String.class);

	}

	private ApiInfo apiInfo() {
		return new ApiInfo(applicationProperties.getSwagger().getTitle(),
				applicationProperties.getSwagger().getDescription(),
				applicationProperties.getSwagger().getVersion(),
				applicationProperties.getSwagger().getTermsOfServiceUrl(),
				applicationProperties.getSwagger().getContact(),
				applicationProperties.getSwagger().getLicense(),
				applicationProperties.getSwagger().getLicenseUrl());
	}

	private List<Parameter> globalHeaders(){
		List<Parameter> headers = new ArrayList<>();
		List<String> valores = new ArrayList<String>();
		ObjectNode ObjAub = objectMapper.createObjectNode();
		ObjectNode ObjCaixa = objectMapper.createObjectNode();
		ObjectNode ObjCorrespondente = objectMapper.createObjectNode();
		ObjectNode ObjCaixaAdm = objectMapper.createObjectNode();

		ObjAub.put("codigoCanal", EnumCanal.AUB.getCodigo());
		ObjAub.put("env", "LCL");
		ObjCaixa.put("codigoCanal", EnumCanal.CIX.getCodigo());
		ObjCaixa.put("env", "LCL");
		ObjCorrespondente.put("codigoCanal", EnumCanal.CIXC.getCodigo());
		ObjCorrespondente.put("env", "LCL");
		ObjCaixaAdm.put("codigoCanal", EnumCanal.CIX_ADM.getCodigo());
		ObjCaixaAdm.put("env", "LCL");

		valores.add(ObjAub.toString());
		valores.add(ObjCaixa.toString());
		valores.add(ObjCorrespondente.toString());
		valores.add(ObjCaixaAdm.toString());

		headers.add(new ParameterBuilder().name("X-CIX")
				.description("Cabeçalho obrigatório para validação canal selecionado:<br> 6 - AUB<br> 5 - CIX<br> 9 - CORRESPONDENTE<br> 16 - CIXADM<br>")
				.modelRef(new ModelRef("string")).parameterType("header")
				.required(true)
				.allowableValues(new AllowableListValues(valores, "string"))
				.build());
		return headers;
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(applicationProperties.getCors().getAllowedOrigins());
		configuration.setAllowedMethods(applicationProperties.getCors().getAllowedMethods());
		configuration.setAllowedHeaders(applicationProperties.getCors().getAllowedHeaders());
		configuration.setExposedHeaders(applicationProperties.getCors().getExposedHeaders());
		configuration.setMaxAge(applicationProperties.getCors().getMaxAge());
		configuration.setAllowCredentials(applicationProperties.getCors().getAllowCredentials());
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}

}
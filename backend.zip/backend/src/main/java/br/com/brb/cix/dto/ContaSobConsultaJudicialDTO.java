package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ContaSobConsultaJudicialDTO extends AbstractDTO {

    private Integer codigoPontoAtendimento;
    private Boolean indicadorBloqueioSobConsultaJudicial;
    private EnumTipoModalidade modalidadeConta;
    private Long numeroConta;
    private EnumTipoConta tipoConta;
    
}
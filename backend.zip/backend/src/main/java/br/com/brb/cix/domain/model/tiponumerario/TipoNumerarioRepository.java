package br.com.brb.cix.domain.model.tiponumerario;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author u653865
 *
 */
public interface TipoNumerarioRepository extends JpaRepository<TipoNumerario, Long> {

    /**
     * @param numeroDescricaoNumerario
     * @return
     */
    TipoNumerario findByNumeroDescricaoNumerario(Integer numeroDescricaoNumerario);
}

package br.com.brb.cix.domain.model.regra;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface RegraRepository extends JpaRepository<Regra, Long> {
    Regra findByCodigo(Long codigo);

    List<Regra> findByCodigoFuncionalidadeOrderByPrioridadeAsc(Long codigoFuncionalidade);

    List<Regra> findByNome(String nome);

    List<Regra> findByNomeAndCodigoNot(String nome, Long codigo);

    @Query(value = "SELECT r.* "
            + "FROM {h-schema}TB_REGRA r, {h-schema}TB_FUNCIONALIDADE f "
            + "WHERE r.SQ_FUNCIONALIDADE = f.SQ_FUNCIONALIDADE AND f.NO_FUNCIONALIDADE = ?1 AND f.CD_MODULO = ?2"
            + " ORDER BY r.NR_PRIORIDADE ASC", nativeQuery = true)    
    List<Regra> findByNomeFuncionalidadeOrderByPrioridadeAsc(String nomeFuncionalidade, Integer modulo);

    @Query("from Regra where codigoFuncionalidade in (from Funcionalidade where codigoMenu = ?1 and modulo = ?2) order by prioridade ASC")
    List<Regra> findByCodigoMenuFuncionalidadeOrderByPrioridadeAsc(Integer codigoMenu, Integer modulo);
    
    @Query("from Regra where codigoFuncionalidade in (from Funcionalidade where codigoMenu = ?1 and modulo = ?2) and formaPagamento in(?3) order by prioridade ASC")
    List<Regra> findByCodigoMenuFuncionalidadeFormaPagamentoOrderByPrioridadeAsc(Integer codigoMenu, Integer modulo, EnumFormaMovimentacao formaPagamento);

    @SuppressWarnings("unchecked")
    Regra save(Regra regra);

    @Transactional
    List<Regra> deleteByCodigo(Long codigo);
}

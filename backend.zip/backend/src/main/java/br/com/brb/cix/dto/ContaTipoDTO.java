package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Getter
@Setter
@ToString
public class ContaTipoDTO extends AbstractDTO {
	private Long agencia;
	@JsonInclude(JsonInclude.Include.NON_DEFAULT)
	private Long conta;
	private Integer ordemConta;
	private String nomeTitular;
	private EnumTipoConta tipoConta;
	private EnumTipoModalidade tipoModalidade;
	
	public ContaTipoDTO(Long conta, Long agencia, EnumTipoConta tipoConta, EnumTipoModalidade tipoModalidade) {
		super();
		this.conta = conta;
		this.agencia = agencia;
		this.tipoConta = tipoConta;
		this.tipoModalidade = tipoModalidade;
	}
}
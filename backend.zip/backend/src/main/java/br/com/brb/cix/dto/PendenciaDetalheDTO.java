package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class PendenciaDetalheDTO {
    private Long codigo;
    private Long nsuCix;
    private Long nsuBlk;
    private Long nsuCixEstornado;
    private Character situacao;
    private Long codigoRegra;
    private Long numeroRecibo;
    private Date dataCadastro;
    private Date dataAtualizacao;
    private BigDecimal valor;
    private String descricao;
    private Long contaOrigem;
    private Long contaDestino;
    private Integer terminal;
    private String matricula;
    private Integer matriculaUltimoAutorizador;
    private Integer unidade;
    private String detalhamento;
    private String motivoRejeicao;
    private String nomeUltimoAutorizador;
    private String nomeRegra;
    private String grupoAutorizador;
    private String formaMovimentacao;
    private String nomeCorrentista;
    private BigDecimal saldoDisponivel;

    public PendenciaDetalheDTO() {
        super();
    }
}
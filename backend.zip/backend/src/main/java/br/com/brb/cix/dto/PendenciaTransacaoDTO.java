package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

@Data
public class PendenciaTransacaoDTO {
    private Integer numeroNSU;
    private Date dataHora;
    private Integer codigoTransacao;
    private String descricaoTransacao;
    private Integer ptaOrigem;
    private Integer numeroNSUOrigem;
    private Integer indicadorSituacao; // 1 Pendente, 2 Confirmada, 3 Cancelada
    private String descricaoSituacao;
    private Long numeroConta;
    private BigDecimal valorLancamento;

    public PendenciaTransacaoDTO() {
        super();
    }
}
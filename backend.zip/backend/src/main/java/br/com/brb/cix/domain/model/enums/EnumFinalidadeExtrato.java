package br.com.brb.cix.domain.model.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.HashMap;
import java.util.Map;


import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumFinalidadeExtrato implements EnumDominio{
    
    USO_INTERNO(1, "Uso Interno"), 
    USO_EXTERNO(2, "Uso Externo");
	
    private static final Map<Integer, EnumFinalidadeExtrato> MAP = new HashMap<>();
    
    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;

    static {
        for (EnumFinalidadeExtrato e : EnumFinalidadeExtrato.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumFinalidadeExtrato get(int codTipoExtrato) {
        return MAP.get(codTipoExtrato);
    }
    
    @JsonCreator
    public static EnumFinalidadeExtrato criaEnum(int codigo) {
        return MAP.get(codigo);
    }

    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }

    
}
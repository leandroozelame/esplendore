package br.com.brb.cix.dto;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaContatosContaDTO {
	private List<ContaTipoDTO> contas;
	private Integer ordem;
	private String nomeCliente;
	private List<ContatoDTO> contatos;
	private boolean senhaEncontrada;
    private int codigoSenhaEncontrada;
}
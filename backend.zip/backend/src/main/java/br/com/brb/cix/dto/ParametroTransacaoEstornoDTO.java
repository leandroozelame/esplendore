package br.com.brb.cix.dto;

import br.com.brb.cix.enums.EnumTipoValorEstorno;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class ParametroTransacaoEstornoDTO {
    private Long codigo;
    private Integer modulo;
    private String nomeModulo;
    private Long funcionalidade;
    private String nomeFuncionalidade;
    private Long formaPagamento; 
    private String nomeFormaPagamento;
    private String horaLimiteEstorno;
    private BigDecimal valorEstorno;
    private BigDecimal valorLimiteEstorno;
    private BigDecimal valorMinimoEstorno;
    private boolean statusTransacaoEstorno;
    private EnumTipoValorEstorno tipoValorEstorno;

    public EnumTipoValorEstorno getTipoValorEstorno() {
        if(tipoValorEstorno != null){
            return tipoValorEstorno;
        }
        
        if(!statusTransacaoEstorno){
            return EnumTipoValorEstorno.NAO_SELECIONADO;
        }
        
        if (valorMinimoEstorno != null && valorLimiteEstorno != null){
            return EnumTipoValorEstorno.INTERVALO;
        }else if(valorMinimoEstorno == null && valorLimiteEstorno != null){
            return EnumTipoValorEstorno.MAXIMO;
        }
        
        return EnumTipoValorEstorno.TODOS;
    }
}
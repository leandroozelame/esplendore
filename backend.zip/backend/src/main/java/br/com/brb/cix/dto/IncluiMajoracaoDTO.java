package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class IncluiMajoracaoDTO extends AbstractDTO {
	private Long id;
    private Integer cnlCod;
    private String cnlDes;
    private String ctaId;
    private Long ctaNum;
    private Integer ctaTip;
    private Integer ctaTipoPessoa;
    protected Date dataAgendamento;
    protected Date dataPeriodoInicial;
    protected Date dataPeriodoFinal;
    protected Boolean permitePeriodoNoturno;
    protected Integer ptaCod;
    protected Integer tctCod;
    protected BigDecimal valorMajorado;
}
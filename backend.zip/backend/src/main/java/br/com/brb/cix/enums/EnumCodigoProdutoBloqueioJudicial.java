package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumCodigoProdutoBloqueioJudicial implements EnumDominio {
    PARA_CONTA_CORRENTE(1, "CONTA CORRENTE", "PRD_BLOQ_JUD_CC"),
    PARA_CONTA_POUPANCA(2, "CONTA POUPANÇA", "PRD_BLOQ_JUD_PP"),
    PARA_CONTA_SALARIO(3, "CONTA SALÁRIO", "PRD_BLOQ_JUD_PS"),
    PARA_CONTA_CORRENTE_INVESTIMENTO(4, "CONTA CORRENTE INVESTIMENTO", "PRD_BLOQ_JUD_CI"),
    PARA_CONTA_POUPANCA_INVESTIMENTO(5, "CONTA POUPANÇA INVESTIMENTO", "PRD_BLOQ_JUD_PI");

    @Getter
    private final Integer codigo;

    @Getter
    private final String descricao;
    
    @Getter
    private final String descricaoAba;

    private static final Map<Integer, EnumCodigoProdutoBloqueioJudicial> MAP_ENUMCANAL = new ConcurrentHashMap<>();

    static {
        for (EnumCodigoProdutoBloqueioJudicial e : EnumCodigoProdutoBloqueioJudicial.values()) {
            MAP_ENUMCANAL.put(e.getCodigo(), e);
        }
    }

    @JsonCreator
    public static EnumCodigoProdutoBloqueioJudicial get(int codigo) {
        return MAP_ENUMCANAL.get(codigo);
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

package br.com.brb.cix.domain.model.viasrecibo;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ViasReciboRepository extends JpaRepository<ViasRecibo, Long> {
    List<ViasRecibo> findByFuncionalidadeModulo(Integer codigoModulo);
    Optional<ViasRecibo> findByFuncionalidadeCodigoAndFormaPagamentoCodigo(Long codigoFuncionalidade, Long codigoPagamento);
    void deleteByFuncionalidadeCodigo(Long codigoFuncionalidade);
}

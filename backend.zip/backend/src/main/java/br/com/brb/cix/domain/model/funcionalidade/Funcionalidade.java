/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.funcionalidade;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.enums.EnumAtivo;
import br.com.brb.cix.enums.EnumAutorizavel;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.com.brb.cix.domain.model.formaautenticacao.FormaAutenticacao;
import br.com.brb.cix.domain.model.funcionalidadeformapagamento.FuncionalidadeFormaPagamento;
import br.com.brb.cix.domain.model.perfil.Perfil;
import br.com.brb.cix.domain.model.supertransacao.ParametroSupertransacao;
import br.com.brb.cix.dto.FuncionalidadeDTO;
import br.com.brb.cix.util.ConvertCharToBoolean;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@Entity
@Getter
@Setter
@Table(name = "TB_FUNCIONALIDADE")
public class Funcionalidade  {

    private static final long serialVersionUID = -6702563344920981783L;

    @SequenceGenerator(name = "funcionalidade_sequence", sequenceName = "SQ_FUNCIONALIDADE", allocationSize = 1)
    @GeneratedValue(generator = "funcionalidade_sequence")
    @Column(name = "SQ_FUNCIONALIDADE")
    @Id
    private Long codigo;

    @Column(name = "CD_FUNCIONALIDADE")
    private String codigoFuncionalidade;

    @Column(name = "NO_FUNCIONALIDADE")
    private String nome;

    @Column(name = "DT_CRIACAO")
    private Date dataCriacao;

    @Column(name = "CD_MODULO")
    private Integer modulo;

    @Column(name = "ST_ATIVO")
    private Character ativo;

    @Column(name = "SQ_FUNCIONALIDADE_PAI")
    private Long funcionalidadePai;

    @Column(name = "NR_RELATORIO")
    private Long numeroRelatorio;

    @Column(name = "ST_AUTORIZAVEL")
    private Character autorizavel;

    @Column(name = "CD_MENU")
    private Integer codigoMenu;

    @Column(name = "DS_AJUDA")
    private String ajuda;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_FORMA_PAGAMENTO")
    private Boolean statusFormaPagamento;

    @Column(name = "ST_VIAS_RECIBO")
    @Convert(converter = ConvertCharToBoolean.class)
    private Boolean statusViasRecibo;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_FORMA_AUTENTICACAO")
    private Boolean statusFormaAutenticacao;

    @Column(name = "NR_TRANSACAO")
    private Integer numeroTransacao;
    
    @Column(name = "DS_STATE")
    private String rota;

    @Column(name = "VL_PLD")
    private BigDecimal valorPld;

    @JsonBackReference
    @ManyToMany // (mappedBy = "listaFuncionalidades")
    @JoinTable(name = "TB_PERFIL_FUNCIONALIDADE", joinColumns = @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE"), inverseJoinColumns = @JoinColumn(name = "SQ_CODIGO", referencedColumnName = "SQ_CODIGO"))
    private List<Perfil> listaPerfis = new ArrayList<>();

    @OneToMany(mappedBy = "funcionalidade", fetch = FetchType.LAZY)
    @JsonManagedReference
    private List<FuncionalidadeFormaPagamento> listaFormaPagamento;

    @ManyToMany
    @JoinTable(name = "TB_FUNCIONALIDADE_AUTENTICACAO", joinColumns = @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE"), inverseJoinColumns = @JoinColumn(name = "CD_FORMA_AUTENTICACAO", referencedColumnName = "CD_FORMA_AUTENTICACAO"))
    private List<FormaAutenticacao> listaFormaAutenticacao;
    
    @JsonBackReference
    @ManyToMany
    @JoinTable(name = "TB_SUPERTRANSACAO_FUNC", joinColumns = @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE"), 
    	inverseJoinColumns = @JoinColumn(name = "SQ_SUPERTRANSACAO", referencedColumnName = "SQ_SUPERTRANSACAO"))
    private List<ParametroSupertransacao> listaSupertransacao = new ArrayList<>();

    public Funcionalidade() {
        dataCriacao = new Date();
    }

    public Funcionalidade(Long codigo, String codigoFuncionalidade, String nome, Date dataCriacao, Integer modulo) {
        this.codigoFuncionalidade = codigoFuncionalidade;
        this.nome = nome;
        this.modulo = modulo;
        ativo = EnumAtivo.ATIVO.getCodigo();
        this.dataCriacao = new Date();
        autorizavel = EnumAutorizavel.NAO_AUTORIZAVEL.getCodigo();
    }

    public Funcionalidade(FuncionalidadeDTO funcionalidadeDTO) {
        codigo = funcionalidadeDTO.getCodigo();
        codigoFuncionalidade = funcionalidadeDTO.getCodigoFuncionalidade();
        nome = funcionalidadeDTO.getNome();
        dataCriacao = funcionalidadeDTO.getDataCriacao();
        modulo = funcionalidadeDTO.getModulo();
        ativo = funcionalidadeDTO.getAtivo();
        autorizavel = funcionalidadeDTO.getAutorizavel();
        funcionalidadePai = funcionalidadeDTO.getFuncionalidadePai();
        numeroRelatorio = funcionalidadeDTO.getNumeroRelatorio();
    }

    @Override
    @JsonIgnore
    public int hashCode() {
        int hash = 7;

        hash = 29 * hash + Objects.hashCode(this.codigo);
        hash = 29 * hash + Objects.hashCode(this.codigoFuncionalidade);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if ((obj == null) || (getClass() != obj.getClass())
                || (!Objects.equals(this.codigoFuncionalidade, ((Funcionalidade) obj).codigoFuncionalidade))
                || (!Objects.equals(this.codigo, ((Funcionalidade) obj).codigo))) {
            return false;
        }
        return true;
    }
}

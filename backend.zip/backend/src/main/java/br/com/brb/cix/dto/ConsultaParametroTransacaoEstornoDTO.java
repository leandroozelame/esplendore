package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
@Builder
public class ConsultaParametroTransacaoEstornoDTO{
    private int codigoModulo = -1;
    private long codigoFuncionalidade = -1;
    private long codigoFormaPagamento = -1;
}

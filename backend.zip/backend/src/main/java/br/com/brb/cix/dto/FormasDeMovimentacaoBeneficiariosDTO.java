package br.com.brb.cix.dto;

import java.io.Serializable;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.formasdemovimentacaobeneficiarios.FormasDeMovimentacaoBeneficiarios;
import br.com.brb.cix.domain.model.formasdemovimentacaobeneficiarios.FormasDeMovimentacaoBeneficiariosRepository;
import br.com.brb.cix.domain.model.modulo.Modulo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@Setter
public class FormasDeMovimentacaoBeneficiariosDTO implements Serializable{

    private static final long serialVersionUID = 5854429321300606200L;
    private Long codigo;
    private Integer unidade;
    private EnumTipoConta tipoContaCliente;
    private Long numeroContaCliente;
    private String nomeCliente; 
    private Boolean bloqueado;
    private FormaPagamento formaPagamento;
    private Modulo modulo;
    private String formaMovimentacao;
    
    
    public FormasDeMovimentacaoBeneficiarios atualizar(Long codigo, FormasDeMovimentacaoBeneficiariosRepository formasDeMovimentacaoBeneficiariosRepository) {
        FormasDeMovimentacaoBeneficiarios movimentacao = formasDeMovimentacaoBeneficiariosRepository.getOne(codigo);
        
        movimentacao.setNumeroContaCliente(this.getNumeroContaCliente());
        movimentacao.setNomeCliente(this.getNomeCliente());
        movimentacao.setFormaPagamento(this.getFormaPagamento());
        movimentacao.setUnidade(this.getUnidade());
        movimentacao.setTipoContaCliente(this.getTipoContaCliente());
        movimentacao.setBloqueado(this.getBloqueado());
        movimentacao.setCodigo(this.getCodigo());
        return movimentacao;
    }
}
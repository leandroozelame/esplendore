package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoPessoa;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFinalidadeTED;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.enums.EnumTipoTransacaoTed;
import br.com.brb.cix.enums.EnumFinalidadeTEDFichaContabil;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class TransferenciaTedDTO extends AbstractDTO {
    
    private EnumFormaMovimentacao formaMovimentacao;
    private Integer agenciaDebito;
    private Long contaDebito;
    private EnumTipoConta tipoContaDebito;
    private Long cpfCnpjTitularDebito;
    private String nomeTitularDebito;
    private EnumTipoPessoa tipoPessoaDebito;
    private Integer ordemTitular;
    
    private Integer codigoBancoCredito;
    private Integer agenciaCredito;
    private Long contaCredito;
    private EnumTipoConta tipoContaCredito;
    private String nomeTitularCredito;
    private Long cpfCnpjTitularCredito;
    private EnumTipoPessoa tipoPessoaCredito;
    private String numeroContaPagamento;

    private String numeroIF;
    private EnumTipoTransacaoTed tipoTransacao; 
    private String documentoIdentificacao;
    private String orgaoExpedidorDocumento;
    private Date dataEmissaoDocumento;
    private String telefoneRemetente;
    private String identificadorTransferencia;
    private EnumFinalidadeTED finalidade;
    private String historico;
    private String numeroContratoOperacaoCredito;
    private Long numeroFichaContabil;

    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Integer numeroCheque;
    private String cmc7;
    private Boolean isCpfCnpjRemetenteEqualsCheque;

    @LogValorTransacao
    private BigDecimal valor;
    
    private Long numeroProtocolo;
    private BigDecimal valorTarifa;
    
    private String identificadorDeposito;
    private String numeroProcesso;
    private Long codigoAreaDemandanteFicha;
    private String areaDemandanteFicha;
    private String nomeBancoCredito;
    
    private String matriculaSupervisor;

    private Integer numeroTerminal;
    private Integer idAlvara;
    private Long cpfCnpjBeneficiario;
    private String nomeBeneficiario;
    private String tipoPessoaRemetente;
    private String nomeRemetente;
    private Integer bancoDestino;
    private Integer tipoContaCreditada;
    private Integer agenciaDestino;
    private Long contaDestino;
    private Long cpfCnpjFavorecido;
    private String nomeFavorecido;
    private BigDecimal valorTed;
    private Boolean indicadorTransferencia;
    private Boolean indicadorMesmaTitularidade;
    private Integer tctCod;

    private EnumFinalidadeTEDFichaContabil finalidadeFichaContabil;
    
}
package br.com.brb.cix.domain.model.beneficioeventual;

import java.util.List;

import br.com.brb.cix.dto.ConsultaBeneficioEventualDTO;

/**
 * @author u653865
 *
 */
public interface BeneficioEventualRepositoryCustom {

    /**
     * @param filtro
     * @return
     */
	List<ConsultaBeneficioEventualDTO> consultarPorModulo(Integer codigoModulo);
	
}

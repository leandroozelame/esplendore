package br.com.brb.cix.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Data
@Getter
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaixaEnvelopeDepositoDTO extends AbstractDTO{
    
    private Integer codigoSeguranca;
    private Long codigoBarrasEnvelope;
    private Long nsuLog;
    

}

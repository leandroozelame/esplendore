package br.com.brb.cix.dto;

import java.util.List;

import br.com.brb.cix.ws.consulta.dto.OperacaoPosicaoCaixa;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultaColetaDocumentoDTO {
    private String terminal;
    private String operador;
    private Integer agencia;
    private List<OperacaoPosicaoCaixa> operacoes;
   
}
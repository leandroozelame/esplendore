package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AutorizacaoDTO {
    private Long codigo;
    private String motivoRejeicao;
    private String senhaAlcada;
    private String matricula;

    public AutorizacaoDTO() {
        super();
    }
}
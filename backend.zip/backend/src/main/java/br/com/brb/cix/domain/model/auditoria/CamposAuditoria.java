/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.auditoria;

import br.com.brb.cix.auditoria.EnumSituacaoExecucao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumCanal;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 *
 * @author u842773
 */
interface CamposInspetoria {
    
    Long getId();
    LocalDateTime getDataOperacao();
    Integer getNrTerminal();
    String getIp();
    String getServidor();
    Integer getCdResposta();
    String getOperador();
    String getAgenciaOperador();
    String getNomeOperador();
    Long getCodigoUnidadeOperador();
    String getDescricaoUnidadeOperador();
    List<SupervisorLogAuditoria> getSupervisores();
    String getCpfCliente();
    String getNomeCliente();
    EnumTipoConta getTpConta();
    String getConta();
    BigDecimal getVlOperacao();
    Integer getCdTransacao();
    String getNomeTransacao();
    EnumCanal getNrCanal();
    String getFuncionalidade();
    Integer getCdNsuCanal();
    Long getCdNsuAutorizacao();
    Integer getCdNsuLog();
    String getMensagem();
    EnumSituacaoExecucao getSituacaoExecucao();
}
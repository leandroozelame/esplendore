package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class VendaMoedaEstrangeiraDTO extends ContaTipoDTO {
    
    private EnumFormaMovimentacao formaMovimentacao;
    private String tipoMoeda;
    private String simbolo;
    private BigDecimal quantidade;
    private BigDecimal valorMoedaNacional;
    private BigDecimal valorIOF;
    private Long numeroProtocolo;
    private BigDecimal valorTarifa;
    @LogValorTransacao
    private BigDecimal valorTotal;
    
    private Integer numeroCheque;
    private String cmc7;
    private String matriculaSupervisor;
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private Long numeroFichaContabil;
    private PendenciaDTO pendencia;
    private Long numeroContaCheque;
    
    @LogValorTransacao
    private BigDecimal valorChequeBRB = BigDecimal.ZERO;
    private EnumTipoModalidade modalidadeDeConta;    
}

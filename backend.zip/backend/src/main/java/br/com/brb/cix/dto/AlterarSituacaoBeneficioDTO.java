package br.com.brb.cix.dto;

import br.com.brb.cix.enums.EnumSituacaoBeneficio;
import br.com.brb.cix.enums.EnumTipoBeneficio;
import java.math.BigDecimal;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlterarSituacaoBeneficioDTO extends AbstractDTO {
    private Long agencia;
    private Long numeroBeneficio;
    private EnumTipoBeneficio tipoBeneficio;
    private EnumSituacaoBeneficio situacaoBeneficio;
    private BigDecimal saldoBeneficio;
}
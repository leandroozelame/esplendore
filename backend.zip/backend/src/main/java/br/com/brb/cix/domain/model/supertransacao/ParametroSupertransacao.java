package br.com.brb.cix.domain.model.supertransacao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.util.SimNaoConverter;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_SUPERTRANSACAO")
public class ParametroSupertransacao  {

	private static final long serialVersionUID = -4334084608248647940L;

	@Id
	@SequenceGenerator(name = "sequence_supertransacao", sequenceName = "SQ_SUPERTRANSACAO", allocationSize = 1)
	@GeneratedValue(generator = "sequence_supertransacao")
	@Column(name = "SQ_SUPERTRANSACAO")
	private Long id;
	
	@Column(name = "CD_MODULO")
	private Integer modulo;
	
	@ManyToOne
	@JoinColumn(name = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;
	
	@Column(name = "DT_CRIACAO")
	private Date dataCriacao;
	
	@Column(name = "DT_ALTERACAO")
	private Date dataAlteracao;
	
	@Convert(converter = SimNaoConverter.class)
	@Column(name = "ST_ATIVO")
	private Boolean habilitado;
	
	@JsonManagedReference
    @ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
    @Fetch(FetchMode.SUBSELECT)
    @JoinTable(name = "TB_SUPERTRANSACAO_FUNC",
            joinColumns = @JoinColumn(name = "SQ_SUPERTRANSACAO", referencedColumnName = "SQ_SUPERTRANSACAO"),
            inverseJoinColumns = @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE"))
    private List<Funcionalidade> funcionalidades;
	
	public ParametroSupertransacao() {
		super();
		dataCriacao = new Date();
		funcionalidades = new ArrayList<Funcionalidade>();
	}
	
	public ParametroSupertransacao(Integer modulo, FormaPagamento formaPagamento, List<Funcionalidade> funcionalidades) {
		super();
		this.modulo = modulo;
		this.formaPagamento = formaPagamento;
		this.funcionalidades = funcionalidades;
		this.dataCriacao = new Date();
		this.habilitado = true;
	}
}

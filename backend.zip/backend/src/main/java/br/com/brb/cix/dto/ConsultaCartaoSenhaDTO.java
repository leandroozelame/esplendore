package br.com.brb.cix.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class ConsultaCartaoSenhaDTO {
    private String numeroCartao;
    private String senhaCartao;
    private Integer codigoAgencia;
    private Long numeroConta;
    private Integer tipoConta;
    private Integer ordemTitular;
}
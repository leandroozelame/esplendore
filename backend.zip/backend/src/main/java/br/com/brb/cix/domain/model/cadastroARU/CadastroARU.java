package br.com.brb.cix.domain.model.cadastroARU;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.modulo.Modulo;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u660977
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "TB_ARRECADACAO_UNICA")
public class CadastroARU  {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "cadastro_aru_sequence", sequenceName = "SQ_ARRECADACAO_UNICA", allocationSize = 1)
    @GeneratedValue(generator = "cadastro_aru_sequence")
    @Column(name = "SQ_ARRECADACAO_UNICA", nullable = false)
    private Long codigo;

    @Column(name = "NR_CONTRATO", nullable = false)
    private Integer numeroContrato;
    
    @ManyToOne
    @JoinColumn(name = "CD_MODULO")
    private Modulo modulo;
    
    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;

    @Column(name = "ST_ATIVO")
    private Boolean ativo;
}
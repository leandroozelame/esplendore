package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TerminaisAbertosDTO {

    private String terminal;
    
    private Long cdNsuAutorizacao;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((cdNsuAutorizacao == null) ? 0 : cdNsuAutorizacao.hashCode());
        result = prime * result + ((terminal == null) ? 0 : terminal.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TerminaisAbertosDTO other = (TerminaisAbertosDTO) obj;
        if (cdNsuAutorizacao == null) {
            if (other.cdNsuAutorizacao != null)
                return false;
        } else if (!cdNsuAutorizacao.equals(other.cdNsuAutorizacao))
            return false;
        if (terminal == null) {
            if (other.terminal != null)
                return false;
        } else if (!terminal.equals(other.terminal))
            return false;
        return true;
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.informacaocaixa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.terminal.Terminal;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@Entity
@Getter
@Setter
@Table(name = "TB_INFO_CAIXA")
public class InformacaoCaixa {

    @SequenceGenerator(name = "infocaixa_sequence", sequenceName = "SQ_INFO_CAIXA", allocationSize = 1)
    @GeneratedValue(generator = "infocaixa_sequence")
    @Column(name = "SQ_INFO_CAIXA")
    @Id
    private Long codigo;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_TERMINAL", nullable = false)
    private Terminal terminal;

    // Diferentemente da auditoria, esta matricula está como numero para facilitar as consultas
    @Column(name = "NR_MATRICULA_OPERADOR")
    private Long matriculaOperador;

}

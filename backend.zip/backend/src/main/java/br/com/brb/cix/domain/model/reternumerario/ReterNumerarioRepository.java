package br.com.brb.cix.domain.model.reternumerario;

import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReterNumerarioRepository extends JpaRepository<ReterNumerario, Long> {
    
    @Query(value = " SELECT * FROM {h-schema}TB_NUMERARIO_RETIDO r "
            + "WHERE r.CD_UNIDADE = ?1 "
            + "AND (r.DT_RETENCAO > ?2 AND r.DT_RETENCAO < ?3) "
            + "AND r.ST_ATIVO = 1", nativeQuery = true)
    List<ReterNumerario> listaValoresRetidofindByNumeroUnidade(Long codigoUnidade, Date dataInicial, Date dataFinal);
	
	ReterNumerario findByCodigo(Long codigo);
}

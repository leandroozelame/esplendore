package br.com.brb.cix.config;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider.ColumnNames;

/**
 * Classe que configura o mecanismo de lock para agendamentos feitos usando a
 * anotação {@code @Scheduled} do Spring.
 * 
 * <p>
 * Para mais informações sobre configuração, acessar o link:
 * 
 * <p>
 * <a href="https://github.com/lukas-krecan/ShedLock">https://github.com/lukas-krecan/ShedLock</a>
 * 
 * @author u653949
 */
@Configuration
public class SchedulerConfig {

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(
                JdbcTemplateLockProvider.Configuration.builder()
                    .withTableName("CIX.TB_AGENDAMENTO_TAREFA")
                    .withColumnNames(new ColumnNames("NO_TAREFA", "DT_TERMINO", "DT_INICIO", "NO_SERVIDOR"))
                    .withJdbcTemplate(new JdbcTemplate(dataSource))
                    .build());
    }
}

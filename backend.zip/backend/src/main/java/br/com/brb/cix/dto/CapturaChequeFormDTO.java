package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Data
@Getter
@EqualsAndHashCode(callSuper = false)
public class CapturaChequeFormDTO extends AbstractDTO {

    private String nrConta;
    @LogValorTransacao
    private BigDecimal subTotal;
    private Integer quantidade;
    private BigDecimal informado;
    private String funcionalidade;
    private List<ChequeRecebidoDTO> cheques = new ArrayList<>();
}

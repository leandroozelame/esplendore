/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 * @author u842773
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DadosCorrentistaDTO {
    private Integer ordemConta;
    private String nomeCorrentista;
    private double cpf;
    private double cnpj;
}
package br.com.brb.cix.domain.model.beneficioeventual;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


public interface BeneficioEventualRepository extends JpaRepository<BeneficioEventual, Long> {

	@Override
	@SuppressWarnings("unchecked")
	BeneficioEventual save(BeneficioEventual beneficio);
	
	List<BeneficioEventual> findByCodigoModuloAndSituacao(int codigoModulo, int situacao);
    	
}

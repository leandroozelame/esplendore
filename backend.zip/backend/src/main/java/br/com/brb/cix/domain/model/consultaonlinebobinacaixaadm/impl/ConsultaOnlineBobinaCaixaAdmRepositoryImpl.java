package br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm.impl;

import java.sql.Clob;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm.ConsultaOnlineBobinaCaixaAdm;
import br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm.ConsultaOnlineBobinaCaixaAdmRepositoryCustom;
import br.com.brb.cix.util.ObjectUtil;
import br.com.brb.cix.util.SqlUtil;
import lombok.Getter;

@Repository
public class ConsultaOnlineBobinaCaixaAdmRepositoryImpl implements ConsultaOnlineBobinaCaixaAdmRepositoryCustom {
    @Getter
    private final EntityManager em;
    @Autowired
    public ConsultaOnlineBobinaCaixaAdmRepositoryImpl(EntityManager em) {this.em = em;}

	@Override
	public List<ConsultaOnlineBobinaCaixaAdm> buscaPorBobinasDoDiaCorrente(Integer codigoModulo, Long codigoUnidade) {
		Query query = em.createNativeQuery(retornarSQL());
		
		query.setParameter("modulo", codigoModulo);
		query.setParameter("unidade", codigoUnidade);
		
		@SuppressWarnings("unchecked")
		List<Object[]> lista = query.getResultList();
		
		return ObjectUtil.isNull(lista) ? new ArrayList<ConsultaOnlineBobinaCaixaAdm>()
                : lista.stream().map(i -> new ConsultaOnlineBobinaCaixaAdm(
                								SqlUtil.toLong(i[0]), 
                								//SqlUtil.toString(i[1]),
                								getClob(i[1]),
                								SqlUtil.toLong(i[2]),
                								SqlUtil.toString(i[3]), 
                								SqlUtil.toString(i[4]))).collect(Collectors.toList());
	}
	
	private Clob getClob(Object obj) {
		Clob clob = (Clob) obj;

		return clob;
	}
	
	private String retornarSQL() {
		StringBuilder sql = new StringBuilder();

		sql.append("SELECT                             	");
		sql.append("    b.sq_bobina,         			");
		sql.append("    b.tx_bobina,                    ");
		sql.append("    b.nr_matricula_operador,        ");
		sql.append("    t.nr_terminal,                  ");
		sql.append("    o.oprnom                   		");
		sql.append("from cix.tb_bobina b  				");
		sql.append("inner join cix.TB_TERMINAL t on		");
		sql.append("	b.sq_terminal = t.sq_terminal	");
		sql.append("inner join CIX.tb_modulo m on		");
		sql.append("	m.cd_modulo = t.cd_modulo		");
		sql.append("inner join cix.VW_UND u  on			");
		sql.append("	u.UNDCOD = t.cd_unidade			");
		sql.append("inner join cix.VW_OPR o on			");
		sql.append("	o.oprmat = to_char (b.nr_matricula_operador) ");
		sql.append("WHERE 	                   	        ");
		sql.append("t.cd_modulo = :modulo and			");
		sql.append("length(b.tx_bobina) > 1 and			");
		sql.append("t.cd_unidade = :unidade and			");
		sql.append("b.dt_abertura_bobina > to_date(CURRENT_DATE)");
		return sql.toString();
	}
}

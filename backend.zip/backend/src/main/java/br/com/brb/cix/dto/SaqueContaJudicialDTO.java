package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaqueContaJudicialDTO extends AbstractDTO {

    private Long terminal;
    private Long cpfCnpj;
    private String nomeBeneficiario;
    @LogValorTransacao
    private BigDecimal saldo;
    private Integer alvara;
    private Integer ptaOrigem;
    private String tipoPessoa;
    private Integer tpPessoa;
    private EnumFormaMovimentacao formaMovimentacao;

    private PendenciaDTO pendencia;
}

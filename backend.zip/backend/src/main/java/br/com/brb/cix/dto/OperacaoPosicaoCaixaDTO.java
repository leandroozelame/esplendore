package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OperacaoPosicaoCaixaDTO {
    
	private Integer quantidade;
	private String quantidadeFormatada;
	private String descricao;
    private BigDecimal valorTotal;
    private String valorFormatado;
}

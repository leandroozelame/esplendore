package br.com.brb.cix.domain.model.grupo;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.brb.cix.domain.model.perfil.Perfil;
import br.com.brb.cix.dto.GrupoDTO;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Immutable
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Table(name = "VW_GRUPO")
public class Grupo  {
    private static final long serialVersionUID = -7884383952009631329L;

    @Column(name = "GRPCOD")
    @Id
    private Long codigo;

    @Column(name = "GRPDSC")
    private String nome;

    @Column(name = "GRPOBS")
    private String descricao;

    @Column(name = "GRPSIT")
    private Integer ativo;

    @Column(name = "PFLSEQ")
    private Integer perfil;

    @Column(name = "GRPDATCAD")
    private Date dataCriacao;

    @Column(name = "GRPDATALT")
    private Date dataAlteracao;

    @JsonBackReference
    @ManyToMany(mappedBy = "listaGrupos")
    private List<Perfil> listaPerfis;

    public Grupo(GrupoDTO grupo) {
        super();
        codigo = grupo.getCodigo();
        nome = grupo.getNome();
    }

}

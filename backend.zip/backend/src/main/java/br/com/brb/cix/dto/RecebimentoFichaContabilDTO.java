package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.config.jackson.DateOnlySerializer;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RecebimentoFichaContabilDTO extends ContaTipoDTO {
    @JsonProperty(access = Access.WRITE_ONLY)
    private Long codigoTransacao;

    private String nomeTitular;
	private Integer ordemTitular;

    private Long numeroFichaContabil;

    @LogValorTransacao
    private BigDecimal valorTransacao;

    private EnumFormaMovimentacao formaMovimentacao;

    //Cheque
    private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
    private String cmc7;
    private Integer nrAgencia;
    private Long nrContaCredito;
    private String numeroCheque;
    private Long numeroContaCheque;

    private String numeroDocumento;
    @JsonSerialize(using = DateOnlySerializer.class)
    private Date dataDocumento;
}

package br.com.brb.cix.auditoria;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;

import br.com.brb.cix.util.CixUtil;
import com.fasterxml.jackson.annotation.JsonProperty;

import br.com.brb.cix.config.jackson.JacksonConfig;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumCanal;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.json.JSONObject;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuditoriaDTO {

    private Long id;

    private LocalDateTime dataOperacao;

    public String getData() {
        return dataOperacao.format(JacksonConfig.DATE_FORMATTER);
    }

    public String getHorario() {
        return dataOperacao.format(JacksonConfig.TIME_FORMATTER);
    }

    private Integer nrTerminal;

    private String ip;

    private String servidor;

    @JsonProperty("requisicao")
    private LinkedHashMap<String, Object> mapaParametroEntrada;

    @JsonProperty("resposta")
    private LinkedHashMap<String, Object> mapaParametrosSaida;

    private Integer cdResposta;

    private String operador;

    private String agenciaOperador;

    private String nomeOperador;

    private Long codigoUnidadeOperador;

    private String descricaoUnidadeOperador;

    private String cpfCliente;

    private String nomeCliente;

    private EnumTipoConta tpConta;

    private String conta;

    private List<SupervisorLogAuditoriaDTO> supervisores;

    @JsonProperty("valorOperacao")
    private BigDecimal vlOperacao;

    private Integer cdTransacao;

    private String nomeTransacao;

    private EnumCanal nrCanal;

    private String funcionalidade;

    private Integer cdNsuCanal;

    private Long cdNsuAutorizacao;

    private Integer cdNsuLog;

    private String mensagem;
    
    private String evento;

    private EnumSituacaoExecucao situacaoExecucao;

    private String valorParticao;

    public String getConta() {
        return CixUtil.formataConta(conta);
    }
}
package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumCanal implements EnumDominio{
	NENHUM(-1, "NENHUM", ""),
	ADM(0, "ADM", ""),
	ATB(1, "ATB - Caixa", ""),
	ATC(2, "ATC - Correspondente", ""),
	BKT(3, "BKT - Banknet antigo", ""),
	CIX(5, "CIX - Caixa", "CIX-ATB"), 
	AUB(6, "AUB - Video", "CIX-AUB"),
	ABA_VIDEO(999, "ABA - Video", "ABA-VIDEO"),
	MASTERCARD(7, "Mastercard", ""),
	VISAELECT(8, "Visa Electron", ""),
	CIXC(9, "CIX - Correspondente", "CIX-ATC"),
	BANCO24H(10, "Banco 24h", ""),
	REDCPR(11, "Rede Compartilhada", ""),
	CHLCOMPRA(12, "Cheque Eletronico - Compra", ""),
	CHLCONTA(13, "Cheque Eletronico - Pag. Contas", ""),
	CIRRUSNAC(14, "Cirrus Nacional", ""),
	CIRRUSIAC(15, "Cirrus Internacional", ""),
	CIX_ADM(16, "CIX - Administrativo", "CIX-ADM"),
	DFC(17, "DFC", ""),
	DFC_AGENCIA_VIRTUAL(18, "DFC - Agencia Virtual", ""),
	IBK(19, "Banknet", ""),
	NETBNK_ADM(20, "IBK - Administrativo", ""),
	MYB(21, "Telebanco", ""),
	BANKLINK_AUTOJUD(24, "Banklink Autojud", ""),
	SGB(30, "SGB", ""),
	TECBAN_BANCO24H_FRANQUIA(33, "Tecban Banco 24h Franquia", ""),
	HRX_HOST(34, "HRX Host", ""),
	CWS(38, "CWS", ""),	
	BANCO_DO_BRASIL(39, "Banco do Brasil", ""),
	FIDELITY(40, "Fidelity", ""),	
	ATM(41, "Autoatendimento", ""),
	BRB_NACAO(42, "Nação BRB", ""),
	PERTO_TTS(45, "Perto TTS", ""),
	VISA_PLUS_NACIONAL(46, "Visa Plus Nacional", ""),
	VISA_PLUS_INTERNACIONAL(47, "Visa Plus Internacional", ""),
	VISA_ELECTRON_INTERNACIONAL(48, "Visa Electron Internacional", ""),
	VISA_ELECTRON_NACIONAL(49, "Visa Electron Nacional", ""),
	MBK(52, "Mobile", ""),
	SAT(53, "SAT", ""),
	HRX(54, "Redes Externas", ""),
	PERMESSO(55, "Permesso", ""),	
	APB(56, "APB", ""),
	MAF(57, "MAF", ""),
	ACO(58, "ACO", ""),
	HCC(60, "HCC", ""),
	CIX_POS(64, "CIX - POS", ""),
	AUT(65, "AUT - Alta plataforma", ""),
	OBK(80, "Open Banking", ""),
	TLB_ADM(81, "Telebanco Administrativo", ""),
	NBKADM(82, "NextBank Administrativo", ""),	
	SAF(83, "SAF", ""),
	GPI(84, "GPI", ""),
	SDJ(85, "SDJ", ""),
	DTE(90, "DTE", ""),
	CONTA_ZAP(91, "Conta Zap", "");

	@Getter
	private final Integer codigo;

	@Getter
	private final String descricao;
	
	@Getter
	private final String descricaoResumida;

	private static final Map<Integer, EnumCanal> MAP_ENUMCANAL = new ConcurrentHashMap<>();

	static {
		for (EnumCanal e : EnumCanal.values()) {
			MAP_ENUMCANAL.put(e.getCodigo(), e);
		}
	}

	@JsonCreator	
	public static EnumCanal get(int codigo) {
		return MAP_ENUMCANAL.get(codigo);
	}
	
	@Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
}
package br.com.brb.cix.alcada;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import br.com.brb.cix.ws.consulta.dto.InformacaoConta;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class DadosTransacao {
    private Long conta;
    private InformacaoConta informacaoConta;
    private BigDecimal valor;
    private Boolean contaDebito;
    private EnumFormaMovimentacao formaMovimentacao;
    private Boolean semSenha;
}
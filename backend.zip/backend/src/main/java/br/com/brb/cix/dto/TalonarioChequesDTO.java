package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.enums.EnumTipoTalao;
import br.com.brb.cix.enums.EnumTipoTarifa;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TalonarioChequesDTO extends ContaTipoDTO {
	private Boolean requisicaoAvulsa;
    private EnumTipoTalao tipoTalao;
    private Integer serie;
    private Integer quantidade;
    private Long numeroPrimeiroCheque;
    private Long numeroUltimoCheque;
    private String documentoIdentificacao;
    private Date dataDocumento;
    private EnumTipoTarifa tipoTarifa;
    private Long protocoloTarifa;
    private BigDecimal valorTarifa;
}
package br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm;

import java.util.List;

/**
 * @author u653865
 *
 */
public interface ConsultaOnlineBobinaCaixaAdmRepositoryCustom {

    /**
     * @param filtro
     * @return
     */
	List<ConsultaOnlineBobinaCaixaAdm> buscaPorBobinasDoDiaCorrente(Integer codigoModulo, Long codigoUnidade);
	
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumCodigoFundo;
import br.com.brb.cix.domain.model.enums.EnumTipoBloqueio;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class BloqueioContaValorDTO extends AbstractDTO {
    private Integer agencia;
    private Long conta;
    private String nome;
    private EnumTipoConta tipoConta;
    private EnumTipoModalidade modalidade;
    private EnumTipoBloqueio tipoBloqueio;
    private EnumCodigoFundo codigoFundo;
    private Long cpf;
    private Long numeroSolicitacao;
    @LogValorTransacao
    private BigDecimal valorBloqueioDesbloqueio;
}
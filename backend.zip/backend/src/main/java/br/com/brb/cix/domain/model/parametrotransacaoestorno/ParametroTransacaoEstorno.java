package br.com.brb.cix.domain.model.parametrotransacaoestorno;

import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.funcionalidade.Funcionalidade;
import br.com.brb.cix.util.ConvertCharToBoolean;
import br.com.brb.cix.util.HoraConvert;
import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import java.math.BigDecimal;

/**
 * @author u662999
 *
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "TB_PARAMETRIZAR_ESTORNO")
public class ParametroTransacaoEstorno  {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "parametrizar_estorno_sequence", sequenceName = "SQ_PARAMETRIZAR_ESTORNO", allocationSize = 1)
    @GeneratedValue(generator = "parametrizar_estorno_sequence")
    @Column(name = "SQ_PARAMETRIZAR_ESTORNO")
    private Long codigo;

    @Column(name = "CD_MODULO")
    private Integer modulo;

    @JsonBackReference(value = "funcionalidade")
    @ManyToOne(fetch = FetchType.EAGER, optional = true)
    @JoinColumn(name = "SQ_FUNCIONALIDADE", referencedColumnName = "SQ_FUNCIONALIDADE", nullable = true)
    private Funcionalidade funcionalidade;

    @JsonBackReference(value = "formaPagamento")
    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO", referencedColumnName = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;
    
    @Convert(converter = HoraConvert.class)
    @Column(name = "HR_LIMITE_ESTORNO")
    private String horaLimiteEstorno;
    
    @Column(name = "VL_ESTORNO")
    private BigDecimal valorEstorno;
    
    @Column(name = "VL_LIMITE_ESTORNO")
    private BigDecimal valorLimiteEstorno;
    
    @Column(name = "VL_MIN_ESTORNO")
    private BigDecimal valorMinimoEstorno;
    
    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_TRANSACAO_ESTORNO")
    private boolean statusTransacaoEstorno;
    
}

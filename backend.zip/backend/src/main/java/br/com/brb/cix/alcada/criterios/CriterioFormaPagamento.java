package br.com.brb.cix.alcada.criterios;

import br.com.brb.cix.alcada.DadosTransacao;
import br.com.brb.cix.domain.model.regra.Regra;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CriterioFormaPagamento implements CriterioAlcada {
    @Override
    public String getNomeCriterio() {
        return "Forma de Pagamento";
    }

    @Override
    public boolean isCriterioDesabilitado(Regra regra) {
        return EnumFormaMovimentacao.INDIFERENTE.equals(regra.getFormaPagamento());
    }

    @Override
    public boolean isCriterioAtingido(Regra regra, DadosTransacao dadosTransacao) {
        EnumFormaMovimentacao formaMovimentacao = dadosTransacao.getFormaMovimentacao();

        if (formaMovimentacao == null) {
            log.debug("formaMovimentacao: {}", formaMovimentacao);
            return false;
        }

        EnumFormaMovimentacao regraFormaPagamento = regra.getFormaPagamento();
        log.debug("regraFormaPagamento: {}, formaMovimentacao: {}", regraFormaPagamento, formaMovimentacao);

        return regraFormaPagamento.getCodigo().equals(formaMovimentacao.getCodigo());
    }
}

package br.com.brb.cix.auditoria;

@SuppressWarnings("serial")
public class ExecutorAuditoriaException extends RuntimeException{

	public ExecutorAuditoriaException(Throwable cause) {
        super(cause.getMessage(), cause);
    }
	
	public ExecutorAuditoriaException(String message, Throwable cause) {
        super(message, cause);
    }
	
}

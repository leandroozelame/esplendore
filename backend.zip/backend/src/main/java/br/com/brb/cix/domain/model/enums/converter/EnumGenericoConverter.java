package br.com.brb.cix.domain.model.enums.converter;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.TypeDescriptor;
import org.springframework.core.convert.converter.GenericConverter;
import org.springframework.util.NumberUtils;

import com.google.common.collect.ImmutableSet;

import br.com.brb.cix.domain.model.enums.EnumDominio;

/**
 * Classe que converte enums mapeados no @PathVariable das classes @RestController
 * São aceitos enums que implementam a interface EnumDominio
 * A conversão pode ser realizada a partir do codigo ou pelo toString do enum
 * 
 * @author u844902
 *
 */
public class EnumGenericoConverter implements GenericConverter {

	@Override
	public Set<ConvertiblePair> getConvertibleTypes () {

		ConvertiblePair[] pairs = new ConvertiblePair[] {
				new ConvertiblePair(Number.class, Enum.class),
				new ConvertiblePair(String.class, Enum.class)};

		return ImmutableSet.copyOf(pairs);
	}

	@Override
	public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {

		Object target = null;

		if (sourceType.getType() == Enum.class) {
			return source;
		}
		if(sourceType.getType() == String.class) {
			String sourceString = (String) source;

			if(StringUtils.isNumeric(sourceString)){
				Integer sourceInteger = NumberUtils.parseNumber(sourceString, Integer.class);
				target = getEnumByCodigo(targetType, sourceInteger);
			}else {
				target = getEnumByString(targetType, sourceString);
			}
		} else if(sourceType.getType() == Number.class){
			target =  getEnumByCodigo(targetType, (Integer) source);
		}

		if(target == null) {
			throw new RuntimeException("Nenhum enum encontrado com o source informado: " + source);
		}

		return target;
	}

	private Enum<?> getEnumByCodigo(TypeDescriptor targetType, Integer codigo) {
		if(isEnumAndDominio(targetType)) {
			@SuppressWarnings("unchecked")
			List<EnumDominio> listaValoresDominio = (List<EnumDominio>) Arrays.asList(targetType.getType().getEnumConstants());
			for (EnumDominio enumDominio : listaValoresDominio) {
				if(enumDominio.getCodigo().equals(codigo)) {
					return (Enum<?>) enumDominio;
				}
			}
		}
		return null;
	}

	private Enum<?> getEnumByString(TypeDescriptor targetType, String toString) {
		if(isEnumAndDominio(targetType)) {
			@SuppressWarnings("unchecked")
			List<EnumDominio> listaValoresDominio = (List<EnumDominio>) Arrays.asList(targetType.getType().getEnumConstants());
			for (EnumDominio enumDominio : listaValoresDominio) {
				if(enumDominio.toString().equals(toString)) {
					return (Enum<?>) enumDominio;
				}
			}
		}
		return null;
	}

	private boolean isEnumAndDominio(TypeDescriptor targetType) {
		return Enum.class.isAssignableFrom(targetType.getType()) && EnumDominio.class.isAssignableFrom(targetType.getType());
	}
}


package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.domain.model.auditoria.Auditoria;
import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.resumotransacao.ResumoTransacao;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class EstornoDTO {

    private Long nsuTransacao;
    private Long codigoFuncionalidade;
    private String nomeFuncionalidade;
    private Long numeroFuncionalidade;
    private EstornoFormaMovimentacaoDTO formaMovimentacao;
    private Integer agenciaConta;
    private Integer codigoBanco;
    private Long codigoTransacao;
    private Date dataHoraGravacaoLog;
    private Date dataReferenciaLog;
    private Long nsuGeralLog;
    private Long nsuOrigem;
    private Long numeroConta;
    private String particao;
    private int tipoParticao;
    private Integer tipoConta;
    private BigDecimal valorLog;
    private BigDecimal valorTransacao;
    private Integer nsuAut;
    private String cmc7;
    
    @JsonIgnore
    private Auditoria auditoria;
    @JsonIgnore
    private ResumoTransacao resumoTransacao;
}

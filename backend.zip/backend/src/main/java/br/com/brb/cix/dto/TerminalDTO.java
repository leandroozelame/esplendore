package br.com.brb.cix.dto;

import java.io.Serializable;

import lombok.Data;

@Data
public class TerminalDTO implements Serializable {

	private static final long serialVersionUID = -8514154117720942161L;
	
	private Long codigo;
    private String ipTerminal;
    private String ipTerminal2;
    private Integer numeroTerminal;
    private Character caixa;
    private Character ativo;
    private Long codigoUnidade;
    private String nomeUnidade;
    private String tipoTerminal;
    private Integer modulo;

    public TerminalDTO() {
        super();
    }
}
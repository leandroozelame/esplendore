package br.com.brb.cix.dto;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class ConsultaOrdemBancariaDTO extends AbstractDTO {
    protected Date data;
    private Long contaDebito;
    private Long contaCredito;
    private String numeroOB;
}
package br.com.brb.cix.domain.model.atendimentotransacao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AtendimentoTransacaoRepository extends JpaRepository<AtendimentoTransacao, Long> {
    AtendimentoTransacao findByCodigo(Long codigo);
}
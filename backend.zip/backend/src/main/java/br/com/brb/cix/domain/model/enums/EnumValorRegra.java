package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumValorRegra implements EnumDominio {
    NAO('0', "Não"),
    SIM('1', "Sim"),
    INDIFERENTE('9', "Indiferente");

    private static final Map<Character, EnumValorRegra> MAP = new HashMap<>();

    @Getter
    private Character codigo;
    @Getter
    private String descricao;

    static {
        for (EnumValorRegra e : EnumValorRegra.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumValorRegra get(Character codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumValorRegra criaEnum(Object tipo) {
        EnumValorRegra retorno = null;
        if ((Character.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumValorRegra criaEnumString(String descricao) {
        EnumValorRegra retorno = null;
        Iterator<Map.Entry<Character, EnumValorRegra>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Character, EnumValorRegra> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao) || par.getKey().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

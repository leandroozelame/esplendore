package br.com.brb.cix.domain.model.parametrocanal;

import br.com.brb.cix.domain.model.funcionalidadeformapagamento.FuncionalidadeFormaPagamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ParametroCanalRepository extends JpaRepository<ParametroCanal, Long> {
    ParametroCanal findByParametro(String parametro);

    List<ParametroCanal> findByCodigoSecao(Integer codigoSecao);

    @SuppressWarnings("unchecked")
    ParametroCanal save(ParametroCanal parametroCanal);

    @Query(nativeQuery = true, value = "SELECT TPC.* FROM {h-schema}TB_PARAMETRO_CANAL TPC " +
            "WHERE CD_SECAO = :cdSecao " +
            "AND ST_ATIVO = 1 " +
            "ORDER BY " +
            "CASE " +
            "WHEN REGEXP_LIKE(SUBSTR(TPC.NO_PARAMETRO, 1, 2), '^\\d+$') " +
            "THEN TO_NUMBER(SUBSTR(TPC.NO_PARAMETRO, 1, 2)) " +
            "ELSE NULL " +
            "END")
    List<ParametroCanal> findByCodigoSecaoOrdenadoPorNome(@Param("cdSecao") Integer cdSecao);
}

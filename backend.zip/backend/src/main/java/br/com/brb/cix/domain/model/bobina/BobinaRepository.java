package br.com.brb.cix.domain.model.bobina;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;

public interface BobinaRepository extends JpaRepository<Bobina, Long> {
    Bobina findByCodigo(Long codigo);

    @Query(value = "Select bobina " +
                    "from Bobina as bobina " +
                    "where bobina.terminal.numeroTerminal = ?1 " +
                    "and bobina.matriculaOperador = ?2 " +
                    "and bobina.terminal.codigoUnidade = ?3 " +
                    "and bobina.dataFechamento IS NULL ")
    List<Bobina> buscaPorTerminalMatriculaPtaLista(Integer nrTerminal, Long nrMatricula, Long nrUnidade);

    @Query(value = "Select bobina " +
            "from Bobina as bobina " +
            "where bobina.terminal.numeroTerminal = ?1 " +
            "and bobina.matriculaOperador = ?2 " +
            "and bobina.terminal.codigoUnidade = ?3 " +
            "and bobina.dataFechamento IS NULL ")
    Bobina buscaPorTerminalMatriculaPta(Integer nrTerminal, Long nrMatricula, Long nrUnidade);

    /**
     * @return
     */
    @Query(value = "Select b "
            + "from Bobina b "
            + "where b.dataFechamento IS NULL "
            + "and b.terminal.codigoUnidade = ?1 " 
            + "and b.terminal.numeroTerminal = ?2 "
            + "and b.matriculaOperador = ?3")
    Bobina buscarBobinaNaoFechada(Long codigoUnidade, Integer numeroTerminal, Long numeroMatricula);

    List<Bobina> findAllByDataAberturaBetween(Date dataInicial, Date dataFinal);
    
    @Query(value = "Select b from Bobina b "
            + "where b.codigo = (select max(b2.codigo) "
            + "from Bobina b2 "
            + "where b2.dataFechamento IS NULL "
            + "and b2.terminal.numeroTerminal = ?1 " 
            + "and b2.terminal.codigoUnidade = ?2)")
    Bobina buscarUltimaBobinaNaoFechadaTerminal(Integer nrTerminal, Long cdUnidade);
}

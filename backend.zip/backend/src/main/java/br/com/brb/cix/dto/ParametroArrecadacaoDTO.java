package br.com.brb.cix.dto;

import javax.xml.bind.annotation.XmlSchemaType;

import br.com.brb.cix.ws.consulta.dto.EnumSimNao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class ParametroArrecadacaoDTO {

    private Integer numeroContrato;
    private String descricaoContrato;
    private Integer codigoReceita;
    private String grupoArr;
    @XmlSchemaType(name = "string")
    private EnumSimNao indicadorUsoCodigoBarra;
    
}

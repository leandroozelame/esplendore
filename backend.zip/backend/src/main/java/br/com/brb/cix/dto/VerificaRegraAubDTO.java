package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class VerificaRegraAubDTO {
    private Integer codigoMenuFuncionalidade; 
    private List<Long> contasOrigem;
    private List<Long> contasDestino;
    private BigDecimal valor;
    private Boolean semSenha;
}
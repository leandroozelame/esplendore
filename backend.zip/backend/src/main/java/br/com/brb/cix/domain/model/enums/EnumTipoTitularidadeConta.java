package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoTitularidadeConta implements EnumDominio{
    INDIVIDUAL(1, "Individual"), 
    CONJUNTA_SOLIDARIA(2, "Conjunta Solidária"),
    CONJUNTA_NAO_SOLIDARIA(3, "Conjunta não Solidária"),
    UNICA_BLOQUEADA(8, "Única Bloqueada"); 

    private static final Map<Integer, EnumTipoTitularidadeConta> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoTitularidadeConta e : EnumTipoTitularidadeConta.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoTitularidadeConta get(int codigo) {
        return MAP.get(codigo);
    }
    
    public static EnumTipoTitularidadeConta criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @JsonCreator
    public static EnumTipoTitularidadeConta criaEnum(String descricao) {
        EnumTipoTitularidadeConta retorno = null;
        Iterator<Map.Entry<Integer, EnumTipoTitularidadeConta>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumTipoTitularidadeConta> par = it.next();
            if(par.getValue().toString().equalsIgnoreCase(descricao)){
                retorno = par.getValue();
            }
        }
        return retorno;
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
package br.com.brb.cix.domain.model.tipocampopld;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.brb.cix.domain.model.parametropld.ParametroPld;
import br.com.brb.cix.util.SimNaoConverter;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "TB_TIPO_CAMPO_PLD")
public class TipoCampoPld  {
    private static final long serialVersionUID = 1L;
    
    @Id
    @Column(name = "SQ_TIPO_CAMPO_PLD")
    @SequenceGenerator(name = "tipo_campo_pld_sequence", sequenceName = "SQ_TIPO_CAMPO_PLD", allocationSize = 1)
    @GeneratedValue(generator = "tipo_campo_pld_sequence")
    private Long codigo;
    
    @Column(name = "NO_CAMPO")
    private String nome;
    
    @Convert(converter = SimNaoConverter.class)
    @Column(name = "ST_ATIVO")
    private Boolean ativo;
    
    @JsonBackReference
    @ManyToMany
    @JoinTable(name = "TB_PARAMETRO_TIPO_CAMPO_PLD", 
        joinColumns = @JoinColumn(name = "SQ_TIPO_CAMPO_PLD", referencedColumnName = "SQ_TIPO_CAMPO_PLD"), 
        inverseJoinColumns = @JoinColumn(name = "SQ_PARAMETRO_PLD", referencedColumnName = "SQ_PARAMETRO_PLD"))
    private List<ParametroPld> parametrosPld = new ArrayList<ParametroPld>();
}

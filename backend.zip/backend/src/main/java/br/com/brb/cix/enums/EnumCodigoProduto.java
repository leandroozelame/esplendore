package br.com.brb.cix.enums;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumCodigoProduto implements EnumDominio{
	CONTA_CORRENTE(1 ,"Conta Corrente"),
	CONTA_POUPANCA(2 ,"Conta Poupanca"),
	POUPANCA_SALARIO(3,"Poupanca Salario"),
	CONTA_INVESTIMENTO(4,"Conta Investimento"),
	POUPANCA_INTEGRADA(5,"Poupanca Integrada"),
	CONTA_ESPECIAL(6,"Conta Especial"),
	CONTA_SALARIO(7,"Conta Salario");
	
	@Getter
	private final Integer codigo;

	@Getter
	private final String descricao;

	private static final Map<Integer, EnumCodigoProduto> MAP_ENUM_CODIGO_PRODUTO = new ConcurrentHashMap<>();

	static {
		for (EnumCodigoProduto e : EnumCodigoProduto.values()) {
			MAP_ENUM_CODIGO_PRODUTO.put(e.getCodigo(), e);
		}
	}

	@JsonCreator	
	public static EnumCodigoProduto get(int codigo) {
		return MAP_ENUM_CODIGO_PRODUTO.get(codigo);
	}
	
	@Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
}
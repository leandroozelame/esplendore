package br.com.brb.cix.domain.model.funcionalidade;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import br.com.brb.cix.domain.model.perfil.Perfil;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FuncionalidadeRepository extends JpaRepository<Funcionalidade, Long> {
    static final String SQL_FUNCIONALIDADE = "SELECT UNIQUE f.* "
            + "FROM {h-schema}TB_FUNCIONALIDADE f, {h-schema}TB_PERFIL_FUNCIONALIDADE pf, {h-schema}TB_PERFIL_GRUPO pg, {h-schema}TB_PERFIL p "
            + "WHERE f.ST_ATIVO = '1' AND pf.SQ_FUNCIONALIDADE = f.SQ_FUNCIONALIDADE "
            + "AND pf.SQ_CODIGO = pg.SQ_CODIGO AND p.SQ_CODIGO = pg.SQ_CODIGO AND p.ST_ATIVO = '1' "
            + "AND pg.CD_GRPCOD = ?1 ";
    static final String ORDER_BY = "ORDER BY f.SQ_FUNCIONALIDADE_PAI DESC, f.CD_FUNCIONALIDADE";

    static final String SQL_FUNCIONALIDADE_SEM_FORMA_PAGAMENTO = " " + " SELECT F.* FROM CIX.TB_FUNCIONALIDADE F "
            + " WHERE F.ST_FORMA_PAGAMENTO = 1          " + " AND F.CD_MODULO = :codigoModulo         ";

    @Query(value = SQL_FUNCIONALIDADE_SEM_FORMA_PAGAMENTO, nativeQuery = true)
    List<Funcionalidade> findWithoutFormaPagamentoByModulo(@Param("codigoModulo") Integer codigoModulo);

    @Query(value = SQL_FUNCIONALIDADE + "AND f.CD_MODULO = ?2 " +  ORDER_BY, nativeQuery = true)
    List<Funcionalidade> findByGrupoAndModulo(Long grupo, Integer modulo);

    @Query(value = SQL_FUNCIONALIDADE + "AND f.CD_MODULO = 6 AND f.NR_RELATORIO IS NOT NULL " + ORDER_BY,             nativeQuery = true)
    List<Funcionalidade> findRelatorioByGrupo(Long grupo);

    List<Funcionalidade> findByNumeroRelatorioIsNotNull();

    Funcionalidade findByModuloAndNumeroTransacao(Integer modulo, Integer numeroTransacao);
    
    List<Funcionalidade> findByNumeroRelatorioIsNotNullAndFuncionalidadePaiAndAtivo(Long funcionalidadePai, Character ativo);

    @Override
    @SuppressWarnings("unchecked")
    Funcionalidade save(Funcionalidade funcionalidade);

    @Transactional
    Long deleteByNumeroRelatorio(Long numeroRelatorio);

    @Transactional
    Long deleteByCodigoMenu(Long codMenu);
    
    Funcionalidade findByCodigoMenuAndModulo(Integer codigoMenu, Integer modulo);

    Funcionalidade findByCodigo(Long codigo);

    @Query(value = "SELECT * FROM {h-schema}TB_FUNCIONALIDADE f WHERE cd_modulo = ?1 AND st_ativo = '1' AND " +
            "st_autorizavel = '1'", nativeQuery = true)
    List<Funcionalidade> findByModuloFuncionalidadesParaRegras(Integer modulo);

    List<Funcionalidade> findByModuloAndCodigoFuncionalidadeIsNotNullOrderByNome(Integer modulo);

    List<Funcionalidade> findByNumeroRelatorio(Long numeroRelatorio);

    List<Funcionalidade> findByNumeroRelatorioAndCodigoNot(Long numeroRelatorio, Long codigo);

    List<Funcionalidade> findByNomeIgnoreCaseAndNumeroRelatorioIsNotNull(String nome);

    List<Funcionalidade> findByNomeIgnoreCaseAndCodigoNot(String nome, Long codigo);

    Funcionalidade findByNomeIgnoreCaseAndModulo(String nome, Integer modulo);
    
    List<Funcionalidade> findByListaPerfisInAndAtivoOrderByCodigoMenu(List<Perfil> perfis, Character ativo);

    @Query(value = " SELECT F FROM  Funcionalidade F where F.modulo = :modulo")
    List<Funcionalidade> listarFuncionalidadefindByModulo(@Param("modulo") Integer modulo);
    
    List<Funcionalidade> findByNomeAndModulo(String nome, Integer modulo);
}

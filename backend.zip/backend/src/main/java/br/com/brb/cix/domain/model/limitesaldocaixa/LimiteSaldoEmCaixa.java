package br.com.brb.cix.domain.model.limitesaldocaixa;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author u654764
 *
 */

@Getter
@Setter
@Entity
@Table(name = "TB_LIMITE_SALDO_CAIXA")
@AllArgsConstructor()
@NoArgsConstructor()
public class LimiteSaldoEmCaixa  {
   
    private static final long serialVersionUID = 1L;

   
    @Id
    @SequenceGenerator(name = "limite_saldo_caixa_sequence", sequenceName = "SQ_LIMITE_SALDO_CAIXA", allocationSize = 1)
    @GeneratedValue(generator = "limite_saldo_caixa_sequence")
    @Column(name = "SQ_LIMITE_SALDO_CAIXA", nullable = false)
    private Long codigo;

    @Column(name = "CD_MODULO", nullable = false)
//    @Convert(converter = EnumCanalConverter.class)
    private Integer codigoModulo;

    @Column(name = "CD_UNIDADE", nullable = true)
    private Long codigoUnidade;
    
    @Column(name = "VL_LIMITE_SALDO_CHEQUE", nullable = false)
    private BigDecimal valorLimiteSaldoCheque;

    @Column(name = "VL_LIMITE_SALDO_DINHEIRO", nullable = false)
    private BigDecimal valorLimiteSaldoDinheiro;

}

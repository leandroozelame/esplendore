package br.com.brb.cix.context;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.brb.cix.enums.EnumCanal;
import lombok.extern.slf4j.Slf4j;

/**
 * Classe responsável por fornecer acesso ao parâmetros enviados no header das requisições do frontend. É obrigatório
 * executar as chamadas dos métodos dessa classe dentro do escopo de REQUEST.
 * @author u844902
 */
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
@Slf4j
public class CixHeader {
    public final static String CIX_HEADER_NAME = "X-CIX";
    private HttpServletRequest httpRequest;
    private CixHeaderWrapper cixHeaderWrapper;
    @Autowired
    private ObjectMapper objectMapper;

    public CixHeader(HttpServletRequest httpReq) {
        this.httpRequest = httpReq;
    }

    @PostConstruct
    private void parseCixHeader() {
        try {
            cixHeaderWrapper = new CixHeaderWrapper();
            String header = httpRequest.getHeader(CIX_HEADER_NAME);

            if (header != null) {
                cixHeaderWrapper = objectMapper.readValue(header, CixHeaderWrapper.class);
            }
        } catch (Exception e) {
            log.error("parseCixHeader()", e);
        }
    }

    public EnumCanal getEnumCanal() {
        return cixHeaderWrapper.enumCanal;
    }

    public Long getCodigoUnidadeSelecionada() {
        return cixHeaderWrapper.codigoUnidadeSelecionada;
    }

    public String getDescricaoUnidadeSelecionada() {
        return cixHeaderWrapper.descricaoUnidadeSelecionada;
    }
    
    // ip do usuário capturado pelo plugin do browser
    public String getIpUsuario() {
        return cixHeaderWrapper.ipUsuario;
    }
    
    // ambiente onde está rodando esta instância do CIX: LCL, DSV, HMO, HMO2, PRD
    public String getEnvironment() {
        return cixHeaderWrapper.environment;
    }

    // código do menu da funcionalidade que o usuário está acessando (opcional AUB)
    public Integer getCodigoMenuFuncionalidade() {
        return cixHeaderWrapper.codigoMenuFuncionalidade;
    }

    public static class CixHeaderWrapper {
        @JsonProperty("codigoCanal")
        public EnumCanal enumCanal;
        public Long codigoUnidadeSelecionada;
        public String descricaoUnidadeSelecionada;
        public String ipUsuario;
        @JsonProperty("env")
        public String environment;
        // código do menu da funcionalidade que o usuário está acessando (opcional AUB)
        @JsonProperty("codigoMenu")
        public Integer codigoMenuFuncionalidade;                
    }
}
package br.com.brb.cix.domain.model.parametrocanal.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.brb.cix.domain.model.parametrocanal.ParametroCanalRepositoryCustom;
import br.com.brb.cix.dto.ParametroCanalDTO;

@Repository
public class ParametroCanalRepositoryImpl implements ParametroCanalRepositoryCustom {

    private final EntityManager entityManager;

    static final String SQL_BUSCA_SECOES_POR_CANAL = "SELECT DISTINCT CD_SECAO AS codigoSecao, DS_SECAO AS secao "
            + "FROM {h-schema}TB_PARAMETRO_CANAL ORDER BY CD_SECAO";

    @Autowired
    public ParametroCanalRepositoryImpl(EntityManager manager) {
        this.entityManager = manager;
    }

    Function<Object[], ParametroCanalDTO> objectsToParametroCanalDTO = new Function<Object[], ParametroCanalDTO>() {
        public ParametroCanalDTO apply(Object[] atributos) {
            ParametroCanalDTO parametroCanalDTO = new ParametroCanalDTO();
            parametroCanalDTO.setCodigoSecao(Integer.parseInt(atributos[0].toString()));
            parametroCanalDTO.setSecao(atributos[1].toString());
            return parametroCanalDTO;
        }
    };

    @Override
    public List<ParametroCanalDTO> buscaSecoes() {
        Query q = entityManager.createNativeQuery(SQL_BUSCA_SECOES_POR_CANAL);

        @SuppressWarnings("unchecked")
        List<Object[]> x = q.getResultList();
        List<ParametroCanalDTO> parametroCanalDTO = new ArrayList<ParametroCanalDTO>(0);
        if (!x.isEmpty()) {
            parametroCanalDTO = x.stream().map(objectsToParametroCanalDTO).collect(Collectors.toList());
        }
        return parametroCanalDTO;
    }
}
package br.com.brb.cix.domain.model.horariocanal;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.enums.EnumDiasSemana;
import br.com.brb.cix.util.ConvertCharToBoolean;
import br.com.brb.cix.util.EnumDiasSemanaConverter;
import br.com.brb.cix.util.HoraConvert;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "TB_HORARIO_CANAL")
public class HorarioCanal  {
    /**
    * 
    */
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "horario_canal_sequence", sequenceName = "SQ_HORARIO_CANAL", allocationSize = 1)
    @GeneratedValue(generator = "horario_canal_sequence")
    @Column(name = "SQ_HORARIO_CANAL")
    private Long codigo;

    @Column(name = "CD_MODULO")
    private Integer codigoModulo;

    @Column(name = "CD_UNIDADE")
    private Long codigoUnidade;

    @Convert(converter = HoraConvert.class)
    @Column(name = "HR_INICIAL")
    private String horaInicial;

    @Convert(converter = HoraConvert.class)
    @Column(name = "HR_FINAL")
    private String horaFinal;

    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_UNIDADE")
    private Boolean situacaoUnidade;

    @Convert(converter = EnumDiasSemanaConverter.class)
    @Column(name = "DI_SEMANA")
    private EnumDiasSemana diaSemana;

    @Column(name = "DT_EXCECAO")
    private Date dataExcecao;
}

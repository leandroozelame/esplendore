package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoModalidade implements EnumDominio {
    CORRENTE_SALARIO_E_POUPANCA(0, "Conta Corrente, Conta Salário e Poupança"), 
    CONTA_ESPECIAL(1, "Conta Simplificada ('Especial')"),
    POUPANCA_INTEGRADA(2, "Poupança Integrada"), 
    CONTA_VINCULADA(3, "Conta Vinculada");

    private static final Map<Integer, EnumTipoModalidade> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoModalidade e : EnumTipoModalidade.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoModalidade get(int tipoConta) {
        return MAP.get(tipoConta);
    }

    @JsonCreator
    public static EnumTipoModalidade criaEnum(Object tipo) {
        EnumTipoModalidade retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumTipoModalidade criaEnumString(String descricao) {
        EnumTipoModalidade retorno = null;
        Iterator<Map.Entry<Integer, EnumTipoModalidade>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumTipoModalidade> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

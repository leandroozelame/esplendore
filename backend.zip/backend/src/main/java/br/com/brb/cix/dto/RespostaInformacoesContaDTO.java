package br.com.brb.cix.dto;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RespostaInformacoesContaDTO {

    private Long numeroConta;
    private Integer codigoAgencia;
    private Integer ptaOrigem;
    private Integer ordemTitular;
    private List<InformacoesContaDTO> informacoesConta;

}

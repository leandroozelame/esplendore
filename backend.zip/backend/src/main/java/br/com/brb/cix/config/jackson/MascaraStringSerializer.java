package br.com.brb.cix.config.jackson;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class MascaraStringSerializer extends JsonSerializer<String> {

	/** Mascara qualquer atributo que contenha a string "senha" para evitar o vazamento de dados*/
    public void serialize(String value, JsonGenerator jsonGenerator, SerializerProvider serializerProvider)
            throws IOException {
    	String nomeAtributo = jsonGenerator.getOutputContext().getCurrentName().toLowerCase();
    	
    	if (nomeAtributo.contains("senha")) {
    		jsonGenerator.writeString("******");
    	} else {
    		jsonGenerator.writeString(value);
    	}
    }
    
}
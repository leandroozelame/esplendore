package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.enums.EnumTipoModalidade;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class DepositoChequeLiquidadoDTO extends AbstractDTO {
    private EnumFormaMovimentacao formaMovimentacao;
    private Long nrContaCredito;
    private Integer nrAgencia;
    private String nomeTitular;
    private EnumTipoConta tipoDeContaCredito;
    private EnumTipoModalidade modalidadeDeConta;
    private String tipoMovimentacao;
    private String linha;
    private Long nrContaDebito;
    private Long nrAgenciaDebito;
    private Integer nrCheque;
    private EnumTipoConta tipoDeContaDebito;
    private Long codigoTransacao;
    @LogValorTransacao
    private BigDecimal valorChequeBRB = BigDecimal.ZERO;
    private Boolean indicadorSemSaldo;
}
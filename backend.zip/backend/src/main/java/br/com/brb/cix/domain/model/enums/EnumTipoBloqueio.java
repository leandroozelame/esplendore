package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoBloqueio implements EnumDominio{
    CONTA(2, "Bloqueio de Conta"), 
    SALDO(3, "Bloqueio de Saldo"); 

    private static final Map<Integer, EnumTipoBloqueio> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoBloqueio e : EnumTipoBloqueio.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoBloqueio get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumTipoBloqueio criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
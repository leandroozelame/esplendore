package br.com.brb.cix.dto;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class AlterarFormaPagamentoDTO {
    private Long codigo;
    private Boolean aceitaFormaPagamento;
    private BigDecimal valorMaximoPagamento;
}
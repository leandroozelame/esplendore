package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.grupo.Grupo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GrupoDTO extends AbstractDTO {
    private Long codigo;
    private String nome;

    public GrupoDTO() {
        super();
    }

    public GrupoDTO(Grupo grupo) {
        super();
        codigo = grupo.getCodigo();
        nome = grupo.getNome();
    }
}
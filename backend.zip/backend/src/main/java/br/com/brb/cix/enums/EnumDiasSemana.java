package br.com.brb.cix.enums;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.annotation.JsonCreator;

import br.com.brb.cix.domain.model.enums.EnumDominio;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author u653865
 */
// CUIDADO EnumDiasSemana É INCOMPATÍVEL com DayOfWeek do Java 
// A conversão deve ser feita usando o método abaixo fromLocalDateTime() ou fromLocalDate()
// Nunca diretamente!
@AllArgsConstructor
public enum EnumDiasSemana implements EnumDominio {
    SEG(1, "Segunda-feira"), 
    TER(2, "Terça-feira"), 
    QUA(3, "Quarta-feira"), 
    QUI(4, "Quinta-feira"), 
    SEX(5, "Sexta-feira"), 
    SAB(6, "Sábado"), 
    DOM(0, "Domingo");  

    @Getter
    private final Integer codigo;
    @Getter
    private final String descricao;
    private static final Map<Integer, EnumDiasSemana> MAP_DIASEMANA = new ConcurrentHashMap<>();

    static {
        for (EnumDiasSemana e : EnumDiasSemana.values()) {
            MAP_DIASEMANA.put(e.getCodigo(), e);
        }
    }

    @JsonCreator    
    public static EnumDiasSemana get(int codigo) {
        return MAP_DIASEMANA.get(codigo);
    }
    
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
    
    public static EnumDiasSemana fromLocalDateTime(LocalDateTime localDateTime) {
    	int diaDaSemana = localDateTime.getDayOfWeek().getValue();
    	
    	return EnumDiasSemana.get(diaDaSemana == 7 ? 0 : diaDaSemana);
    }

    public static EnumDiasSemana fromLocalDate(LocalDate localDate) {
    	int diaDaSemana = localDate.getDayOfWeek().getValue();
    	
    	return EnumDiasSemana.get(diaDaSemana == 7 ? 0 : diaDaSemana);
    }
}
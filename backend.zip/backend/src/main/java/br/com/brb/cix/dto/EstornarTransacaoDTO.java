package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class EstornarTransacaoDTO extends ContaTipoDTO {
	
	private Long nsu;
	private String motivo;
	private String descricaoTransacao;
    @JsonProperty(access = Access.WRITE_ONLY)
	private Long codigoTransacao;
    @JsonProperty(access = Access.WRITE_ONLY)
	private Integer tipoParticao;
    @JsonProperty(access = Access.WRITE_ONLY)
	private String particao;
	private Date dataHoraPagamento;
	@LogValorTransacao
	private BigDecimal valorTransacao;
    @JsonProperty(access = Access.WRITE_ONLY)
	private BigDecimal valorLog;
	private EnumFormaMovimentacao formaMovimentacao;
    @JsonProperty(access = Access.WRITE_ONLY)
    private PendenciaDTO pendencia;
    @JsonProperty(access = Access.WRITE_ONLY)
    private Boolean temValorDepositoDinheiro = false;
    @JsonProperty(access = Access.WRITE_ONLY)
    private boolean isSaque = false;
    private List<EstornoSuperTransacaoDTO> listaTransacoes;
    @JsonProperty(access = Access.WRITE_ONLY)
    private boolean isTransacaoMalote = false;
}
package br.com.brb.cix.dto;

import br.com.brb.cix.domain.model.enums.EnumTipoBloqueioHabilitacaoContasSobJudice;
import java.util.List;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class HabilitacaoContasSobJudiceDTO extends AbstractDTO {

    private EnumTipoBloqueioHabilitacaoContasSobJudice tipoBloqueio;
    private List<ContaSobConsultaJudicialDTO> contas;
}
package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumCodigoFundo implements EnumDominio{
    FUNDO_BRB_ACOES_500(2, "FIC FIA BRB ACOES 500", 902),
    FUNDO_BRB_FIRF_(13, "BRB FIC FIRF DI LP 25 MIL", 913),
    FUNDO_FIC_FI_MULTIM(16, "BRB FIC FI MULTIM LP 500 ", 916),
    FUNDO_FI_RF_BRB_LIQUIDEZ(18, "FI RF BRB LIQUIDEZ", 918),
    FUNDO_BRB_FIC_FI_RF_GOVERNO(27, "BRB FIC FI RF GOVERNO", 927),
    FUNDO_BRB_FIC_FI_RF_DI_LP_500(28, "BRB FIC FI RF DI LP 500", 928),
    FUNDO_FI_RF_BRB_MAIS(31,"FI RF BRB MAIS", 931),
    FUNDO_BRB_FIC_FIRF_PUB_LP_(33,"BRB FIC FIRF PUB LP 5MIL", 933),
    FUNDO_FIA_BRB_PETROVALE(34,"FIA BRB PETROVALE", 934),
    FUNDO_BRB_FICFIRF_PUB_LP(35,"BRB FICFIRF PUB LP 300MIL", 935),
    FUNDO_BRB_RF_PUBLICO_LP(40,"BRB FIC FI RF PUBLICO LP", 940),
    FUNDO_BRB_LP_IMA(44,"BRB FIC FI RF LP IMA B", 944),
    FUNDO_BRB_PREMIUM_FI_MULTIM(56,"BRB PREMIUM FI MULTIM LP", 956),
    FUNDO_FICFI_RF_DI_LP_1_MILHAO(61,"FICFI RF DI LP 1 MILHAO", 961),
    FUNDO_BRB_FIRF_DI_100_MIL(65,"BRB FIC FIRF DI 100 MIL L", 965);

    private static final Map<Integer, EnumCodigoFundo> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;
    @Getter
    private Integer tipoContaFundo;

    static {
        for (EnumCodigoFundo e : EnumCodigoFundo.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumCodigoFundo get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumCodigoFundo criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
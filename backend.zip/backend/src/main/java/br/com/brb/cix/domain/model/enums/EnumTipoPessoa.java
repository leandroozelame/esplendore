package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoPessoa implements EnumDominio {
    PESSOA_FISICA(0, "Pessoa Física", "F"), PESSOA_JURIDICA(1, "Pessoa Jurídica", "J");

    private static final Map<Integer, EnumTipoPessoa> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;
    @Getter
    private String sigla;

    static {
        for (EnumTipoPessoa e : EnumTipoPessoa.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoPessoa get(int codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumTipoPessoa criaEnum(Object tipo) {
        EnumTipoPessoa retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumTipoPessoa criaEnumString(String descricao) {
        EnumTipoPessoa retorno = null;
        Iterator<Map.Entry<Integer, EnumTipoPessoa>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumTipoPessoa> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class SuprimentoRecolhimentoDTO extends AbstractDTO {
    private Integer quantidade2;
    private Integer quantidade5;
    private Integer quantidade10;
    private Integer quantidade20;
    private Integer quantidade50;
    private Integer quantidade100;
    private Integer quantidade200;
    private BigDecimal valor2;
    private BigDecimal valor5;
    private BigDecimal valor10;
    private BigDecimal valor20;
    private BigDecimal valor50;
    private BigDecimal valor100;
    private BigDecimal valor200;
    private BigDecimal valorMoedas;
    @LogValorTransacao
    private BigDecimal valorTotal;
}
package br.com.brb.cix.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReimprimirComprovanteTransacaoDTO implements Serializable{
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private Integer canalFormatacao;
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date dataTransacao;
    private String terminal;
    private Long nsu;
    private BigDecimal valorTransacao;
    private Integer unidade;
    private String linhaDigitavel;

}

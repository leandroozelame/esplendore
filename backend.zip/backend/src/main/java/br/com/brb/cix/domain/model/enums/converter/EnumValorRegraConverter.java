package br.com.brb.cix.domain.model.enums.converter;

import br.com.brb.cix.domain.model.enums.EnumValorRegra;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumValorRegraConverter implements AttributeConverter<EnumValorRegra, Character> {

    @Override
    public Character convertToDatabaseColumn(EnumValorRegra valorRegra) {
        return valorRegra != null ? valorRegra.getCodigo() : null;
    }

    @Override
    public EnumValorRegra convertToEntityAttribute(Character codigo) {
        return EnumValorRegra.get(codigo);
    }
}

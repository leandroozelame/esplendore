package br.com.brb.cix.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class CustomCorsFilter implements Filter {

    private static final String COMMA = ",";
    private static final String HEADER_ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
    private static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
    private static final String HEADER_ACCESS_CONTROL_EXPOSE_HEADERS = "Access-Control-Expose-Headers";
    private static final String HEADER_ACCESS_CONTROL_MAX_AGE = "Access-Control-Max-Age";
    private static final String HEADER_ACCESS_CONTROL_ALLOW_METHODS = "Access-Control-Allow-Methods";
    private static final String HEADER_ACEESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
    private static final String METHOD_OPTIONS = "OPTIONS";
    private static final String HEADER_ORIGIN = "Origin";

    @Autowired
    private ApplicationProperties applicationProperties;

    @Override
    public void init(FilterConfig filterConfig) {

    }

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletResponse response = (HttpServletResponse) res;
        HttpServletRequest request = (HttpServletRequest) req;

        String origin = ((HttpServletRequest) req).getHeader(HEADER_ORIGIN);

        if(origin == null){
            chain.doFilter(req, res);
            return;
        }

        String allowedOrigins = StringUtils.join(this.applicationProperties.getCors().getAllowedOrigins(), ",");
        if (allowedOrigins.contains(origin)) {
            response.setHeader(HEADER_ACCESS_CONTROL_ALLOW_ORIGIN, origin);
        }
        response.setHeader(ACCESS_CONTROL_ALLOW_HEADERS, StringUtils.join(this.applicationProperties.getCors().getAllowedHeaders(), ","));
        response.setHeader(HEADER_ACCESS_CONTROL_EXPOSE_HEADERS, StringUtils.join(this.applicationProperties.getCors().getExposedHeaders(), ","));
        response.setHeader(HEADER_ACCESS_CONTROL_MAX_AGE, this.applicationProperties.getCors().getMaxAge().toString());
        response.setHeader(HEADER_ACCESS_CONTROL_ALLOW_METHODS, StringUtils.join(this.applicationProperties.getCors().getAllowedMethods(), ","));
        response.setHeader(HEADER_ACEESS_CONTROL_ALLOW_CREDENTIALS, this.applicationProperties.getCors().getAllowCredentials().toString());

        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            response.setStatus(200);
        } else {
            chain.doFilter(req, res);
        }
    }

    @Override
    public void destroy() {

    }
}
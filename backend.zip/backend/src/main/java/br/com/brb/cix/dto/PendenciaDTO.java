package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PendenciaDTO {
    private Long codigo;
    private Long nsuCix;
    private Long nsuBlk;
    private Long nsuCixEstornado;
    private Character situacao;
    private Long codigoRegra;
    private String nomeRegra;
    private Long numeroRecibo;
    private Date dataCadastro;
    private Date dataAtualizacao;
    private BigDecimal valor;
    private String descricao;
    private Long contaOrigem;
    private Long contaDestino;
    private Integer terminal;
    private String matricula;
    private Integer matriculaUltimoAutorizador;
    private Integer unidade;
    @JsonIgnore
    private String detalhamento;
    private String motivoRejeicao;

    public PendenciaDTO() {
        super();
    }
}
package br.com.brb.cix.domain.model.transacaoSupertransacao;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.supertransacao.Supertransacao;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "TB_TRANSACAO_SUPERTRANSACAO")
public class TransacaoSupertransacao  {
	
	private static final long serialVersionUID = -5072825570683287791L;

	@Id
	@SequenceGenerator(name = "sequence_transacao_supertransacao", sequenceName = "SQ_TRANSACAO_SUPERTRANSACAO", allocationSize = 1)
	@GeneratedValue(generator = "sequence_transacao_supertransacao")
	@Column(name = "SQ_TRANSACAO_SUPERTRANSACAO")
	private Long id;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "SQ_SUPERTRANSACAO_EXECUCAO")
	private Supertransacao supertransacao;
	
	@Column(name = "CD_TRANSACAO")
	private Long numero;
	
	@ManyToOne
	@JoinColumn(name = "CD_SITUACAO_TRANSACAO_EXECUCAO")
	private SituacaoExecucaoTransacao situacaoExecucao;
	
	@Column(name = "VL_TRANSACAO")
	private BigDecimal valor;
	
	@Column(name = "VL_TARIFA")
	private BigDecimal valorTarifa;
	
	@Lob
    @Column(name = "TX_DADOS")
    private String dados;
	
	@Column(name = "NR_NSU")
	private Long nsu;
}

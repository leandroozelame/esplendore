package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RecebimentoOperacaoCursoAnormalDTO extends ContaTipoDTO {
	
	private Long contrato;
	private Integer tipo;
	private Integer parcela;
	private Integer dv;
	@LogValorTransacao
	private BigDecimal valorTransacao;
	private String numeroDocumento;
	private Date dataDocumento;
	
	private EnumFormaMovimentacao formaMovimentacao;
	private Long numeroFichaContabil;
	private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
	private Integer numeroCheque;
	private Long numeroContaCheque;
	private String cmc7;
	private String matriculaSupervisor;
}
package br.com.brb.cix.domain.model.gavetadigital;

import java.util.List;

import br.com.brb.cix.domain.model.terminal.Terminal;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author u653865
 *
 */
public interface GavetaDigitalRepository extends JpaRepository<GavetaDigital, Long> {

    /**
     * @param terminal
     * @return
     */
    GavetaDigital findByTerminal(Terminal terminal);

    /**
     * @param terminal
     * @return
     */
    Long countByTerminal(Terminal terminal);
    
    List<GavetaDigital> findByTerminalOrderByDataOperacaoDesc(Terminal terminal);
}

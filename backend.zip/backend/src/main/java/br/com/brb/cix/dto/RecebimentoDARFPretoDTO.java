package br.com.brb.cix.dto;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.config.jackson.CodigoReceitaSerializer;
import br.com.brb.cix.config.jackson.DateOnlySerializer;
import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.enums.EnumChequeIndicadorDigitacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RecebimentoDARFPretoDTO extends ContaTipoDTO {
	

	@JsonSerialize(using = DateOnlySerializer.class)
	private Date periodoApuracao;
	private String cpfCnpjContribuinte;
	@JsonSerialize(using = CodigoReceitaSerializer.class)
	private String codigoReceita;
	private String descricaoReceita;
	private String numeroReferencia;
	@JsonSerialize(using = DateOnlySerializer.class)
	private Date dataVencimento;
	private BigDecimal valorPrincipal;
	private BigDecimal valorMulta;
	private BigDecimal valorJuros;
	@LogValorTransacao
	private BigDecimal valorTotal;
	private String numeroDocumento;
	private Date dataDocumento;

	private Long agencia;
	private Long conta;
	private EnumTipoConta tipoConta;

	private String nomeTitular;
	private Integer ordemTitular;
	
	
	private EnumFormaMovimentacao formaMovimentacao;
	private Long numeroFichaContabil;
	private EnumChequeIndicadorDigitacao chequeIndicadorDigitacao;
	private Integer numeroCheque;
	private Long numeroContaCheque;
	private String cmc7;
	private String matriculaSupervisor;

	private Integer idAlvara;
	private BigDecimal valorAlvara;
	private String nomeBeneficiario;
	private Long cpfCnpj;
	private String tipoPessoa;
	private String nomeTribunal;
	private String cnpjTribunal;
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Integer tpPessoaSigla;
}
package br.com.brb.cix.auditoria;

import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.brb.cix.domain.model.auditoria.Auditoria;
import br.com.brb.cix.domain.model.auditoria.AuditoriaRepository;
import br.com.brb.cix.dto.DadosAuditoriaDTO;
import br.com.brb.cix.enums.EnumCanal;
import br.com.brb.cix.enums.EnumFuncionalidade;
import br.com.brb.cix.enums.EnumTipoEventoAuditoria;
import br.com.brb.cix.util.EnderecoIP;
import lombok.Getter;

@Component
@Slf4j
public class LogAuditoriaSchedulerBuilder {

	@Getter
    private EnumFuncionalidade enumFuncionalidade;
	@Getter
    private EnumTipoEventoAuditoria enumTipoEventoAuditoria;
	@Getter
    private LinkedHashMap<String, Object> mapaParametroEntrada = new LinkedHashMap<>();
    @Getter
    private EnumSituacaoExecucao enumSituacaoExecucao;
	@Autowired
    private AuditoriaRepository auditoriaRepository;

	public LogAuditoriaSchedulerBuilder setEnumFuncionalidade(EnumFuncionalidade enumFuncionalidade) {
        this.enumFuncionalidade = enumFuncionalidade;
        return this;
    }

	public LogAuditoriaSchedulerBuilder setEnumTipoEventoAuditoria(EnumTipoEventoAuditoria enumTipoEventoAuditoria) {
        this.enumTipoEventoAuditoria = enumTipoEventoAuditoria;
        return this;
    }
	
	public LogAuditoriaSchedulerBuilder setEnumSituacaoExecucao(EnumSituacaoExecucao enumSituacaoExecucao) {
        this.enumSituacaoExecucao = enumSituacaoExecucao;
        return this;
    }
	
	public LogAuditoriaSchedulerBuilder putMapaParametroEntrada(String key, Object value) {
        getMapaParametroEntrada().put(key, value);
        return this;
    }

    public LogAuditoriaSchedulerBuilder clearMapaParametroEntrada() {
        getMapaParametroEntrada().clear();
        return this;
    }
    
    public void cria() {
    	auditoriaRepository.saveAndFlush(fabricaAuditoria());
    }
    
    @SuppressWarnings("static-access")
    private Auditoria fabricaAuditoria(){
        // Dados Comum
        Auditoria auditoriaInicial = new Auditoria();
        
        auditoriaInicial.setDataOperacao(LocalDateTime.now());
        auditoriaInicial.setNrTerminal(0);
        String operador = "u000000";
        String nomeOperador = "SISTEMA CIX";
        String localHostAddress = "0.0.0.0";
        String localHostName = "";
        StringBuilder builder = new StringBuilder();
        try {
        	Enumeration<NetworkInterface> e = NetworkInterface.getNetworkInterfaces();
        	while (e.hasMoreElements()) {
        		NetworkInterface networkInterface = e.nextElement();
	        	List<InterfaceAddress> getInterfaceAddresses = ((NetworkInterface) networkInterface).getInterfaceAddresses();
	        	for (InterfaceAddress interfaceAddress : getInterfaceAddresses) {
	        		String ip = interfaceAddress.getAddress().getHostAddress().toString();
	        		if(EnderecoIP.isValid(ip)) {
	        			String interfaceName = ((NetworkInterface) networkInterface).getName();
	        			String hostName = (interfaceAddress.getAddress().getLocalHost().getHostName());
	        			builder.append(interfaceName);
	        			builder.append(";");
	        			builder.append(hostName);
	        			builder.append(";");
	        			builder.append(ip);
	        			builder.append(";");
	        		}
				}
        	}
        	
    	localHostName = InetAddress.getLocalHost().getHostName();

        } catch (UnknownHostException | SocketException e) {
        	log.error("UnknownHostException", e);
		}
        
        auditoriaInicial.setIp(localHostAddress);
        auditoriaInicial.setOperador(operador);
        auditoriaInicial.setNomeOperador(nomeOperador);
        auditoriaInicial.setAgenciaOperador("0");
        auditoriaInicial.setCodigoUnidadeOperador(0L);
        auditoriaInicial.setDescricaoUnidadeOperador("");
        auditoriaInicial.setServidor(localHostName);
        auditoriaInicial.setCpfCliente("");
        auditoriaInicial.setNomeCliente("");

        // Canal
        auditoriaInicial.setNrCanal(EnumCanal.CIX);
        auditoriaInicial.setFuncionalidade(this.enumFuncionalidade.getDescricao());
        auditoriaInicial.setEvento(this.enumTipoEventoAuditoria != null ? this.enumTipoEventoAuditoria.getDescricao() : null);
        auditoriaInicial.setSituacaoExecucao(this.getEnumSituacaoExecucao());

        DadosAuditoriaDTO dadosAuditoria = new DadosAuditoriaDTO();
    	putMapaParametroEntrada("IPs", builder.toString());
    	dadosAuditoria.setParametroEntrada(getMapaParametroEntrada());
    	auditoriaInicial.setMapaParametroEntrada(new LinkedHashMap<String, Object>());
    	LinkedHashMap<String, Object> dadosEntrada = auditoriaInicial.getMapaParametroEntrada();
    	dadosEntrada.putAll((Map<String, Object>) getMapaParametroEntrada());
    	auditoriaInicial.setMapaParametroEntrada(dadosEntrada);
        
        return auditoriaInicial;
    }

}
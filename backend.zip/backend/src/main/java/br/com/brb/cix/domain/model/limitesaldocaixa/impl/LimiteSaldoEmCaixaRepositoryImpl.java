package br.com.brb.cix.domain.model.limitesaldocaixa.impl;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import br.com.brb.cix.domain.model.limitesaldocaixa.LimiteSaldoEmCaixaRepositoryCustom;
import br.com.brb.cix.dto.ConsultaSaldoEmCaixaDTO;
import br.com.brb.cix.util.ObjectUtil;
import br.com.brb.cix.util.SqlUtil;
import lombok.Getter;

/**
 * @author u653865
 *
 */
@Repository
public class LimiteSaldoEmCaixaRepositoryImpl implements LimiteSaldoEmCaixaRepositoryCustom {

    @Getter
    private final EntityManager em;

    @Autowired
    public LimiteSaldoEmCaixaRepositoryImpl(EntityManager em) {
        this.em = em;
    }

    /*
     * (non-Javadoc)
     * 
     * @see br.com.brb.cix.domain.model.limitesaldocaixa.
     * LimiteSaldoEmCaixaRepositoryCustom#consultar(br.com.brb.cix.dto.
     * ConsultaSaldoEmCaixaDTO)
     */
    @Override
    public ConsultaSaldoEmCaixaDTO consultar(ConsultaSaldoEmCaixaDTO filtro) {

        Query query = em.createNativeQuery(retornarSQL(filtro.getCodigoUnidade()));

        query.setParameter("modulo", filtro.getCodigoModulo());
        query.setParameter("unidade", ObjectUtil.isNull(filtro.getCodigoUnidade()) ? 0 : filtro.getCodigoUnidade());

        try {
            Object[] resultado = (Object[]) query.getSingleResult();

            ConsultaSaldoEmCaixaDTO parametro = new ConsultaSaldoEmCaixaDTO();
            parametro.setCodigo(SqlUtil.toLong(resultado[0]));
            parametro.setCodigoModulo(SqlUtil.toInteger(resultado[1]));
            parametro.setDescricaoModulo(SqlUtil.toString(resultado[2]));
            parametro.setCodigoUnidade(SqlUtil.toLong(resultado[3]));
            parametro.setDescricaoUnidade(SqlUtil.toString(resultado[4]));
            parametro.setValorLimiteSaldoCheque(SqlUtil.toBigDecimail(resultado[5]));
            parametro.setValorLimiteSaldoDinheiro(SqlUtil.toBigDecimail(resultado[6]));

            return parametro;
        } catch (NoResultException nre) {
            return null;
        }
    }

    private String retornarSQL(Long codigoUnidade) {
        StringBuilder sql = new StringBuilder();
        if(codigoUnidade == null || codigoUnidade  ==0L){
            sql.append(" SELECT                                                  ");
            sql.append("    p.sq_limite_saldo_caixa ,                            ");
            sql.append("    p.cd_modulo             ,                            ");
            sql.append("    m.no_modulo             ,                            ");
            sql.append("    p.cd_unidade            ,                            ");
            sql.append("    '' as UNDDSC            ,                            ");
            sql.append("    p.vl_limite_saldo_cheque,                            ");
            sql.append("    p.vl_limite_saldo_dinheiro                           ");
            sql.append(" FROM CIX.TB_LIMITE_SALDO_CAIXA p                        ");
            sql.append(" LEFT JOIN CIX.TB_MODULO m ON p.cd_modulo = m.CD_MODULO  ");
            sql.append(" WHERE p.cd_modulo = :modulo                             ");
            sql.append(" AND p.cd_unidade IS NULL                                ");
            sql.append("                                                         ");
            sql.append(" UNION ALL                                               ");
            sql.append("                                                         ");
            sql.append(" SELECT                                                  ");
            sql.append("    p.sq_limite_saldo_caixa  ,                           ");
            sql.append("    p.cd_modulo              ,                           ");
            sql.append("    m.no_modulo              ,                           ");
            sql.append("    p.cd_unidade             ,                           ");
            sql.append("    u.UNDDSC                 ,                           ");
            sql.append("    p.vl_limite_saldo_cheque ,                           ");
            sql.append("    p.vl_limite_saldo_dinheiro                           ");
            sql.append(" FROM CIX.TB_LIMITE_SALDO_CAIXA p                        ");
            sql.append(" LEFT JOIN CIX.VW_UND u ON p.cd_unidade = u.UNDCOD       ");
            sql.append(" LEFT JOIN CIX.TB_MODULO m ON p.cd_modulo = m.CD_MODULO  ");
            sql.append(" WHERE p.cd_modulo = :modulo                             ");
            sql.append(" AND p.cd_unidade = :unidade                             ");
            sql.append(" AND p.cd_unidade IS NOT NULL                            ");
            sql.append(" ORDER BY UNDDSC");
            return sql.toString();
        }
            sql.append(" SELECT                                                  ");
            sql.append("    p.sq_limite_saldo_caixa  ,                           ");
            sql.append("    p.cd_modulo              ,                           ");
            sql.append("    m.no_modulo              ,                           ");
            sql.append("    p.cd_unidade             ,                           ");
            sql.append("    u.UNDDSC                 ,                           ");
            sql.append("    p.vl_limite_saldo_cheque ,                           ");
            sql.append("    p.vl_limite_saldo_dinheiro                           ");
            sql.append(" FROM CIX.TB_LIMITE_SALDO_CAIXA p                        ");
            sql.append(" LEFT JOIN CIX.VW_UND u ON p.cd_unidade = u.UNDCOD       ");
            sql.append(" LEFT JOIN CIX.TB_MODULO m ON p.cd_modulo = m.CD_MODULO  ");
            sql.append(" WHERE p.cd_modulo = :modulo                             ");
            sql.append(" AND p.cd_unidade = :unidade                             ");
            sql.append(" ORDER BY UNDDSC");

        return sql.toString();
    }

}

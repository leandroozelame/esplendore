package br.com.brb.cix.domain.model.documentorecebido;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentoRecebidoRepository extends JpaRepository<DocumentoRecebido, Long> {

	DocumentoRecebido findFirstByCodigoBarras(String codigoBarras);
	DocumentoRecebido findFirstByUnidadeAndNsu(Long unidade,  Long nsu);
}

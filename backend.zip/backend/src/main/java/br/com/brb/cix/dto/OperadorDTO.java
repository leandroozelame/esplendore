package br.com.brb.cix.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OperadorDTO extends AbstractDTO {
    @JsonIgnore
    private String cpf;

    private String matricula;
    private String nome;
    private Long codigoUnidade;
    private String descricaoUnidade;
    private Integer unidadeTransacionavel;
    private Integer tipoUnidade;
    private Long codigoGrupo;
    private String descricaoGrupo;
    private Integer numeroTerminal;
    private String descricaoUnidadeTerminal;
    private TerminalDTO terminal;
    private Integer modulo;
    private List<ContaDTO> contas;

    private String urlSairPortal;
    private String urlSairSso;
    
    private Long codigoEquipe;
    private String nomeEquipe;
    private String cargoFuncaoLdap;
    
    @Data
    public static class ContaDTO {
        private Integer agencia;
        private Long conta;
        private Integer modalidadeConta;
        private Integer ordemTitular;
        private Integer tipoConta;
        private Integer tipoTitularidade;
    }
}
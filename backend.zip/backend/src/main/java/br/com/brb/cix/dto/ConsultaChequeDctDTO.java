package br.com.brb.cix.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import br.com.brb.cix.util.ChequeUtil;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsultaChequeDctDTO extends AbstractDTO {

    private String cmc7;
    private Integer NrAgencia;
    private Integer NrBanco;
    private Long NrConta;
    private Integer NrCheque;
    private Integer NrComp;
    private Integer dv1;
    private Integer dv2;
    private Integer dv3;

    public ConsultaChequeDctDTO() {
    }

    public ConsultaChequeDctDTO(String cmc7) {
        ChequeUtil chequeUtil = new ChequeUtil(cmc7);
        this.NrAgencia = chequeUtil.getNrAgencia();
        this.NrBanco = chequeUtil.getNrBanco();
        this.NrConta = chequeUtil.getNrConta();
        this.NrCheque = chequeUtil.getNrCheque();
        this.NrComp = chequeUtil.getNrComp();
        this.dv1 = chequeUtil.getDv1();
        this.dv2 = chequeUtil.getDv2();
        this.dv3 = chequeUtil.getDv3();
    }

}

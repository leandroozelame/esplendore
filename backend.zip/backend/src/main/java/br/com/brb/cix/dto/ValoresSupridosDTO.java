package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class ValoresSupridosDTO {
    
    private BigDecimal valorSuprido;
}
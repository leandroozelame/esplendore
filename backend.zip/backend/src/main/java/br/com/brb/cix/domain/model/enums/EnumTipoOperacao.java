package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoOperacao implements EnumDominio{
    INDIFERENTE(0, "Indiferente"),
    CREDITO(1, "Crédito"), 
    DEBITO(2, "Débito"); 

    private static final Map<Integer, EnumTipoOperacao> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoOperacao e : EnumTipoOperacao.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoOperacao get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumTipoOperacao criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
}
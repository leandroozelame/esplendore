package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author u654764
 *
 */
@AllArgsConstructor
@Getter
public enum EnumBeneficioProgaramaEventual implements EnumDominio {
    AUXILIO_FUNERAL("00003","Auxílio funeral"),
    AUXILIO_NATALIDADE("00005","Auxílio natalidade"),
    AUXILIO_VULNERABILIDADE("00006","Auxílio Vulnerabilidade"),
    AUXILIO_CALAMIDADE("00009","Auxílio Calamidade"),
    BENEFICIO_EXCEPCIONAL_PTTS("00010","Benefício Excepcional (PTTS)"),
    AGENTES_DA_CIDADANIA_AMBIENTAL("00011","Agentes da Cidadania Ambiental"),
    AGENTES_DA_CIDADANIA_MOB_AMBIENTAL("00012","Agentes da Cidadania Mobilização Social"),
    CAMINHOS_DA_CIDADANIA("00013","Caminhos da Cidadania"),
    CONEXAO_CIDADA("00014","Conexão Cidadã"),
    BENEF_EM_CONTIG_OU_BENF_COMP_FINANC("00099","Benefício em Contingência ou Benefício de Compensação Financeira");
    
    
    private String codigo;
    private String descricao;

    static List<EnumBeneficioProgaramaEventual> listaEnum = Arrays.asList(EnumBeneficioProgaramaEventual.values());
    private static final Map<String, EnumBeneficioProgaramaEventual> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

    /**
     * @param codigo
     * @return
     */
    @JsonCreator
    public static EnumBeneficioProgaramaEventual get(String codigo) {
        return MAP.get(codigo);
    }

    /**
     * @return
     */
    public static List<Object> listarEnumBenProgramaEventual() {
        return listaEnum.stream().map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());
    }

    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }
}

package br.com.brb.cix.domain.model.terminal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_TERMINAL")
public class Terminal  {
    private static final long serialVersionUID = -7884383952009631333L;
    
    @Id
    @SequenceGenerator(name = "terminal_sequence", sequenceName = "SQ_TERMINAL", allocationSize = 1)
    @GeneratedValue(generator = "terminal_sequence")
    @Column(name = "SQ_TERMINAL")
    private Long codigo;

    @Column(name = "DS_IP_TERMINAL")
    private String ipTerminal;

    @Column(name = "NR_TERMINAL")
    private Integer numeroTerminal;

    @Column(name = "ST_CAIXA")
    private Character caixa;

    @Column(name = "ST_ATIVO")
    private Character ativo;

    @Column(name = "CD_UNIDADE")
    private Long codigoUnidade;
    
    @Column(name = "CD_MODULO")
    private Integer modulo;
}

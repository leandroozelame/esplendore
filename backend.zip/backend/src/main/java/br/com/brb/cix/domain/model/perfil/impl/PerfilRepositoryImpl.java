package br.com.brb.cix.domain.model.perfil.impl;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import lombok.Getter;

@Repository
public class PerfilRepositoryImpl {
    @Getter
    private final EntityManager entityManager;

    @Autowired
    public PerfilRepositoryImpl(EntityManager manager) {
        entityManager = manager;
    }
}
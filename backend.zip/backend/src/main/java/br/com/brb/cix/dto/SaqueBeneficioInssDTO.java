package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.auditoria.anotacao.LogValorTransacao;
import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author u654764
 *
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SaqueBeneficioInssDTO extends AbstractDTO {
    private Long codigoTransacao;
    private EnumFormaMovimentacao formaMovimentacao;
    private Integer nrAgencia;
    private Long nrBeneficio;
    private Integer tctCod;
    private String senhaCartao;
    private String indicadorTransacaoSemCartao;
    private boolean gaveta;
    private String docIdentificacao;
    private Date dataEmissao;
    private String telefone;
    @LogValorTransacao
    private BigDecimal valorTransacao = BigDecimal.ZERO;
    private PendenciaDTO pendencia;
}
package br.com.brb.cix.config.jackson;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import br.com.brb.cix.domain.model.grupocnp.GrupoCNP;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

public class CustomGrupoCNPSerializer extends StdSerializer<List<GrupoCNP>>{

    private static final long serialVersionUID = 7331302650801416080L;

    public CustomGrupoCNPSerializer() {
        this(null);
    }
    
    public CustomGrupoCNPSerializer(Class<List<GrupoCNP>> t) {
        super(t);
    }
    
    @Override
    public void serialize(List<GrupoCNP> groups, 
            JsonGenerator generator, SerializerProvider provider) 
            throws IOException {
        List<GrupoCNP> grupos = new ArrayList<>();
        for (GrupoCNP grupo : groups) {
            grupo.setListaCorrespondentes(null);
            grupos.add(grupo);
        }
        generator.writeObject(grupos);
    }

}

package br.com.brb.cix.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

/**@auto
 * @author u654764
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class TabelaOperadorDTO extends AbstractDTO {

    @NotBlank(message = "nome obrigatorio")
    @Size(max = 33, message = "nome maximo 33 caracteres")
    private String nome;
    @NotNull(message = "nivel obrigatorio")
    private String nivel;
    @NotNull(message = "conta obrigatorio")
    private Long conta;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @NotNull(message = "senha obrigatorio")
    private String senha;
    @NotNull(message = "caixa obrigatorio")
    private boolean caixa;
    @NotNull(message = "valor obrigatorio")
    private BigDecimal valorMonetario = BigDecimal.ZERO;
    @NotNull(message = "dependencia obrigatorio")
    private Integer dependencia;
    @NotNull(message = "matricula obrigatorio")
    private Integer matricula;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private boolean senhaEditada;

    public BigDecimal getValorAlcadaInteiro(){
        return valorMonetario.multiply(BigDecimal.valueOf(100));
    }
}
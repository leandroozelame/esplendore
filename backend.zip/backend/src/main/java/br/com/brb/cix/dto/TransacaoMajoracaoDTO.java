package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TransacaoMajoracaoDTO extends AbstractDTO {
	
    private Integer cnlCod;
    private String cnlDes;
    private Long ttrCod;
    private String ttrDes;
    
}
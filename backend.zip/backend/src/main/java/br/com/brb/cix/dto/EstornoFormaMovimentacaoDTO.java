package br.com.brb.cix.dto;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EstornoFormaMovimentacaoDTO {
    private String formaMovimentacao;
    private boolean temValorDepositoDinheiro;
    private BigDecimal valorDepositoDinheiro = BigDecimal.ZERO;
    @JsonIgnore
    private EnumFormaMovimentacao enumFormaMovimentacao;
}

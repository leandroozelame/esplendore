package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import br.com.brb.cix.enums.EnumTipoEmprestimo;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class AlteraLimiteChequeEspecialDTO {
    private Long conta;
    private BigDecimal valorLimite;
    private Date dataVencimentoContrato;
    private EnumTipoEmprestimo tipoEmprestimo;
}
package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u653865
 *
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ValidacaoDTO extends AbstractDTO {

    private String nomeConversor;
    private String mensageErro;
    private Object objetoRetorno;

    /**
     * @param objetoRetorno
     */
    public ValidacaoDTO(String mensagemErro, Object objetoRetorno) {
        super();
        this.mensageErro = mensagemErro;
        this.objetoRetorno = objetoRetorno;
    }

}

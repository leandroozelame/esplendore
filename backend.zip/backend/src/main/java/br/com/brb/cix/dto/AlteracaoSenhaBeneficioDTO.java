package br.com.brb.cix.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import br.com.brb.cix.config.anotacao.LabelAuditoriaAlcada;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AlteracaoSenhaBeneficioDTO extends ContaTipoDTO {
    private String nomeBeneficiario;
    private String statusInss;
    @LabelAuditoriaAlcada(value = "CPF")
    private String cpf;
    private String nomeProcurador;
    private String numeroDocumento;
    private Date dataDocumento;
    private String telefone;
    @JsonProperty(access = Access.WRITE_ONLY)
    private String senhaNova;
}
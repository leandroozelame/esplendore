package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ConsultaLimitesFinanceirosDTO extends AbstractDTO {
    private Long agencia;
    private Long conta;
    private Integer tipoConta;
    private Integer modalidade;
}
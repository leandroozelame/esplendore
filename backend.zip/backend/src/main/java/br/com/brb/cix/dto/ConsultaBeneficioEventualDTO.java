package br.com.brb.cix.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConsultaBeneficioEventualDTO extends AbstractDTO {
    private Long sqBeneficioEventual;
    private Integer codigoModulo;
    private String descricaoModulo;
    private String programa;
    private String codigoPrograma;
    private int situacao;
    private Long dataCriacao;
    private Long matricula;
    private Long dataUltimaAlteracao;
    
	public ConsultaBeneficioEventualDTO(Long sqBeneficioEventual) {
		super();
		this.sqBeneficioEventual = sqBeneficioEventual;
	}
    
}
package br.com.brb.cix.config.anotacao;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/** Define uma label customizada para um campo de uma classe {@link br.com.brb.cix.dto DTO} na Alçada e no Log de Auditoria */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LabelAuditoriaAlcada {
	String value() default "";
}

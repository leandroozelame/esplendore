package br.com.brb.cix.domain.model.transacaoSupertransacao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoSupertransacaoRepository extends JpaRepository<TransacaoSupertransacao, Long> {
    
    TransacaoSupertransacao findByNsu(Long nsu);

}

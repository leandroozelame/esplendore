package br.com.brb.cix.domain.model.formasdemovimentacaobeneficiarios;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FormasDeMovimentacaoBeneficiariosRepository extends JpaRepository<FormasDeMovimentacaoBeneficiarios, Long> {
    
List<FormasDeMovimentacaoBeneficiarios> findByUnidadeAndBloqueado(Integer unidade, Boolean bloqueado);
    
    List<FormasDeMovimentacaoBeneficiarios> findByUnidadeAndNumeroContaCliente(Integer unidade, Long numeroContaCliente);
        
    List<FormasDeMovimentacaoBeneficiarios> findBynumeroContaClienteAndBloqueado(Long numeroContaCliente, Boolean bloqueado);
    
    List<FormasDeMovimentacaoBeneficiarios> findBynumeroContaClienteAndNomeCliente(Long numeroContaCliente, String nomeCliente);
    
    FormasDeMovimentacaoBeneficiarios findByNumeroContaCliente(Long numeroContaCliente);
    
    List<FormasDeMovimentacaoBeneficiarios> findByBloqueado(Boolean bloqueado);
    
    FormasDeMovimentacaoBeneficiarios findByCodigo(Long codigo);
    
    boolean existsByNumeroContaClienteAndBloqueado(Long numeroContaCliente, Boolean bloqueado);
    
    
}

package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UnidadeDTO {

    private Integer codigo;
    private String descricao;
    private Integer categoria;
    private Integer transacionavel;
    private Integer tipo;
}

package br.com.brb.cix.domain.model.enums;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum EnumTipoRecebimento implements EnumDominio {
    ARRECADACOES_DIVERSAS(3160,"Arrecadações Diversas"),
    RECEBIMENTO_CARTAO_CREDITO(5180,"Avulso de Cartão de Crédito"),
    RECEBIMENTO_DARF_PRETO(3340,"DARF Preto s/ Cód Barras"),
    ENVIO_CREDITO_MALOTE(3460,"Envio de Crédito de Malote"), 
    MALOTE_EMPRESARIAL(3660,"Malote Empresarial"), 
    RECEBIMENTO_OCA(5130,"Recebimento de Operações de Curso Anormal (OCA)"), 
    RECEBIMENTO_ARRECADACAO(3320,"Recebimento de Arrecadação"),
    RECEBIMENTO_GPS(3300,"Recebimento de GPS - Guia de Previdência Social"),
    RECEBIMENTO_TARIFA(3385,"Recebimento de Tarifa com Protocolo"),
    RECEBIMENTO_TITULOS_BRB(5010,"Recebimento de Títulos BRB"), 
    RECEBIMENTO_CCD_CFI(5070,"Recebimento de Títulos CCD/CFI"), 
    RECEBIMENTO_TITULOS_OUTROS_BANCOS(3200,"Recebimento de Títulos de Outros Bancos");
    
    
    private Integer codigo;
    private String descricao;

    static List<EnumTipoRecebimento> listaEnum = Arrays.asList(EnumTipoRecebimento.values());
    private static final Map<Integer, EnumTipoRecebimento> MAP = new HashMap<>();

    static {
        listaEnum.forEach(e -> MAP.put(e.getCodigo(), e));
    }

 
    @JsonCreator
    public static EnumTipoRecebimento get(int codigo) {
        return MAP.get(codigo);
    }


    public static List<Object> listarEnumTipoRecebimento() {
        return listaEnum.stream().map(r -> {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("codigo", MAP.get(r.getCodigo()).getCodigo());
            map.put("descricao", MAP.get(r.getCodigo()).getDescricao());
            return map;
        }).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return "0" + getCodigo() + " - " + getDescricao();
    }
}

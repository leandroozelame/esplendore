package br.com.brb.cix.dto;

import br.com.brb.cix.ws.autorizacao.anotacao.ParametroBPM;
import br.com.brb.cix.ws.dto.entrada.EntradaAutorizacaoDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**@auto
 * @author u654764
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class EntradaDeletarOperadorDTO extends EntradaAutorizacaoDTO {

    @ParametroBPM("BRB_CodigoDependencia")
    private Integer dependencia;
    @ParametroBPM("FTN_MatriculaEmpregado")
    private Integer matricula;
    @ParametroBPM("BRB_TctCod")
    private Integer tctCod;
}
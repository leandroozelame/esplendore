package br.com.brb.cix.dto;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor
public class RetornoDTO implements Serializable {
    private static final long serialVersionUID = 3325601943950782918L;
    @Builder.Default
    private Integer codigoErro = 0;
    @Builder.Default
    private String mensagem = "";
    @Builder.Default
    private Integer severidade = 0;
    private Object resultado;

    private Integer codigoTransacao;
    private Long unidade;
    private Long nsuCix;
    private Long nsuBlk;
    private Long nsuCixEstornado;

    public RetornoDTO(Object resultado) {
        this.resultado = resultado;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }
}
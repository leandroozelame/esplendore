package br.com.brb.cix.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class SenhaAlcadaDTO extends AbstractDTO {
    private String senhaAlcada;
    private String senhaLdap;
}
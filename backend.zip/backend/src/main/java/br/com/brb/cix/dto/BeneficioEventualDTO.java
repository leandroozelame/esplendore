package br.com.brb.cix.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BeneficioEventualDTO {
    private Long codigo;
    private Integer codigoModulo;
    private String programa;
    private String codigoPrograma;
    private int situacao;
}
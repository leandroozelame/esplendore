package br.com.brb.cix.domain.model.auditoria;

import br.com.brb.cix.auditoria.EnumSituacaoExecucao;
import br.com.brb.cix.enums.EnumCanal;
import br.com.brb.cix.enums.EnumFuncionalidade;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import com.querydsl.core.BooleanBuilder;
import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.Expressions;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public final class AuditoriaPredicateBuilder {

    
    public static BooleanBuilder numeroCanal(EnumCanal numeroCanal) {
        return Objects.isNull(numeroCanal) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.nrCanal.eq(numeroCanal));
    }

    public static BooleanBuilder agencia(String agencia) {
        return StringUtils.isEmpty(agencia) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.agenciaOperador.eq(agencia));
    }

    public static BooleanBuilder conta(String conta) {
        return StringUtils.isEmpty(conta) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.conta.eq(conta));
    }

    public static BooleanBuilder cpf(Long cpf) {
        return Objects.isNull(cpf) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.cpfCliente.eq(cpf.toString()));
    }

    public static BooleanBuilder rangeData(LocalDateTime dataInicio, LocalDateTime dataFim) {
        return new BooleanBuilder(
                QAuditoria.auditoria.dataOperacao.between(dataInicio, dataFim.plusDays(1).minusSeconds(1)));
    }

    public static BooleanBuilder ip(String ip) {
        return StringUtils.isEmpty(ip) ? new BooleanBuilder() : new BooleanBuilder(QAuditoria.auditoria.ip.eq(ip));
    }

    public static BooleanBuilder operador(String operador) {
        return StringUtils.isEmpty(operador) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.operador.eq(operador));
    }
    
    public static BooleanBuilder situacao(EnumSituacaoExecucao situacao) {
        return Objects.isNull(situacao) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.situacaoExecucao.eq(situacao));
    }
    
    public static BooleanBuilder situacaoInspetoria() {
        return new BooleanBuilder(QAuditoria.auditoria.situacaoExecucao.in(EnumSituacaoExecucao.SUCESSO, EnumSituacaoExecucao.REJEITADO, EnumSituacaoExecucao.ERRO));
    }

    // TODO Fazer os supervisores
    // public static BooleanBuilder supervisor(String supervisor) {
    // return Objects.isNull(supervisor) ? new BooleanBuilder()
    // : new BooleanBuilder(QAuditoria.auditoria.supervisores.eq(supervisor));
    // }

    public static BooleanBuilder valorOperacao(BigDecimal valorOperacao) {
        return Objects.isNull(valorOperacao) || valorOperacao.compareTo(BigDecimal.ZERO) == 0 ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.vlOperacao.eq(valorOperacao));
    }

    public static BooleanBuilder funcionalidade(String funcionalidade) {
        return StringUtils.isEmpty(funcionalidade) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.funcionalidade.eq(funcionalidade));
    }
    
    public static BooleanBuilder funcionalidadeExcetoInspetoria(String funcionalidade) {
        return StringUtils.isEmpty(funcionalidade) ? new BooleanBuilder(QAuditoria.auditoria.funcionalidade.ne(EnumFuncionalidade.INSPETORIA_DE_TRANSACOES.getDescricao()))
                : new BooleanBuilder(QAuditoria.auditoria.funcionalidade.eq(funcionalidade));
    }

    public static BooleanBuilder terminal(Integer terminal) {
        return Objects.isNull(terminal) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.nrTerminal.eq(terminal));
    }

    public static BooleanBuilder nsuAutorizacao(Long nsuAutorizacao) {
        return Objects.isNull(nsuAutorizacao) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.cdNsuAutorizacao.eq(nsuAutorizacao));
    }

    public static BooleanBuilder codigoTransacao(Integer tctCod) {
        return Objects.isNull(tctCod) ? new BooleanBuilder()
                : new BooleanBuilder(QAuditoria.auditoria.cdTransacao.eq(tctCod));
    }

    public static BooleanBuilder codigoTransacaoEmTextoResposta(String tctCod) {
        BooleanBuilder retorno = new BooleanBuilder();
        if(!StringUtils.isEmpty(tctCod)){
            retorno = new BooleanBuilder(Expressions.booleanTemplate("dbms_lob.instr({0},{1}) > 0", QAuditoria.auditoria.mapaParametrosSaida, tctCod));
        }
        return retorno;
    }    
    
    public static BooleanBuilder codigoTransacaoEmTextoRequisicao(String tctCod) {
        BooleanBuilder retorno = new BooleanBuilder();
        if(!StringUtils.isEmpty(tctCod)){
            retorno = new BooleanBuilder(Expressions.booleanTemplate("dbms_lob.instr({0},{1}) > 0", QAuditoria.auditoria.mapaParametroEntrada, tctCod));
        }
        return retorno;
    }    
    
    public static OrderSpecifier<LocalDateTime> ordenaPorDataDecrescente() {
        return QAuditoria.auditoria.dataOperacao.desc();
    }
    
    public static OrderSpecifier<LocalDateTime> ordenaPorDataCrescente() {
        return QAuditoria.auditoria.dataOperacao.asc();
    }

    public static OrderSpecifier<Long> ordenaPorId() {
        return QAuditoria.auditoria.id.desc();
    }
}
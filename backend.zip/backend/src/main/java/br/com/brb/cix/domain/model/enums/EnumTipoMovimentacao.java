package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoMovimentacao implements EnumDominio {
    SOLIDARIO(0, "Solidária"), NAO_SOLIDARIO(1, "Não Solidária"), SEM_MOVIMENTACAO(2, "Sem Movimentação");

    private static final Map<Integer, EnumTipoMovimentacao> MAP = new HashMap<>();

    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoMovimentacao e : EnumTipoMovimentacao.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoMovimentacao get(int codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumTipoMovimentacao criaEnum(Object tipo) {
        EnumTipoMovimentacao retorno = null;
        if ((Integer.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumTipoMovimentacao criaEnumString(String descricao) {
        EnumTipoMovimentacao retorno = null;
        Iterator<Map.Entry<Integer, EnumTipoMovimentacao>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, EnumTipoMovimentacao> par = it.next();
            if (par.getValue().name().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            } else if (par.getValue().getDescricao().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getDescricao();
    }

}

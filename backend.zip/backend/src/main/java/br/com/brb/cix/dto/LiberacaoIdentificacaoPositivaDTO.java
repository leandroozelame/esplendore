package br.com.brb.cix.dto;

import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class LiberacaoIdentificacaoPositivaDTO extends ContaTipoDTO {
    private String nomeProcurador;
    private String nomeTitular;
    private Integer ordemTitularConta;
    private String numeroDocumento;
    private Date dataDocumento;
    private String telefone;
}
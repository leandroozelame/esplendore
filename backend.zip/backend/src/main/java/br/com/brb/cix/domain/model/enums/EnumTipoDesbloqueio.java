package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumTipoDesbloqueio implements EnumDominio{
    CONTA(4, "Bloqueio de Conta"), 
    SALDO(5, "Bloqueio de Saldo"); 

    private static final Map<Integer, EnumTipoDesbloqueio> MAP = new HashMap<>();
    
    @Getter
    private Integer codigo;
    @Getter
    private String descricao;

    static {
        for (EnumTipoDesbloqueio e : EnumTipoDesbloqueio.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumTipoDesbloqueio get(int codigo) {
        return MAP.get(codigo);
    }
    
    @JsonCreator
    public static EnumTipoDesbloqueio criaEnum(int tipoConta) {
        return MAP.get(tipoConta);
    }
    
    @Override
    public String toString() {
    	return getCodigo() + " - " + getDescricao();
    }
    
}
package br.com.brb.cix.domain.model.funcionalidade;

import java.util.List;

import br.com.brb.cix.dto.FuncionalidadeDTO;

/**
 * @author u653865
 *
 */
public interface FuncionalidadeRepositoryCustom {

    /**
     * @return
     */
    List<FuncionalidadeDTO> listarComboFuncionalidadesNrTransacao(List<Integer> numerosTransacao, Integer modulo);

    /**
     * @param numeroTransacao
     * @return
     */
    String getStateFuncionalidadeByNrTransacao(Integer numeroTransacao);
    
    /**
     * @param codMenu
     * @return
     */
    Funcionalidade getSqlStateByCodMenu(Long codMenu);
    
    /**
     * @param codigoGrupo
     * @param codigoModulo
     * @param codigoFuncionalidade  
     * @return
     */
    FuncionalidadeDTO getByGrupoModuloFuncionalidade(Long codigoGrupo, Integer codigoModulo, Long codigoMenu);

}

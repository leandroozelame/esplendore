package br.com.brb.cix.domain.model.horariocanal;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import br.com.brb.cix.enums.EnumDiasSemana;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HorarioCanalRepository extends JpaRepository<HorarioCanal, Long> {

    static String SQL_BY_UND = " " 
            + " SELECT * FROM (                                                    "
            + "     SELECT                                                         "
            + "            TB.SQ_HORARIO_CANAL,                                    "
            + "            TB.CD_MODULO       ,                                    "
            + "            TB.CD_UNIDADE      ,                                    "
            + "            TB.ST_UNIDADE      ,                                    "
            + "            TB.DI_SEMANA       ,                                    "
            + "            TB.HR_INICIAL      ,                                    "
            + "            TB.HR_FINAL        ,                                    "
            + "            NULL AS DT_EXCECAO                                      "
            + "     FROM {h-schema}TB_HORARIO_CANAL TB                             "
            + "     WHERE TB.CD_MODULO = :codigoModulo                             "
            + "     AND TB.DT_EXCECAO IS NULL                                      "
            + "     AND TB.CD_UNIDADE IS NULL                                      "
            + "     AND TB.DI_SEMANA NOT IN (                                      "
            + "                               SELECT TB2.DI_SEMANA                 "
            + "                               FROM {h-schema}TB_HORARIO_CANAL TB2  "
            + "                               WHERE TB2.CD_MODULO = TB.CD_MODULO   "
            + "                               AND TB2.CD_UNIDADE  = :codigoUnidade "
            + "                               AND TB2.DT_EXCECAO IS NULL           "
            + "                              )                                     "
            + "                                                                    "
            + "     UNION ALL                                                      "
            + "                                                                    "
            + "     SELECT                                                         "
            + "         TB.SQ_HORARIO_CANAL,                                       "
            + "         TB.CD_MODULO       ,                                       "
            + "         TB.CD_UNIDADE      ,                                       "
            + "         TB.ST_UNIDADE      ,                                       "
            + "         TB.DI_SEMANA       ,                                       "
            + "         TB.HR_INICIAL      ,                                       "
            + "         TB.HR_FINAL        ,                                       "
            + "         TB.DT_EXCECAO                                              "
            + "     FROM                                                           "
            + "         {h-schema}TB_HORARIO_CANAL TB                              "     
            + "     WHERE                                                          "
            + "         TB.CD_MODULO = :codigoModulo                               "   
            + "         AND TB.DT_EXCECAO IS NOT NULL                              "             
            + "         AND TB.CD_UNIDADE IS NULL                                  "         
            + "         AND TB.DT_EXCECAO NOT IN (                                 "
            + "             SELECT                                                 "
            + "                 TB2.DT_EXCECAO                                     "           
            + "             FROM                                                   "
            + "                 {h-schema}TB_HORARIO_CANAL TB2                     "             
            + "             WHERE                                                  "
            + "                 TB2.CD_MODULO = TB.CD_MODULO                       "           
            + "                 AND TB2.CD_UNIDADE  = :codigoUnidade               "                 
            + "                 AND TB2.DT_EXCECAO IS NOT NULL                     "                    
            + "     )                                                              "
            + "                                                                    "
            + "     UNION ALL                                                      "
            + "                                                                    "
            + "     SELECT                                                         "
            + "            TB.SQ_HORARIO_CANAL,                                    "
            + "            TB.CD_MODULO       ,                                    "
            + "            TB.CD_UNIDADE      ,                                    "
            + "            TB.ST_UNIDADE      ,                                    "
            + "            TB.DI_SEMANA       ,                                    "
            + "            TB.HR_INICIAL      ,                                    "
            + "            TB.HR_FINAL        ,                                    "
            + "            NULL AS DT_EXCECAO                                      "
            + "     FROM {h-schema}TB_HORARIO_CANAL TB                             "
            + "     WHERE TB.CD_MODULO = :codigoModulo                             "
            + "     AND TB.CD_UNIDADE  = :codigoUnidade                            "
            + "     AND TB.DT_EXCECAO IS NULL                                      "
            + "                                                                    "
            + "     UNION ALL                                                      "
            + "                                                                    "
            + "     SELECT                                                         "
            + "            TB.SQ_HORARIO_CANAL,                                    "
            + "            TB.CD_MODULO       ,                                    "
            + "            TB.CD_UNIDADE      ,                                    "
            + "            TB.ST_UNIDADE      ,                                    "
            + "            TB.DI_SEMANA       ,                                    "
            + "            TB.HR_INICIAL      ,                                    "
            + "            TB.HR_FINAL        ,                                    "
            + "            TB.DT_EXCECAO                                           "
            + "     FROM {h-schema}TB_HORARIO_CANAL TB                             "
            + "     WHERE TB.CD_MODULO = :codigoModulo                             "
            + "     AND TB.CD_UNIDADE  = :codigoUnidade                            "
            + "     AND TB.DT_EXCECAO >= TRUNC(SYSDATE)                            "
            + " ) TB                                                               "
            + " ORDER BY TB.DT_EXCECAO,                                            "
            + "          TB.CD_MODULO ,                                            "
            + "          TB.DI_SEMANA                                              ";

    static final String SQL_BY_MDL = " " 
            + " SELECT * FROM CIX.TB_HORARIO_CANAL TB "
            + " WHERE TB.CD_MODULO = :codigoModulo    " 
            + " AND TB.CD_UNIDADE IS NULL             "
            + " ORDER BY TB. DI_SEMANA                ";
    
    static final String SQL_BY_MDL_UND_DIA = " " 
            + " SELECT * FROM {h-schema}TB_HORARIO_CANAL TB "
            + " WHERE                                       " 
            + " TB.CD_MODULO = :codigoModulo                "
            + " AND ( TB.CD_UNIDADE = :codigoUnidade        "
            + " OR                                          "
            + " TB.CD_UNIDADE IS NULL )                     "
            + " AND TB.DI_SEMANA = :diaSemana               "
            + " AND (TB.DT_EXCECAO IS NULL                  "
            + " OR                                          "
            + " TRUNC(TB.DT_EXCECAO) = TRUNC(SYSDATE) )     "
		    + " ORDER BY TB.DT_EXCECAO,                     "
		    + "          TB.CD_MODULO ,                     "
		    + "          TB.DI_SEMANA ,                     "
		    + "          TB.CD_UNIDADE                      ";
    
    static final String SQL_UNIDADES_CONFIGURADAS = ""
    		+ " SELECT * FROM {h-schema}TB_HORARIO_CANAL HC "
    		+ " WHERE HC.CD_MODULO = :codigoModulo          "
    		+ " AND HC.CD_UNIDADE IS NOT NULL               "
    		+ " AND (HC.DT_EXCECAO IS NULL                  "
    		+ "   OR TRUNC(HC.DT_EXCECAO) >= TRUNC(SYSDATE))";
	
    @Query(nativeQuery = true, value = SQL_BY_UND )
    List<HorarioCanal> listHorarioCanalByUnidade(@Param("codigoModulo") Integer codigoModulo, @Param("codigoUnidade") Long codigoUnidade);
    
    @Query(nativeQuery = true, value = SQL_BY_MDL )
    List<HorarioCanal> listHorarioCanalByModulo(@Param("codigoModulo") Integer codigoModulo);
    
    @Query(nativeQuery = true, value = SQL_BY_MDL_UND_DIA )
    List<HorarioCanal> listHorarioCanalByModuloUnidadeDia(@Param("codigoModulo") Integer codigoModulo, @Param("codigoUnidade") Long codigoUnidade, @Param("diaSemana") Integer diaSemana);
    
    @Query(nativeQuery = true, value = SQL_UNIDADES_CONFIGURADAS )
    List<HorarioCanal> listHorarioCanalByUnidadesConfiguradas(@Param("codigoModulo") Integer codigoModulo);

    HorarioCanal findByCodigo(Long codigo);

    @Transactional
    void deleteByCodigo(Long codigo);
    
    HorarioCanal findByCodigoModuloAndCodigoUnidadeAndDataExcecao(Integer modulo, Long unidade, Date dataExcecao);
    
    HorarioCanal findByCodigoModuloAndDataExcecao(Integer modulo, Date dataExcecao);
    
    HorarioCanal findByCodigoModuloAndDiaSemanaAndDataExcecaoIsNullAndCodigoUnidadeIsNull(Integer module, EnumDiasSemana diaSemana);
    
    Boolean existsHorarioCanalByCodigoModuloAndCodigoUnidadeAndDataExcecao(Integer module, Long unidade, Date dataExcecao);
}

package br.com.brb.cix.config.security.openshift;

import br.com.brb.cix.domain.model.parametrocanal.ParametroCanalRepository;
import br.com.brb.cix.security.CixAccessDeniedHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationProvider;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.PostConstruct;
import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

@EnableWebSecurity
@Order(Ordered.LOWEST_PRECEDENCE)
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
@Profile({"openShift","weblogic"})
@Slf4j
public class OpenShiftSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private OpenAmPreAuthUserDetailsOpenShiftService openAmPreAuthUserDetailsAutocontidoService;

    @Autowired
    private CixAccessDeniedHandler cixAccessDeniedHandler;

    @Autowired
    private ParametroCanalRepository parametroRepository;

    private static String urlOpenAm;

    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v2
            "/v2/api-docs",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",
            "/webjars/**",
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/swagger-ui/**",

            // -- Swagger UI v2
            "/cix/v2/api-docs",
            "/cix/swagger-resources",
            "/cix/swagger-resources/**",
            "/cix/configuration/ui",
            "/cix/configuration/security",
            "/cix/swagger-ui.html",
            "/cix/webjars/**",
            // -- Swagger UI v3 (OpenAPI)
            "/cix/v3/api-docs/**",
            "/cix/swagger-ui/**"
    };

    private static final String PARAMETRO_HOST_OAM = "HOST_OAM";

    @PostConstruct
    public void init(){
        urlOpenAm = parametroRepository.findByParametro(PARAMETRO_HOST_OAM).getValorParametro();
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .csrf()
                .disable()
                .anonymous()
                .disable()
                .authorizeRequests()
                .antMatchers(AUTH_WHITELIST).permitAll()
                .antMatchers("/**").authenticated()
                .and()
                .addFilter(preAuthFilter())
                .exceptionHandling()
                .accessDeniedHandler(cixAccessDeniedHandler);
    }

    @Override
    public void configure(WebSecurity web) {
        web
                .ignoring()
                .antMatchers(AUTH_WHITELIST);
    }

    @Bean
    protected Filter preAuthFilter() {
        OpenAmPreAuthAutocontidoFilter filter = new OpenAmPreAuthAutocontidoFilter();
        filter.setAuthenticationManager(preAuthAuthenticationManager());
        return filter;
    }

    @Bean
    protected AuthenticationManager preAuthAuthenticationManager() {

        PreAuthenticatedAuthenticationProvider preAuthProvider= new PreAuthenticatedAuthenticationProvider();
        preAuthProvider.setPreAuthenticatedUserDetailsService(openAmPreAuthUserDetailsAutocontidoService);

        List<AuthenticationProvider> providers = new  ArrayList<>();
        providers.add(preAuthProvider);

        return new ProviderManager(providers);
    }

    public static class OpenAmPreAuthAutocontidoFilter extends AbstractPreAuthenticatedProcessingFilter {

        @Override
        protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
            String matriculaOperador = null;
            try {
                String tokenOpenAm = recuperaTokenDoOpenAm(request);

                if (tokenOpenAm == null) {
                    log.warn("Token 'iPlanetDirectoryPro' não encontrado");
                    return matriculaOperador;
                }

                ResponseEntity<TokenOpemAmDTO> resposta = consultaTokenOpenAm(tokenOpenAm);
                log.debug("Usuario encontrado para o token informado");

                matriculaOperador = resposta.getBody().findName();
            } catch (HttpClientErrorException e) {
                log.error(e.getMessage());
            } catch (Exception e) {
                log.error("Falha ao recuperar token do openam", e);
            }
            return matriculaOperador;
        }

        private ResponseEntity<TokenOpemAmDTO> consultaTokenOpenAm(String tokenOpenAm) throws URISyntaxException {
            String urlOpenAm = getUrlOpenAm(tokenOpenAm);
            RestTemplate restTemplateOpenAm = new RestTemplateBuilder().rootUri(urlOpenAm).build();

            RequestEntity<Void> requestEntity = RequestEntity
                    .get(new URI(urlOpenAm))
                    .accept(MediaType.APPLICATION_JSON)
                    .build();

            return restTemplateOpenAm.exchange(requestEntity, TokenOpemAmDTO.class);
        }

        @Override
        protected Object getPreAuthenticatedCredentials(HttpServletRequest httpRequest) {
            return "N/A";
        }

        private String recuperaTokenDoOpenAm(HttpServletRequest request) {
            String tokenOpenAm = "";
            if (request.getCookies() != null) {
                for (int i = 0; i < request.getCookies().length; i++) {
                    if ("iPlanetDirectoryPro".equals(request.getCookies()[i].getName())) {
                        tokenOpenAm = request.getCookies()[i].getValue();
                    }
                }
            }

            if ("".equals(tokenOpenAm)){
                tokenOpenAm = request.getHeader("iPlanetDirectoryPro");
            }

            return tokenOpenAm;
        }

        private String getUrlOpenAm(String tokenId) throws URISyntaxException {
            return UriComponentsBuilder.newInstance().uri(new URI(urlOpenAm))
                    .path("/identity/json/attributes")
                    .queryParam("subjectid", tokenId)
                    .queryParam("attributenames", "name")
                    .build()
                    .toUriString();
        }
    }
}

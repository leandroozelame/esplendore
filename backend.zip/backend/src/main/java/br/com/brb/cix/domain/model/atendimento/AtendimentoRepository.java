package br.com.brb.cix.domain.model.atendimento;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AtendimentoRepository extends JpaRepository<Atendimento, Long> {
    Atendimento findByCodigo(Long codigo);
}
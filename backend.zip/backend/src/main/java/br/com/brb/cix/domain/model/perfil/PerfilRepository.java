package br.com.brb.cix.domain.model.perfil;

import br.com.brb.cix.domain.model.grupo.Grupo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import java.util.List;
import java.util.Optional;

public interface PerfilRepository extends JpaRepository<Perfil, Long>, JpaSpecificationExecutor<Perfil>, QueryDslPredicateExecutor<Perfil> {
    Optional<Perfil> findByModuloAndListaGruposIn(Integer modulo, List<Grupo> grupos);
    
    boolean existsByNomeIgnoreCaseAndModuloAndCodigoNot(String nome, Integer modulo, Long codigo);
}

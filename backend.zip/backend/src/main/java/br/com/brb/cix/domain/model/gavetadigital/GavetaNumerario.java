package br.com.brb.cix.domain.model.gavetadigital;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

import br.com.brb.cix.domain.model.tiponumerario.TipoNumerario;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @param valorNumerario
 */
@Setter
@Getter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@IdClass(GavetaNumerarioId.class)
@Table(name = "TB_GAVETA_NUMERARIO")
public class GavetaNumerario  {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "SQ_GAVETA_DIGITAL", nullable = false)
    @JsonBackReference
    private GavetaDigital gavetaDigital;

    @Id
    @ManyToOne
    @JoinColumn(name = "SQ_TIPO_NUMERARIO")
    private TipoNumerario tipoNumerario;

    @Column(name = "QT_NUMERARIO")
    private Integer quantidadeNumerario;

    @Column(name = "VL_NUMERARIO")
    private BigDecimal valorNumerario;

}

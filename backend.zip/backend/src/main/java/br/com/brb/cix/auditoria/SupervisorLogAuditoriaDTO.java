/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.auditoria;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 *
 * @author u842773
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class SupervisorLogAuditoriaDTO {
    private Long codigoSupervisor;
    private String matricula;
    private Integer ordem;
}
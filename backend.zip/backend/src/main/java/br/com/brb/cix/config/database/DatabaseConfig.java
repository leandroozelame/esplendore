package br.com.brb.cix.config.database;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.bind.RelaxedPropertyResolver;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.Properties;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = {"br.com.brb.cix"}, repositoryImplementationPostfix = "Impl")
@ConditionalOnExpression("${spring.jta.enabled}==false")
public class DatabaseConfig implements EnvironmentAware {

    public static final String JNDI_NAME = "jndi-name";
    public static final String SPRING_DATASOURCE = "spring.datasource.";
    public static final String SPRING_JPA_PROPERTIES = "spring.jpa.properties.";
    public static final String VALIDATE = "validate";
    public static final String HIBERNATE_FORMAT_SQL = "hibernate.format_sql";
    public static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
    public static final String HIBERNATE_DIALECT = "hibernate.dialect";
    public static final String HIBERNATE_HBM2DDL_AUTO = "hibernate.hbm2ddl.auto";
    public static final String HIBERNATE_DEFAULT_SCHEMA = "hibernate.default_schema";
    protected RelaxedPropertyResolver jpaPropertyResolver;
    protected RelaxedPropertyResolver dataSourcePropertyResolver;

	@Profile("autoContido")
    @Bean
    @Autowired
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(DataSource dataSource) {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        
        em.setDataSource(dataSource);
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());
        em.setPackagesToScan(new String[] {"br.com.brb.cix"});
        return em;
    }
	
	@Profile("weblogic")
	@Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        JpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        
        em.setDataSource(dataSource());
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());
        em.setPackagesToScan(new String[] {"br.com.brb.cix"});
        return em;
    }

	@Profile("weblogic")
    @Bean(destroyMethod = "")
    public DataSource dataSource() {
        final JndiDataSourceLookup dsLookup = new JndiDataSourceLookup();
 
        dsLookup.setResourceRef(true);
        
        DataSource dataSource = dsLookup.getDataSource(dataSourcePropertyResolver.getProperty(JNDI_NAME));
        
        return dataSource;
    }

    @Override
    public void setEnvironment(Environment environment) {
        this.jpaPropertyResolver = new RelaxedPropertyResolver(environment, SPRING_JPA_PROPERTIES);
        this.dataSourcePropertyResolver = new RelaxedPropertyResolver(environment, SPRING_DATASOURCE);
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    protected Properties additionalProperties() {
        Properties properties = new Properties();

        properties.setProperty(HIBERNATE_HBM2DDL_AUTO, jpaPropertyResolver.getProperty(HIBERNATE_HBM2DDL_AUTO, VALIDATE));
        properties.setProperty(HIBERNATE_DIALECT, jpaPropertyResolver.getProperty(HIBERNATE_DIALECT));
        properties.setProperty(HIBERNATE_DEFAULT_SCHEMA, jpaPropertyResolver.getProperty(HIBERNATE_DEFAULT_SCHEMA));
        properties.setProperty(HIBERNATE_SHOW_SQL, jpaPropertyResolver.getProperty(HIBERNATE_SHOW_SQL, Boolean.FALSE.toString()));
        properties.setProperty(HIBERNATE_FORMAT_SQL, jpaPropertyResolver.getProperty(HIBERNATE_FORMAT_SQL, Boolean.FALSE.toString()));
        return properties;
    }
}
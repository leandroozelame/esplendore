package br.com.brb.cix.domain.model.formasdemovimentacaobeneficiarios;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import br.com.brb.cix.domain.model.enums.EnumTipoConta;
import br.com.brb.cix.domain.model.formapagamento.FormaPagamento;
import br.com.brb.cix.domain.model.modulo.Modulo;
import br.com.brb.cix.util.ConvertCharToBoolean;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * @author u662999
 *
 */
@Entity
@Getter
@Setter
@NoArgsConstructor
@Table(name = "TB_FORMA_DE_MOV_BENEFICIARIO")
public class FormasDeMovimentacaoBeneficiarios  {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "forma_de_mov_beneficiario_sequence", sequenceName = "SQ_FORMA_DE_MOV_BENEFICIARIO", allocationSize = 1)
    @GeneratedValue(generator = "forma_de_mov_beneficiario_sequence")
    @Column(name = "SQ_FORMA_DE_MOV_BENEFICIARIO", nullable = false)
    private Long codigo;

    @Column(name = "CD_UNIDADE")
    private Integer unidade;
    
    @Column(name = "CD_TIPO_CONTA_CLIENTE")
    private EnumTipoConta tipoContaCliente;
    
    @Column(name = "NR_CONTA_CLIENTE")
    private Long numeroContaCliente;
    
    @Column(name = "NO_CLIENTE")
    private String nomeCliente;
    
    @ManyToOne
    @JoinColumn(name = "CD_FORMA_PAGAMENTO")
    private FormaPagamento formaPagamento;
    
    @ManyToOne
    @JoinColumn(name = "CD_MODULO")
    private Modulo modulo;
    
    @Convert(converter = ConvertCharToBoolean.class)
    @Column(name = "ST_BLOQUEADO")
    private Boolean bloqueado;
    
}

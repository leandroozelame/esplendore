package br.com.brb.cix.domain.model.formapagamento;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.Date;

@Entity
@Getter
@Setter
@Table(name = "TB_FORMA_PAGAMENTO")
@ToString
public class FormaPagamento  {

    private static final long serialVersionUID = -7945086156339761292L;

    @Id
    @Column(name = "CD_FORMA_PAGAMENTO")
    private Long codigo;
    
    @Column(name = "DS_FORMA_PAGAMENTO")
    private String descricao;

    @Column(name = "DT_CRIACAO")
    private Date dataCriacao;

    @Column(name = "DT_ALTERACAO")
    private Date dataAlteracao;

    @Column(name = "ST_ATIVO")
    private Boolean habilitado;

}

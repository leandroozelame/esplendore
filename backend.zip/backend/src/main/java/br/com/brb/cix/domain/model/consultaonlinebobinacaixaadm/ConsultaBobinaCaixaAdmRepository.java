package br.com.brb.cix.domain.model.consultaonlinebobinacaixaadm;

import br.com.brb.cix.domain.model.bobina.Bobina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConsultaBobinaCaixaAdmRepository extends JpaRepository<Bobina, Long> {
    
	
}

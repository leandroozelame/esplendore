package br.com.brb.cix.domain.model.formaautenticacao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "TB_FORMA_AUTENTICACAO")
public class FormaAutenticacao  {
    
    private static final long serialVersionUID = -8506562106548835809L;

    @Id
    @Column(name = "CD_FORMA_AUTENTICACAO")
    private Long codigo;
    
    @Column(name = "DS_FORMA_AUTENTICACAO")
    private String descricao;
    
}

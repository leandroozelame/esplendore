package br.com.brb.cix.domain.model.horariocanal;

import java.util.Date;

import br.com.brb.cix.enums.EnumDiasSemana;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HorarioCanalDTO {

    private Long codigo;
    private Integer codigoModulo;
    private Long codigoUnidade;
    private Date dataExcecao;
    private EnumDiasSemana diaSemana;
    private String horaInicial;
    private String horaFinal;
    private Boolean situacaoUnidade;

    /**
     * @param horaInicial
     * @param horaFinal
     */
    public HorarioCanalDTO(String horaInicial, String horaFinal) {
        this.horaInicial = horaInicial;
        this.horaFinal = horaFinal;
    }

    /**
     * @param codigo
     */
    public HorarioCanalDTO(Long codigo) {
        this.codigo = codigo;
    }

    /**
     * @param diaSemana
     * @param horaInicial
     * @param horaFinal
     * @param situacaoUnidade
     */
    public HorarioCanalDTO(EnumDiasSemana diaSemana, String horaInicial, String horaFinal, Boolean situacaoUnidade) {
        this.diaSemana = diaSemana;
        this.horaInicial = horaInicial;
        this.horaFinal = horaFinal;
        this.situacaoUnidade = situacaoUnidade;
    }
    
    public HorarioCanalDTO(EnumDiasSemana diaSemana, Boolean situacaoUnidade) {
        this.diaSemana = diaSemana;
        this.situacaoUnidade = situacaoUnidade;
    }
    
    public HorarioCanalDTO(HorarioCanal horarioCanal) {
        this.codigo = horarioCanal.getCodigo();
        this.codigoModulo = horarioCanal.getCodigoModulo();
        this.codigoUnidade = horarioCanal.getCodigoUnidade();
        this.dataExcecao = horarioCanal.getDataExcecao();
        this.diaSemana  = horarioCanal.getDiaSemana();
		this.horaInicial  = horarioCanal.getHoraInicial();
		this.horaFinal  = horarioCanal.getHoraFinal();
		this.situacaoUnidade  = horarioCanal.getSituacaoUnidade();
    }
}

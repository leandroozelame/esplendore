package br.com.brb.cix.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Data
@Getter
@EqualsAndHashCode(callSuper = false)
public class ConsultaBeneficioSocialDTO extends AbstractDTO {
   
    private Integer codigoSeguranca;
    private String nrCartao;
    private String senha;
    
}

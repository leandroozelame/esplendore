package br.com.brb.cix.dto;

import java.math.BigDecimal;
import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ConsultaChequeEspecialDTO extends AbstractDTO {
    private Long conta;
    private String nomeTitular;
    protected Date dataVencimento;
    protected String dsTipoEmprestimo;
    protected BigDecimal limite;
    protected Integer tipoEmprestimo;
}
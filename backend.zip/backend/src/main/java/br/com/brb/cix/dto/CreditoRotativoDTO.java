package br.com.brb.cix.dto;

import java.math.BigDecimal;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@ToString
public class CreditoRotativoDTO extends AbstractDTO {

    private Long agencia;
    private Long conta;
    private String contrato;
    private BigDecimal contratoValorOperacao;
    private BigDecimal contratoValorIOF;
    private BigDecimal contratoValorSeguro;
    private BigDecimal contratoValorTarifa;

    public BigDecimal getContratoValorLiquido() {
        return getContratoValorOperacao()
                .subtract(getContratoValorSeguro())
                .subtract(getContratoValorIOF())
                .subtract(getContratoValorTarifa());
    }
}

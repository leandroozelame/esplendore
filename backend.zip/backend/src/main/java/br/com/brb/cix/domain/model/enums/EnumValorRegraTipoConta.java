package br.com.brb.cix.domain.model.enums;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Iterator;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum EnumValorRegraTipoConta implements EnumDominio {
    CONTA_CORRENTE('0', "Conta Corrente"),
    CONTA_SALARIO('1', "Conta Salário"),
    CONTA_POUPANCA('2', "Conta Poupança"),
    POUPANCA_INTEGRADA('3', "Poupança Integrada"),
    CONTA_VINCULADA('4', "Conta Vinculada"),
    INDIFERENTE('9', "Indiferente");

    private static final Map<Character, EnumValorRegraTipoConta> MAP = new HashMap<>();

    @Getter
    private Character codigo;
    @Getter
    private String descricao;

    static {
        for (EnumValorRegraTipoConta e : EnumValorRegraTipoConta.values()) {
            MAP.put(e.getCodigo(), e);
        }
    }

    public static EnumValorRegraTipoConta get(Character codigo) {
        return MAP.get(codigo);
    }

    @JsonCreator
    public static EnumValorRegraTipoConta criaEnum(Object tipo) {
        EnumValorRegraTipoConta retorno = null;
        if ((Character.class.isInstance(tipo))) {
            retorno = MAP.get(tipo);
        } else {
            retorno = criaEnumString((String) tipo);
        }

        return retorno;
    }

    private static EnumValorRegraTipoConta criaEnumString(String descricao) {
        EnumValorRegraTipoConta retorno = null;
        Iterator<Map.Entry<Character, EnumValorRegraTipoConta>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Character, EnumValorRegraTipoConta> par = it.next();
            if (par.getValue().toString().equalsIgnoreCase(descricao) || par.getKey().toString().equalsIgnoreCase(descricao)) {
                retorno = par.getValue();
            }
        }
        return retorno;
    }

    @Override
    public String toString() {
        return getCodigo() + " - " + getDescricao();
    }

}

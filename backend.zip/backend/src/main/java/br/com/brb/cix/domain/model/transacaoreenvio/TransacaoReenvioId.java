/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.brb.cix.domain.model.transacaoreenvio;

import java.io.Serializable;
import java.util.Objects;

public class TransacaoReenvioId implements Serializable {

    private static final long serialVersionUID = 1665275683388247082L;

    protected Long matriculaOperador;
    private Long nsuCanal;

    public TransacaoReenvioId() {}

    public TransacaoReenvioId(Long matriculaOperador, Long nsuCanal) {
        this.matriculaOperador = matriculaOperador;
        this.nsuCanal = nsuCanal;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TransacaoReenvioId other = (TransacaoReenvioId) obj;
        if (!Objects.equals(this.matriculaOperador, other.matriculaOperador)) {
            return false;
        }
        if (!Objects.equals(this.nsuCanal, other.nsuCanal)) {
            return false;
        }
        return true;
    }

}

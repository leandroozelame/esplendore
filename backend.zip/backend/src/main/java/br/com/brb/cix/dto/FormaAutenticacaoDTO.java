package br.com.brb.cix.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class FormaAutenticacaoDTO {

    private Long codigo;
    private String descricao;
    private Boolean aceita;
    
    public Boolean getAceita() {
        return aceita == null ? true : aceita;
    }
}

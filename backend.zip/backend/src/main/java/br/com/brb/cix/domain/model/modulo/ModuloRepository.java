package br.com.brb.cix.domain.model.modulo;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ModuloRepository  extends JpaRepository<Modulo, Integer> {
    Modulo findByCodigo(Long codigo);
    List<Modulo> findAllByOrderByCodigo();
}

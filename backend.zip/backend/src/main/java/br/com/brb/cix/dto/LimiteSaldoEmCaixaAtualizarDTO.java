package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.domain.model.limitesaldocaixa.LimiteSaldoEmCaixa;
import br.com.brb.cix.domain.model.limitesaldocaixa.LimiteSaldoEmCaixaRepository;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


@Data
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
public class LimiteSaldoEmCaixaAtualizarDTO extends AbstractDTO {

    private Long codigo;
    private BigDecimal valorLimiteSaldoCheque;
    private BigDecimal valorLimiteSaldoDinheiro;
   
    
    public LimiteSaldoEmCaixaAtualizarDTO(LimiteSaldoEmCaixa limiteSaldoEmCaixa) {
        this.codigo = limiteSaldoEmCaixa.getCodigo();
        this.valorLimiteSaldoCheque = limiteSaldoEmCaixa.getValorLimiteSaldoCheque();
        this.valorLimiteSaldoDinheiro = limiteSaldoEmCaixa.getValorLimiteSaldoDinheiro();
    }
   
    public LimiteSaldoEmCaixaAtualizarDTO() {
    }
    
    public LimiteSaldoEmCaixa atualizar(Long codigo, LimiteSaldoEmCaixaRepository limiteEmCaixaRepository) {
        LimiteSaldoEmCaixa limite = limiteEmCaixaRepository.getOne(codigo);
        limite.setValorLimiteSaldoCheque(this.valorLimiteSaldoCheque);
        limite.setValorLimiteSaldoDinheiro(this.valorLimiteSaldoDinheiro);
        return limite;
    }

    
}

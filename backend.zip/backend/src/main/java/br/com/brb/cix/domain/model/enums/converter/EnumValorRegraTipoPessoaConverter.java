package br.com.brb.cix.domain.model.enums.converter;

import br.com.brb.cix.domain.model.enums.EnumValorRegraTipoPessoa;
import javax.persistence.AttributeConverter;
import javax.persistence.Converter;

@Converter(autoApply = true)
public class EnumValorRegraTipoPessoaConverter implements AttributeConverter<EnumValorRegraTipoPessoa, Character> {

    @Override
    public Character convertToDatabaseColumn(EnumValorRegraTipoPessoa valorRegra) {
        return valorRegra != null ? valorRegra.getCodigo() : null;
    }

    @Override
    public EnumValorRegraTipoPessoa convertToEntityAttribute(Character codigo) {
        return EnumValorRegraTipoPessoa.get(codigo);
    }
}

package br.com.brb.cix.dto;

import java.math.BigDecimal;

import br.com.brb.cix.enums.EnumFormaMovimentacao;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class LimiteTransacaoDTO {
	private Integer codigoMenuFuncionalidade;
	private BigDecimal valorTransacao;
	private EnumFormaMovimentacao formaMovimentacao;
}